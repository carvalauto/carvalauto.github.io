# 🎯 立即开始 - 阿里巴巴采集器

## 🚀 3步安装，马上开始使用

### 第1步：打开Chrome扩展管理页面

在Chrome浏览器地址栏输入：
```
chrome://extensions/
```

### 第2步：启用开发者模式

在页面右上角找到"开发者模式"开关，点击开启。

### 第3步：加载插件

1. 点击"加载已解压的扩展程序"按钮
2. 选择 `alibaba-collector` 文件夹
3. ✅ 安装完成！

---

## ✅ 插件已完全预配置

**所有配置信息已嵌入，无需手动配置！**

### 📋 已配置信息

#### ✅ 阿里云OSS配置
```
✅ 地域节点: oss-cn-hangzhou
✅ 存储桶名称: carvalauto-products
✅ AccessKey ID: LTAI5tKCovsg5dJWKxoXwDr2
✅ AccessKey Secret: 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
✅ 存储目录: products/
```

#### ✅ 网站配置
```
✅ 域名: https://carvalautopart.com
✅ 管理页面: https://carvalautopart.com/admin.html
✅ 产品页面: https://carvalautopart.com/product.html
```

#### ✅ GitHub配置
```
✅ 用户名: carvalauto
✅ 仓库名称: carvalauto.github.io
✅ 分支: main
✅ 已配置3个GitHub Token
```

#### ✅ Google Analytics配置
```
✅ 媒体资源ID: 529242507
✅ 已启用
```

---

## 🎯 立即开始采集

### 1. 访问阿里巴巴商品页面

打开任意阿里巴巴1688商品详情页：
```
https://www.alibaba.com/product-detail/商品ID.html
```

### 2. 悬浮窗自动显示

插件会自动在页面右侧显示悬浮窗，包含：
- 状态指示器
- "开始采集"按钮
- 实时统计信息
- 采集日志

### 3. 点击采集

点击"开始采集"按钮，或使用快捷键：
```
Ctrl + Shift + A
```

### 4. 查看结果

- 悬浮窗实时显示采集进度
- 数据自动上传到OSS
- 网站后台实时显示新采集的产品

---

## 🎨 悬浮窗使用技巧

### 拖拽移动
- 长按彩色标题栏
- 拖动到任意位置
- 松开鼠标完成移动

### 最小化/展开
- 点击 `−` 按钮最小化悬浮窗
- 点击 `+` 按钮展开悬浮窗

### 查看错误
- 错误信息显示在"错误信息"区域
- 点击"展开"查看详细错误代码

---

## 📊 采集规则

### ✅ 会采集的内容

1. **产品标题** - 商品完整标题
2. **产品主图** - 主图区域图片（最多6张，跳过带Logo的）
3. **OEM编码** - 从标题自动提取
4. **车型适配表** - 仅当存在时采集

### ❌ 不会采集的内容

1. **价格** - 完全不采集
2. **无车型商品** - 没有车型适配表的商品自动跳过
3. **带Logo图片** - 自动过滤

---

## 🔍 查看采集结果

### OSS存储
```
https://carvalauto-products.oss-cn-hangzhou.aliyuncs.com/
```

### 网站后台
```
https://carvalautopart.com/admin.html
```

### 产品页面
```
https://carvalautopart.com/product.html
```

---

## 📱 移动端使用

### Kiwi Browser（推荐）
1. 安装Kiwi Browser
2. 访问 `kiwi://extensions/`
3. 按照PC端相同步骤安装

### Firefox for Android
1. 安装Firefox for Android
2. 启用扩展支持
3. 加载临时扩展

---

## ⚠️ 常见问题

### Q: 悬浮窗不显示？
**A:** 确保在阿里巴巴商品详情页，刷新页面重试。

### Q: OSS上传失败？
**A:** 检查网络连接，查看悬浮窗中的详细错误信息。

### Q: 采集数据不完整？
**A:** 某些商品可能没有完整的车型适配表，这是正常的。

### Q: 网站端没有显示新产品？
**A:** 清除浏览器缓存，检查OSS URL是否正确。

---

## 🎉 开始使用吧！

**现在就安装插件，开始高效采集阿里巴巴商品数据！**

**插件已完全预配置，开箱即用！** ✅

**享受智能悬浮窗、实时错误显示、OSS直传的强大功能！** 🚀

---

## 📞 需要帮助？

查看详细文档：
- 📖 [完整使用说明](README.md)
- 🛠️ [安装配置指南](INSTALL.md)
- ⚡ [快速开始](QUICK_START.md)
- 📋 [安装完成指南](INSTALL_COMPLETE.md)
- 🚀 [部署指南](DEPLOYMENT.md)

---

**祝采集顺利！** 🎯🚀