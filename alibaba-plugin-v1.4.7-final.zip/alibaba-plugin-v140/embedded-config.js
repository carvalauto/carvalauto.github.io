// Alibaba采集器 - 完全嵌入式配置
// 所有配置已硬编码，无需用户配置

const EMBEDDED_CONFIG = {
  // 阿里云OSS配置（硬编码）
  oss: {
    region: 'oss-cn-hangzhou',
    bucket: 'carvalauto-products',
    accessKeyId: 'LTAI5tKCovsg5dJWKxoXwDr2',
    accessKeySecret: 'vDdWLEKBnnmFFZwOeLzX73vRo8k0WW',
    directory: 'products/',
    endpoint: 'https://carvalauto-products.oss-cn-hangzhou.aliyuncs.com',
    productsUrl: 'https://carvalauto-products.oss-cn-hangzhou.aliyuncs.com/products.json'
  },

  // 网站配置（硬编码）
  website: {
    domain: 'https://carvalautopart.com',
    adminPage: 'https://carvalautopart.com/admin.html',
    productPage: 'https://carvalautopart.com/product.html'
  },

  // GitHub配置（硬编码）
  github: {
    username: 'carvalauto',
    repository: 'carvalauto.github.io',
    branch: 'main',
    domain: 'https://carvalautopart.com',
    tokens: [
      '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',
      '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',
      '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'
    ]
  },

  // Google Analytics配置（硬编码）
  analytics: {
    trackingId: '529242507',
    enabled: true
  },

  // 采集规则配置（硬编码）
  collection: {
    collectImages: true,
    collectFitment: true,
    skipLogoImages: true,
    autoSEO: true,
    retryCount: 3,
    timeoutSeconds: 120,
    maxImages: 6
  },

  // 插件信息
  plugin: {
    name: '阿里巴巴商品采集器 - 预配置版',
    version: '1.0.0',
    description: '完全预配置，开箱即用'
  }
};

// 导出配置
if (typeof window !== 'undefined') {
  window.EMBEDDED_CONFIG = EMBEDDED_CONFIG;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = EMBEDDED_CONFIG;
}