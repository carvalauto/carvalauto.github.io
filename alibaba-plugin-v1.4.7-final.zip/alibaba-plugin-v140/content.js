// Alibaba商品采集器 - 内容脚本（修复版）
// 实现悬浮窗、拖拽功能、实时状态显示
// 修复了图片提取和OEM编码提取问题

class AlibabaCollector {
  constructor() {
    this.isInitialized = false;
    this.floatingWindow = null;
    this.isDragging = false;
    this.dragOffset = { x: 0, y: 0 };
    this.collectionStats = {
      total: 0,
      success: 0,
      failed: 0,
      inProgress: 0
    };
    this.errorMessages = [];
    this.processQueue = [];
    this.isProcessing = false;
    
    this.init();
  }

  init() {
    if (this.isInitialized) return;
    
    // 检测是否为阿里巴巴页面
    if (!this.isAlibabaPage()) {
      return;
    }

    this.createFloatingWindow();
    this.setupEventListeners();
    this.isInitialized = true;
    
    console.log('阿里巴巴采集器已启动（修复版）');
  }

  isAlibabaPage() {
    const hostname = window.location.hostname;
    return hostname.includes('alibaba.com') || hostname.includes('1688.com');
  }

  createFloatingWindow() {
    // 创建悬浮窗容器
    this.floatingWindow = document.createElement('div');
    this.floatingWindow.id = 'alibaba-collector-window';
    this.floatingWindow.innerHTML = `
      <div class="collector-header">
        <div class="collector-title">🛒 商品采集器</div>
        <button class="collector-minimize" title="最小化">−</button>
      </div>
      
      <div class="collector-body">
        <div class="collector-section">
          <button class="collector-btn collector-btn-primary" id="start-collection">
            🚀 开始采集
          </button>
        </div>

        <div class="collector-section status-section">
          <div class="status-info">
            <div class="status-item">
              <span class="status-label">状态</span>
              <span class="status-value" id="collection-status">就绪</span>
            </div>
            <div class="status-item">
              <span class="status-label">总数</span>
              <span class="status-value" id="total-count">0</span>
            </div>
            <div class="status-item">
              <span class="status-label">成功</span>
              <span class="status-value success" id="success-count">0</span>
            </div>
            <div class="status-item">
              <span class="status-label">失败</span>
              <span class="status-value error" id="failed-count">0</span>
            </div>
          </div>
        </div>

        <div class="collector-section log-section">
          <div class="log-header">📝 采集日志</div>
          <div class="log-content" id="log-content"></div>
        </div>
      </div>
    `;

    document.body.appendChild(this.floatingWindow);
    
    // 设置默认位置
    this.setInitialPosition();
    this.makeDraggable();
    this.setupWindowControls();
  }

  setInitialPosition() {
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;
    
    this.floatingWindow.style.left = (windowWidth - 320) + 'px';
    this.floatingWindow.style.top = (windowHeight - 450) + 'px';
  }

  makeDraggable() {
    const header = this.floatingWindow.querySelector('.collector-header');
    
    // 鼠标事件
    header.addEventListener('mousedown', (e) => this.startDrag(e));
    document.addEventListener('mousemove', (e) => this.drag(e));
    document.addEventListener('mouseup', () => this.endDrag());
    
    // 触摸事件（移动端支持）
    header.addEventListener('touchstart', (e) => this.startDrag(e));
    document.addEventListener('touchmove', (e) => this.drag(e));
    document.addEventListener('touchend', () => this.endDrag());
  }

  startDrag(e) {
    if (e.target.tagName === 'BUTTON') return;
    
    this.isDragging = true;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    
    this.dragOffset = {
      x: clientX - this.floatingWindow.offsetLeft,
      y: clientY - this.floatingWindow.offsetTop
    };
    
    this.floatingWindow.style.cursor = 'move';
    e.preventDefault();
  }

  drag(e) {
    if (!this.isDragging) return;
    
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    
    const newX = clientX - this.dragOffset.x;
    const newY = clientY - this.dragOffset.y;
    
    // 限制在窗口内
    const maxX = window.innerWidth - this.floatingWindow.offsetWidth;
    const maxY = window.innerHeight - this.floatingWindow.offsetHeight;
    
    this.floatingWindow.style.left = Math.max(0, Math.min(newX, maxX)) + 'px';
    this.floatingWindow.style.top = Math.max(0, Math.min(newY, maxY)) + 'px';
  }

  endDrag() {
    this.isDragging = false;
    this.floatingWindow.style.cursor = 'default';
  }

  setupWindowControls() {
    const minimizeBtn = this.floatingWindow.querySelector('.collector-minimize');
    const body = this.floatingWindow.querySelector('.collector-body');
    let isMinimized = false;
    
    minimizeBtn.addEventListener('click', () => {
      isMinimized = !isMinimized;
      body.style.display = isMinimized ? 'none' : 'block';
      minimizeBtn.textContent = isMinimized ? '+' : '−';
    });
  }

  setupEventListeners() {
    const startBtn = this.floatingWindow.querySelector('#start-collection');
    startBtn.addEventListener('click', () => this.startCollection());
  }

  async startCollection() {
    if (this.isProcessing) {
      this.log('⚠️ 正在采集中，请稍候...', 'warning');
      return;
    }

    this.log('🚀 开始采集商品信息...', 'info');
    this.updateStatus('collecting');
    this.isProcessing = true;

    try {
      const productData = await this.collectProductData();
      
      if (productData) {
        this.log('📤 正在上传到OSS...', 'info');
        const uploadResult = await this.uploadToOSS(productData);
        
        if (uploadResult.success) {
          this.log('✅ 采集成功！', 'success');
          this.collectionStats.success++;
          this.updateStats();
          
          // 🚀 自动生成SEO页面
          this.log('🌐 正在生成SEO页面...', 'info');
          try {
            const seoResult = await this.uploadSEOToGitHub(productData);
            if (seoResult.success) {
              this.log('✅ SEO页面上传成功！', 'success');
            } else {
              this.log('⚠️ SEO上传失败: ' + seoResult.error, 'warning');
            }
          } catch (e) {
            this.log('⚠️ SEO生成失败: ' + e.message, 'warning');
          }
          
          // 显示采集结果摘要
          this.showCollectionSummary(productData);
        } else {
          throw new Error(uploadResult.error || '上传失败');
        }
      }
    } catch (error) {
      this.log(`❌ 采集失败: ${error.message}`, 'error');
      this.errorMessages.push(error.message);
      this.collectionStats.failed++;
      this.updateStats();
    } finally {
      this.isProcessing = false;
      this.updateStatus('idle');
      this.updateStats();
      this.log('🏁 采集完成', 'info');
    }
  }

  isProductDetailPage() {
    // 检查是否为商品详情页
    const url = window.location.href;
    return url.includes('/product-detail/') || url.includes('/product/');
  }

  async collectProductData() {
    this.log('📖 正在分析页面结构...', 'info');

    const productData = {
      url: window.location.href,
      title: '',
      oemCodes: [],
      images: [],
      fitment: null,
      hasFitment: false,
      collectedAt: new Date().toISOString()
    };

    try {
      // 1. 采集标题
      productData.title = this.extractTitle();
      if (!productData.title) {
        throw new Error('无法提取商品标题');
      }
      this.log(`📌 标题: ${productData.title.substring(0, 50)}...`, 'info');

      // 2. 提取OEM编码
      productData.oemCodes = this.extractOEMCodes(productData.title);
      if (productData.oemCodes.length > 0) {
        this.log(`🔢 OEM编码: ${productData.oemCodes.join(', ')}`, 'info');
      } else {
        this.log('⚠️ 未找到OEM编码', 'warning');
      }

      // 3. 采集主图（修复版）
      productData.images = this.extractImages();
      if (productData.images.length === 0) {
        throw new Error('无法提取商品图片');
      }
      this.log(`🖼️ 采集到 ${productData.images.length} 张图片`, 'info');

      // 4. 检查并采集车型适配表
      const fitmentData = this.extractFitmentTable();
      if (fitmentData) {
        productData.fitment = fitmentData;
        productData.hasFitment = true;
        this.log(`🚗 采集到 ${fitmentData.length} 条车型适配信息`, 'info');
      } else {
        productData.fitment = null;
        productData.hasFitment = false;
        this.log('ℹ️ 该商品无车型适配表', 'info');
      }

      // 5. 生成SEO数据
      const seoData = this.generateSEOData(productData);
      Object.assign(productData, seoData);

      return productData;

    } catch (error) {
      this.log(`❌ 数据采集失败: ${error.message}`, 'error');
      console.error('数据采集失败:', error);
      throw error;
    }
  }

  extractTitle() {
    // 多个选择器备选
    const titleSelectors = [
      'h1.product-title',
      'h1.pdp-title',
      'h1.detail-title',
      'h1.product-name',
      '.module-pdp-title h1',
      '.product-title-text',
      '[class*="title"] h1',
      'h1'
    ];

    for (const selector of titleSelectors) {
      const element = document.querySelector(selector);
      if (element && element.textContent.trim()) {
        return element.textContent.trim();
      }
    }

    return document.title.replace(' - Alibaba.com', '').trim();
  }

  extractOEMCodes(title) {
    // 改进的OEM编码提取模式
    const oemPatterns = [
      /\b\d{4,}-[0-9A-Z]{3,}\b/g,           // 23390-0L040 格式
      /\b[0-9A-Z]{4,}-[0-9A-Z]{3,}\b/g,     // 5333881-11040206 格式
      /\b\d{8,}\b/g,                        // 纯数字8位以上
      /\b[0-9A-Z]{6,}\b/g                   // 纯字母数字6位以上
    ];

    const oemCodes = new Set();
    
    oemPatterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(title)) !== null) {
        const code = match[0];
        if (code.length >= 6 && code.length <= 20) {  // OEM编码通常在6-20位之间
          oemCodes.add(code);
        }
      }
    });

    return Array.from(oemCodes);
  }

  extractImages() {
    const images = [];
    const maxImages = 6;

    this.log('🔍 开始查找商品图片...', 'info');

    // 方案1：查找主图区域容器
    const mainSelectors = [
      '[role="group"][aria-roledescription="slide"]',
      '.module_productImage',
      '.current-main-image'
    ];

    for (const selector of mainSelectors) {
      const container = document.querySelector(selector);
      if (!container) continue;
      
      const imgs = container.querySelectorAll('img');
      this.log(`📷 "${selector}" 找到 ${imgs.length} 张图片`, 'info');
      
      imgs.forEach((img) => {
        if (images.length >= maxImages) return;
        
        let imageUrl = img.src || img.getAttribute('data-src');
        if (!imageUrl) return;
        
        // 只处理产品图片
        if (!imageUrl.includes('@sc04') && !imageUrl.includes('@sc01')) return;
        
        // 转换高清图：去掉 _960x960q80.格式后缀，保留原始扩展名
        // 例如: xxx.jpg_960x960q80.jpg -> xxx.jpg
        // 例如: xxx.png_960x960q80.jpg -> xxx.png
        imageUrl = imageUrl.replace(/_960x960q80\.(jpe?g|png|gif|webp)$/i, '');
        
        if (this.isValidProductImage(imageUrl) && !images.includes(imageUrl)) {
          images.push(imageUrl);
          this.log(`✅ 图片${images.length}`, 'info');
        }
      });
      
      if (images.length >= 3) return images;
    }

    // 方案2：直接找960x960产品图
    document.querySelectorAll('img').forEach((img) => {
      if (images.length >= maxImages) return;
      
      let imageUrl = img.src;
      if (!imageUrl) return;
      
      if (imageUrl.includes('_960x960q80') && (imageUrl.includes('@sc04') || imageUrl.includes('@sc01'))) {
        imageUrl = imageUrl.replace(/_960x960q80\.(jpe?g|png|gif|webp)$/i, '');
        
        if (!images.includes(imageUrl)) {
          images.push(imageUrl);
        }
      }
    });

    this.log(`🖼️ 采集到 ${images.length} 张图片`, 'info');
    return images;
  }

  // 检查是否为有效的产品图片URL
  isValidProductImage(url) {
    if (!url) return false;
    const lowerUrl = url.toLowerCase();
    
    // 必须在alicdn.com域名
    if (!lowerUrl.includes('alicdn.com')) return false;
    
    // 排除缩略图（太小的）
    if (lowerUrl.includes('_50x50') || lowerUrl.includes('_100x100')) return false;
    
    // 排除明显不是产品的图片
    const excludePatterns = [
      'logo', 'icon', 'banner', 'avatar', 'user', 'profile', 'tracking',
      // 排除客服系统、支付相关
      'customer', 'service', 'chat', 'payment', 'alipay', 'wechat', 'qrcode',
      'inquiry', 'contact', 'support', 'help'
    ];
    for (const pattern of excludePatterns) {
      if (lowerUrl.includes(pattern)) return false;
    }
    
    return true;
  }

  // 检查是否为阿里云CDN产品图片（排除缩略图）
  isAlicdnProductImage(url) {
    if (!url) return false;
    const lowerUrl = url.toLowerCase();
    
    // 必须是alicdn.com或img.alicdn.com
    if (!lowerUrl.includes('alicdn.com')) return false;
    
    // 排除UI元素路径（非产品图片）
    const excludePaths = ['/tfs/', '/ata-src/', '/imgextra/', '/tps/'];
    for (const path of excludePaths) {
      if (lowerUrl.includes(path)) return false;
    }
    
    // 必须包含产品图片特征路径
    const productPaths = ['/@sc', '/@img/', '/kf/', '/product/'];
    let hasProductPath = false;
    for (const path of productPaths) {
      if (lowerUrl.includes(path)) {
        hasProductPath = true;
        break;
      }
    }
    if (!hasProductPath) return false;
    
    // 排除缩略图特征
    if (lowerUrl.match(/_[0-9]+x[0-9]+\./)) {
      // 检查是否是太小的缩略图
      const match = lowerUrl.match(/_(\d+)x(\d+)\./);
      if (match) {
        const width = parseInt(match[1]);
        if (width < 200) return false;
      }
    }
    
    return true;
  }

  // 获取高清图片URL
  getHighResImageUrl(img) {
    let url = img.src || img.getAttribute('data-src') || img.getAttribute('data-original') || img.getAttribute('data-image') || img.getAttribute('data-zoom-image');
    
    if (!url) return null;

    // 转换缩略图为高清版本 - 阿里巴巴格式处理
    // 例如: https://s.alicdn.com/@sc04/kf/HxxxL.jpg_960x960q80.jpg -> https://s.alicdn.com/@sc04/kf/HxxxL.jpg
    // 先处理 _960x960q80.jpg 格式（最常见）
    url = url.replace(/_960x960q80\.jpg$/, '.jpg');
    url = url.replace(/_960x960q80\.png$/, '.png');
    url = url.replace(/_960x960q80\.jpeg$/, '.jpeg');
    
    // 处理其他尺寸格式 _数字x数字q数字.
    url = url.replace(/_[0-9]+x[0-9]+q[0-9]+\.(\w+)$/, '.$1');
    
    // 移除旧的尺寸后缀格式 _数字x数字.
    url = url.replace(/_[0-9]+x[0-9]+\./, '.');
    
    return url;
  }

  isLikelyProductImage(img, url) {
    // 检查是否可能是产品图片
    const src = url.toLowerCase();
    const alt = (img.alt || '').toLowerCase();
    
    // 排除明显不是产品图片的
    const excludePatterns = [
      'logo', 'icon', 'banner', 'ad', 'advertisement', 'tracking',
      'pixel', 'spacer', 'background', 'header', 'footer', 'nav',
      'avatar', 'user', 'profile', 'social'
    ];
    
    for (const pattern of excludePatterns) {
      if (src.includes(pattern) || alt.includes(pattern)) {
        return false;
      }
    }
    
    // 检查图片尺寸（产品图片通常比较大）
    const width = img.width || img.naturalWidth || 0;
    const height = img.height || img.naturalHeight || 0;
    
    if (width > 200 && height > 200) {
      return true;
    }
    
    // 检查URL特征
    const productPatterns = [
      'product', 'item', 'detail', 'pdp', 'gallery', 'image',
      'photo', 'picture', 'thumb', 'view'
    ];
    
    return productPatterns.some(pattern => src.includes(pattern));
  }

  getImageUrl(img) {
    // 获取图片URL，优先使用高清版本
    let url = img.src || img.getAttribute('data-src') || img.getAttribute('data-original');
    
    if (!url) {
      return null;
    }

    // 将低质量URL转换为高质量URL（如果可能）
    if (url.includes('_640x640.')) {
      url = url.replace('_640x640.', '_1000x1000.');
    } else if (url.includes('_480x480.')) {
      url = url.replace('_480x480.', '_1000x1000.');
    }

    return url;
  }

  hasLogoImage(img) {
    // 检查图片是否包含logo
    const src = img.src || img.getAttribute('data-src') || '';
    const alt = img.alt || '';
    const title = img.title || '';
    const className = img.className || '';

    const logoKeywords = ['logo', 'brand', 'watermark', 'trademark'];
    const combinedText = (src + alt + title + className).toLowerCase();

    return logoKeywords.some(keyword => combinedText.includes(keyword));
  }

  extractFitmentTable() {
    // 修复：基于实际阿里巴巴页面结构的车型适配表选择器
    // 支持电脑端和移动端Kiwi浏览器
    const tableSelectors = [
      // 官方属性选择器（最优先）
      '[data-testid*="compatible"] table',
      '[data-testid*="fitment"] table',
      '[data-testid*="vehicle"] table',
      // 电脑端选择器
      'table.compatible-vehicles-table',
      'table[data-role="compatible-vehicles"]',
      '.compatible-vehicles-section table',
      '.fitment-details table',
      '#compatible-vehicles table',
      '.vehicle-compatibility table',
      '.product-fitment table',
      // 通用选择器
      'table.fitment-table',
      'table.compatibility-table',
      '[class*="compatible"] table',
      '[class*="fitment"] table',
      '[class*="vehicle"] table',
      '[id*="compatible"] table',
      '[id*="fitment"] table',
      // 移动端Kiwi可能使用的选择器
      '.module-compatible table',
      '.module-fitment table',
      '.detail-table table',
      '.info-table table',
      // 最后备用方案：扫描所有表格
      'table'
    ];

    let fitmentTable = null;
    for (const selector of tableSelectors) {
      try {
        fitmentTable = document.querySelector(selector);
        if (fitmentTable) {
          // 验证表格是否包含车型适配数据
          const tableText = fitmentTable.textContent.toLowerCase();
          if (tableText.includes('make') || tableText.includes('model') || tableText.includes('year')) {
            this.log(`✅ 找到车型适配表，使用选择器: ${selector}`, 'debug');
            break;
          }
        }
      } catch (e) {
        continue;
      }
    }

    if (!fitmentTable) {
      this.log('ℹ️ 未找到车型适配表', 'info');
      return null;
    }

    // 提取表格数据
    const fitmentData = [];
    const rows = fitmentTable.querySelectorAll('tr');

    this.log(`📊 找到 ${rows.length} 行数据`, 'debug');

    rows.forEach((row, index) => {
      const cells = row.querySelectorAll('td, th');
      if (cells.length >= 3) {
        const make = cells[0].textContent.trim();
        const model = cells[1].textContent.trim();
        const year = cells[2].textContent.trim();
        const engine = cells[3] ? cells[3].textContent.trim() : '';

        // 跳过表头行和空行
        if (make.toLowerCase() !== 'make' &&
            model.toLowerCase() !== 'model' &&
            make && model) {
          fitmentData.push({
            make: make,
            model: model,
            year: year,
            engine: engine
          });
        }
      }
    });

    if (fitmentData.length > 0) {
      this.log(`🚗 成功提取 ${fitmentData.length} 条车型适配信息`, 'info');
      return fitmentData;
    } else {
      this.log('⚠️ 表格存在但未提取到有效数据', 'warning');
      return null;
    }
  }

  generateSEOData(productData) {
    // 品牌识别
    const brand = this.identifyBrand(productData.title);
    
    // SEO标题 (60字符内)
    productData.seoTitle = this.truncateText(
      `${brand} ${productData.title.split(' ')[0]} ${productData.oemCodes[0] || ''}`,
      60
    );

    // SEO描述 (155字符内)
    productData.seoDescription = this.truncateText(
      `${brand} ${productData.title.substring(0, 80)}，OEM: ${productData.oemCodes.join(', ')}`,
      155
    );

    // SEO关键词
    productData.seoKeywords = [
      brand,
      ...productData.oemCodes,
      ...this.extractKeywords(productData.title)
    ];

    // URL友好标题
    productData.urlSlug = this.createUrlSlug(productData.title);

    // 图片Alt文本
    productData.imageAltText = `${brand} ${productData.title}`;

    // H1/H2标题
    productData.h1Title = productData.title;
    productData.h2Title = `${brand} ${productData.oemCodes.join(' ')}`;

    return productData;
  }

  identifyBrand(title) {
    const titleLower = title.toLowerCase();
    const brandMap = {
      // 美系
      'ford': 'Ford', 'chevrolet': 'Chevrolet', 'dodge': 'Dodge',
      // 欧系  
      'volkswagen': 'Volkswagen', 'bmw': 'BMW', 'mercedes': 'Mercedes-Benz',
      'audi': 'Audi', 'volvo': 'Volvo',
      // 日系
      'toyota': 'Toyota', 'honda': 'Honda', 'nissan': 'Nissan',
      'mazda': 'Mazda', 'subaru': 'Subaru',
      // 韩系
      'hyundai': 'Hyundai', 'kia': 'Kia',
      // 中国品牌
      'chery': 'Chery', 'geely': 'Geely', 'byd': 'BYD', 'haval': 'Haval'
    };

    for (const [keyword, brand] of Object.entries(brandMap)) {
      if (titleLower.includes(keyword)) {
        return brand;
      }
    }

    return 'Universal';
  }

  extractKeywords(title) {
    // 提取关键词
    const stopWords = ['for', 'and', 'the', 'with', 'high', 'quality', 'new', 'genuine'];
    const words = title.split(/\s+/).filter(word => 
      word.length > 2 && !stopWords.includes(word.toLowerCase())
    );
    return words.slice(0, 5);
  }

  createUrlSlug(title) {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '')
      .substring(0, 100);
  }

  truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength - 3) + '...';
  }

  async uploadToOSS(productData) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({
        action: 'uploadToOSS',
        data: productData
      }, (response) => {
        resolve(response || { success: false, error: '无响应' });
      });
    });
  }
  
  async uploadSEOToGitHub(productData) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({
        action: 'uploadSEOToGitHub',
        data: productData
      }, (response) => {
        resolve(response || { success: false, error: '无响应' });
      });
    });
  }

  updateStatus(status) {
    const statusElement = this.floatingWindow.querySelector('#collection-status');
    const statusMap = {
      'idle': '就绪',
      'collecting': '采集中',
      'uploading': '上传中',
      'success': '成功',
      'error': '失败'
    };
    statusElement.textContent = statusMap[status] || status;
  }

  updateStats() {
    this.floatingWindow.querySelector('#total-count').textContent = this.collectionStats.total;
    this.floatingWindow.querySelector('#success-count').textContent = this.collectionStats.success;
    this.floatingWindow.querySelector('#failed-count').textContent = this.collectionStats.failed;
    this.collectionStats.total = this.collectionStats.success + this.collectionStats.failed;
  }

  log(message, type = 'info') {
    const logContent = this.floatingWindow.querySelector('#log-content');
    const logEntry = document.createElement('div');
    logEntry.className = `log-entry log-${type}`;
    
    const timestamp = new Date().toLocaleTimeString();
    logEntry.innerHTML = `<span class="log-time">[${timestamp}]</span> ${message}`;
    
    logContent.appendChild(logEntry);
    logContent.scrollTop = logContent.scrollHeight;

    // 限制日志条数
    while (logContent.children.length > 50) {
      logContent.removeChild(logContent.firstChild);
    }
  }

  showCollectionSummary(productData) {
    const summary = `
📊 采集摘要:
📌 标题: ${productData.title.substring(0, 40)}...
🔢 OEM编码: ${productData.oemCodes.join(', ') || '无'}
🖼️ 图片数量: ${productData.images.length}
🚗 车型适配: ${productData.hasFitment ? productData.fitment.length + ' 条' : '无'}
📅 采集时间: ${new Date().toLocaleString()}
    `;
    this.log(summary, 'info');
  }
}

// 启动采集器
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => new AlibabaCollector());
} else {
  new AlibabaCollector();
}