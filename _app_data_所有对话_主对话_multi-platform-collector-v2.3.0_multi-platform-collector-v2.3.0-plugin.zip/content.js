// 多平台汽配商品采集器 - 内容脚本（v2.0.0）
// 支持: Alibaba/1688, eBay, Amazon
// 完整流程: 采集 -> OSS上传 -> SEO生成 -> 前台/后台同步

class MultiPlatformCollector {
  constructor() {
    this.isInitialized = false;
    this.floatingWindow = null;
    this.isDragging = false;
    this.dragOffset = { x: 0, y: 0 };
    this.collectionStats = { total: 0, success: 0, failed: 0, inProgress: 0 };
    this.errorMessages = [];
    this.isProcessing = false;
    this.currentPlatform = this.detectPlatform();
    this.loadProgress();
    this.init();
  }
  
  detectPlatform() {
    const hostname = window.location.hostname.toLowerCase();
    if (hostname.includes('alibaba.com') || hostname.includes('1688.com')) return 'alibaba';
    else if (hostname.includes('ebay.com')) return 'ebay';
    else if (hostname.includes('amazon.')) return 'amazon';
    return 'unknown';
  }
  
  loadProgress() {
    try {
      const saved = localStorage.getItem('multi_collector_progress');
      if (saved) {
        const progress = JSON.parse(saved);
        this.collectionStats.success = progress.successCount || 0;
        this.collectionStats.failed = progress.failedCount || 0;
      }
    } catch (e) {}
  }

  saveProgress() {
    try {
      localStorage.setItem('multi_collector_progress', JSON.stringify({
        successCount: this.collectionStats.success,
        failedCount: this.collectionStats.failed,
        lastUpdate: new Date().toISOString()
      }));
    } catch (e) {}
  }

  init() {
    if (this.isInitialized || this.currentPlatform === 'unknown') return;
    this.createFloatingWindow();
    this.setupEventListeners();
    this.isInitialized = true;
    console.log(`✅ ${this.getPlatformName()} 采集器已启动`);
  }

  getPlatformName() {
    return { alibaba: '阿里巴巴/1688', ebay: 'eBay', amazon: 'Amazon' }[this.currentPlatform] || '未知';
  }

  getPlatformBadge() {
    return { alibaba: '🏭', ebay: '🚗', amazon: '📦' }[this.currentPlatform] || '🌐';
  }

  createFloatingWindow() {
    this.floatingWindow = document.createElement('div');
    this.floatingWindow.id = 'multi-platform-collector-window';
    // 确保悬浮窗可见
    this.floatingWindow.style.cssText = 'position: fixed !important; z-index: 2147483647 !important; visibility: visible !important; display: block !important;';
    this.floatingWindow.innerHTML = `
      <div class="collector-header">
        <div class="collector-title">🛒 ${this.getPlatformBadge()} 商品采集器</div>
        <button class="collector-minimize">−</button>
      </div>
      <div class="collector-body">
        <div class="platform-info">当前平台: <strong>${this.getPlatformName()}</strong></div>
        <div class="collector-section">
          <button class="collector-btn collector-btn-primary" id="start-collection">🚀 开始采集</button>
        </div>
        <div class="collector-section status-section">
          <div class="status-info">
            <div class="status-item"><span class="status-label">状态</span><span class="status-value" id="collection-status">就绪</span></div>
            <div class="status-item"><span class="status-label">总数</span><span class="status-value" id="total-count">0</span></div>
            <div class="status-item"><span class="status-label">成功</span><span class="status-value success" id="success-count">0</span></div>
            <div class="status-item"><span class="status-label">失败</span><span class="status-value error" id="failed-count">0</span></div>
          </div>
        </div>
        <div class="collector-section log-section">
          <div class="log-header">📝 采集日志</div>
          <div class="log-content" id="log-content"></div>
        </div>
      </div>
    `;
    document.body.appendChild(this.floatingWindow);
    this.setInitialPosition();
    this.makeDraggable();
    this.setupWindowControls();
  }

  setInitialPosition() {
    this.floatingWindow.style.left = (window.innerWidth - 320) + 'px';
    this.floatingWindow.style.top = (window.innerHeight - 450) + 'px';
  }

  makeDraggable() {
    const header = this.floatingWindow.querySelector('.collector-header');
    const onMove = (x, y) => {
      this.floatingWindow.style.left = (x - this.dragOffset.x) + 'px';
      this.floatingWindow.style.top = (y - this.dragOffset.y) + 'px';
    };
    // 鼠标事件
    header.addEventListener('mousedown', (e) => { 
      if (e.target.tagName !== 'BUTTON') { 
        this.isDragging = true; 
        this.dragOffset = { x: e.clientX - this.floatingWindow.offsetLeft, y: e.clientY - this.floatingWindow.offsetTop }; 
      } 
    });
    document.addEventListener('mousemove', (e) => { if (this.isDragging) onMove(e.clientX, e.clientY); });
    document.addEventListener('mouseup', () => this.isDragging = false);
    // 触摸事件（移动端）
    header.addEventListener('touchstart', (e) => { 
      if (e.target.tagName !== 'BUTTON') { 
        this.isDragging = true; 
        const touch = e.touches[0];
        this.dragOffset = { x: touch.clientX - this.floatingWindow.offsetLeft, y: touch.clientY - this.floatingWindow.offsetTop }; 
      } 
    }, { passive: true });
    header.addEventListener('touchmove', (e) => { 
      if (this.isDragging) { 
        const touch = e.touches[0];
        onMove(touch.clientX, touch.clientY);
      } 
    }, { passive: true });
    header.addEventListener('touchend', () => this.isDragging = false);
  }

  setupWindowControls() {
    let minimized = false;
    this.floatingWindow.querySelector('.collector-minimize').addEventListener('click', () => {
      minimized = !minimized;
      this.floatingWindow.querySelector('.collector-body').style.display = minimized ? 'none' : 'block';
    });
  }

  setupEventListeners() {
    this.floatingWindow.querySelector('#start-collection').addEventListener('click', () => this.startCollection());
  }

  log(message, type = 'info') {
    const logContent = this.floatingWindow.querySelector('#log-content');
    const entry = document.createElement('div');
    entry.className = `log-entry log-${type}`;
    entry.innerHTML = `<span class="log-time">[${new Date().toLocaleTimeString()}]</span> ${message}`;
    logContent.appendChild(entry);
    logContent.scrollTop = logContent.scrollHeight;
    while (logContent.children.length > 50) logContent.removeChild(logContent.firstChild);
  }

  updateStatus(status) {
    const map = { idle: '就绪', collecting: '采集中...', uploading: '上传中...', seopage: '生成SEO...', success: '成功', error: '失败' };
    this.floatingWindow.querySelector('#collection-status').textContent = map[status] || status;
  }

  updateStats() {
    this.collectionStats.total = this.collectionStats.success + this.collectionStats.failed;
    this.floatingWindow.querySelector('#success-count').textContent = this.collectionStats.success;
    this.floatingWindow.querySelector('#failed-count').textContent = this.collectionStats.failed;
    this.floatingWindow.querySelector('#total-count').textContent = this.collectionStats.total;
  }

  async startCollection() {
    if (this.isProcessing) { this.log('⚠️ 正在采集中，请稍候...', 'warning'); return; }
    this.log(`🚀 开始采集 ${this.getPlatformName()} 商品信息...`, 'info');
    this.updateStatus('collecting');
    this.isProcessing = true;
    this.collectionStats.total++;

    try {
      const productData = await this.collectProductData();
      if (productData) {
        this.log('📤 正在上传到OSS...', 'info');
        this.updateStatus('uploading');
        const uploadResult = await this.uploadToOSS(productData);
        
        if (uploadResult.success) {
          this.log('✅ OSS上传成功！', 'success');
          this.log('🌐 正在生成SEO页面...', 'info');
          this.updateStatus('seopage');
          try {
            const seoResult = await this.uploadSEOToGitHub(productData);
            if (seoResult.success) this.log('✅ SEO页面上传成功！', 'success');
            else this.log('⚠️ SEO上传失败', 'warning');
          } catch (e) { this.log('⚠️ SEO生成失败', 'warning'); }
          
          this.collectionStats.success++;
          this.updateStatus('success');
          this.showCollectionSummary(productData);
          this.saveProgress();
          this.log('⏱️ 等待10秒...', 'info');
          await new Promise(r => setTimeout(r, 10000));
        } else {
          throw new Error(uploadResult.error || '上传失败');
        }
      }
    } catch (error) {
      this.log(`❌ 采集失败: ${error.message}`, 'error');
      this.collectionStats.failed++;
      this.updateStatus('error');
    } finally {
      this.isProcessing = false;
      this.updateStats();
      this.log('🏁 采集完成', 'info');
    }
  }

  async collectProductData() {
    this.log('📖 正在分析页面结构...', 'info');
    const productData = {
      platform: this.currentPlatform,
      url: window.location.href,
      title: '',
      images: [],
      oemCodes: [],
      fitment: null,
      hasFitment: false,
      collectedAt: new Date().toISOString()
    };

    try {
      productData.title = this.extractTitle();
      if (!productData.title) throw new Error('无法提取商品标题');
      this.log(`📌 标题: ${productData.title.substring(0, 50)}...`, 'info');

      productData.images = this.extractImages();
      if (productData.images.length === 0) throw new Error('无法提取商品图片');
      this.log(`🖼️ 采集到 ${productData.images.length} 张图片`, 'info');

      // OEM编码提取
      if (this.currentPlatform === 'alibaba') {
        productData.oemCodes = this.extractOEMFromText(productData.title);
        productData.fitment = this.extractAlibabaFitment();
      } else if (this.currentPlatform === 'ebay') {
        productData.oemCodes = this.extractEbayOEMCodes();
        productData.fitment = this.extractEbayFitment();
      } else if (this.currentPlatform === 'amazon') {
        productData.oemCodes = this.extractAmazonOEMCodes();
        productData.fitment = this.extractAmazonFitment();
      }
      
      if (productData.fitment && productData.fitment.length > 0) {
        productData.hasFitment = true;
        this.log(`🚗 采集到 ${productData.fitment.length} 条车型适配`, 'info');
      }
      if (productData.oemCodes.length > 0) {
        this.log(`🔢 OEM编码: ${productData.oemCodes.join(', ')}`, 'info');
      }

      Object.assign(productData, this.generateSEOData(productData));
      return productData;
    } catch (error) {
      this.log(`❌ 数据采集失败: ${error.message}`, 'error');
      throw error;
    }
  }

  extractTitle() {
    if (this.currentPlatform === 'alibaba') {
      const selectors = ['h1.product-title', 'h1.pdp-title', 'h1.detail-title', 'h1'];
      for (const s of selectors) { const el = document.querySelector(s); if (el?.textContent.trim()) return el.textContent.trim(); }
      return document.title.replace(' - Alibaba.com', '').trim();
    } else if (this.currentPlatform === 'ebay') {
      const selectors = ['h1.x-item-title__mainTitle span[itemprop="name"]', 'h1[itemprop="name"]', '#itemTitle'];
      for (const s of selectors) { const el = document.querySelector(s); if (el?.textContent.trim()) return el.textContent.trim().replace(/^(Title:|Item title:)/i, '').trim(); }
      return document.title.replace(' | eBay', '').trim();
    } else if (this.currentPlatform === 'amazon') {
      const el = document.querySelector('#productTitle');
      if (el?.textContent.trim()) return el.textContent.trim();
      return document.title.split(':')[0].trim();
    }
    return '';
  }

  extractImages() {
    if (this.currentPlatform === 'alibaba') return this.extractAlibabaImages();
    else if (this.currentPlatform === 'ebay') return this.extractEbayImages();
    else if (this.currentPlatform === 'amazon') return this.extractAmazonImages();
    return [];
  }

  extractAlibabaImages() {
    const images = [], maxImages = 6;
    const container = document.querySelector('[role="group"][aria-roledescription="slide"]') || document.querySelector('.module_productImage');
    if (container) {
      container.querySelectorAll('img').forEach(img => {
        if (images.length >= maxImages) return;
        let src = img.src || img.getAttribute('data-src');
        if (src && src.includes('@sc') && src.includes('alicdn.com')) {
          src = src.replace(/_960x960q80\.(jpe?g|png)/i, '');
          if (!images.includes(src)) images.push(src);
        }
      });
    }
    if (images.length === 0) {
      document.querySelectorAll('img').forEach(img => {
        if (images.length >= maxImages) return;
        let src = img.src;
        if (src && src.includes('_960x960q80') && src.includes('@sc')) {
          src = src.replace(/_960x960q80\.(jpe?g|png)/i, '');
          if (!images.includes(src)) images.push(src);
        }
      });
    }
    return images;
  }

  extractEbayImages() {
    const images = [], maxImages = 6;
    
    // 方案1: 直接获取主图 #icImg（eBay产品页的标准主图元素）
    const mainImageEl = document.querySelector('#icImg');
    if (mainImageEl) {
      let src = mainImageEl.getAttribute('data-zoom-image') || 
                 mainImageEl.getAttribute('data-old-hires') || 
                 mainImageEl.src;
      if (src && src.includes('ebayimg.com') && src.includes('/images/g/')) {
        src = src.replace(/s-l\d+/, 's-l1600');
        if (!images.includes(src)) images.push(src);
      }
    }
    
    // 方案2: 查找所有ebayimg产品图（包含/images/g/路径）
    document.querySelectorAll('img').forEach(img => {
      if (images.length >= maxImages) return;
      let src = img.src || img.getAttribute('data-old-hires') || img.getAttribute('data-zoom-image');
      if (!src) return;
      
      // 只处理ebayimg.com的产品图片，排除图标和按钮
      if (src.includes('ebayimg.com') && src.includes('/images/g/')) {
        // 排除太小的图片
        const sizeMatch = src.match(/s-l(\d+)/);
        const size = sizeMatch ? parseInt(sizeMatch[1]) : 0;
        if (size >= 300) {
          src = src.replace(/s-l\d+/, 's-l1600');
          if (!images.includes(src)) images.push(src);
        }
      }
    });
    
    // 方案3: 从carousel/gallery容器获取
    if (images.length === 0) {
      document.querySelectorAll('[class*="carousel"] img, [class*="gallery"] img, .ux-image-carousel-item img').forEach(img => {
        if (images.length >= maxImages) return;
        let src = img.src || img.getAttribute('data-old-hires');
        if (src && src.includes('ebayimg.com') && src.includes('/images/g/')) {
          src = src.replace(/s-l\d+/, 's-l1600');
          if (!images.includes(src)) images.push(src);
        }
      });
    }
    
    return [...new Set(images)].slice(0, maxImages);
  }

  extractAmazonImages() {
    const images = [], maxImages = 6;
    
    // Amazon大图URL转换：把缩略图/中图的URL后缀替换为最大尺寸
    const getLargeUrl = (url) => {
      if (!url) return url;
      // 如果已经是最大尺寸，直接返回
      if (url.includes('_SL1500_')) return url;
      // m.media-amazon.com 格式：_AC_US40_ / _AC_SY355_ 等 → _AC_SL1500_
      return url.replace(/_AC_(?:US\d+|SY\d+|SX\d+|SYRC_\d+)_/i, '_AC_SL1500_')
                 .replace(/_AC_(\w+),/i, '_AC_$1,');
    };
    
    // 1. 主图
    const mainImg = document.querySelector('#landingImage');
    if (mainImg) {
      let src = mainImg.src;
      src = getLargeUrl(src);
      if (src && !images.includes(src)) images.push(src);
    }
    
    // 2. 缩略图区
    const altBlock = document.querySelector('#altImages');
    if (altBlock) {
      altBlock.querySelectorAll('img').forEach(img => {
        if (images.length >= maxImages) return;
        let src = getLargeUrl(img.src);
        if (src && src.includes('amazon.com') && !images.includes(src)) {
          images.push(src);
        }
      });
    }
    
    return images;
  }

  extractEbayOEMCodes() {
    const codes = new Set();
    document.querySelectorAll('.ux-labels-values__values, .item-specifics__value').forEach(el => {
      const text = el.textContent;
      if (text.match(/^(OEM|P\/N|Part Number|OE)/i)) {
        this.extractOEMFromText(text).forEach(c => codes.add(c));
      }
    });
    return Array.from(codes).slice(0, 10);
  }

  extractAmazonOEMCodes() {
    const codes = new Set();
    document.querySelectorAll('#productDetails_detailBullets_sections1 li, #prodDetails tr').forEach(el => {
      const text = el.textContent;
      if (text.match(/(OEM|Part Number|Model Number)/i)) {
        this.extractOEMFromText(text).forEach(c => codes.add(c));
      }
    });
    return Array.from(codes).slice(0, 10);
  }

  extractOEMFromText(text) {
    if (!text) return [];
    const codes = new Set();
    const patterns = [/\b(\d{4,}[-\s][A-Z0-9]{3,})\b/g, /\b([A-Z]{2,}\d{4,})\b/g, /\b(\d{8,})\b/g, /\b(OEM[:\s]*)([A-Z0-9\-]+)/gi, /\b(P\/N[:\s]*)([A-Z0-9\-]+)/gi];
    patterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        const code = (match[2] || match[1]).trim().toUpperCase();
        if (code.length >= 4 && code.length <= 25) codes.add(code);
      }
    });
    return Array.from(codes);
  }

  extractEbayFitment() {
    const fitment = [];
    document.querySelectorAll('.cbt-parts-compatibility tr, .compatibility-section tr').forEach(row => {
      const cells = row.querySelectorAll('td');
      if (cells.length >= 3) {
        const make = cells[0]?.textContent?.trim();
        const model = cells[1]?.textContent?.trim();
        const year = cells[2]?.textContent?.trim();
        if (make && model) fitment.push({ make, model, year: year || '' });
      }
    });
    return fitment.slice(0, 50);
  }

  extractAmazonFitment() {
    const fitment = [];
    document.querySelectorAll('.a-section .a-text-left, #rhf .a-spacing-small').forEach(el => {
      const text = el.textContent || '';
      if (text.toLowerCase().includes('fit')) {
        text.split(/[\n,]/).forEach(part => {
          const t = part.trim();
          if (t.length > 2 && t.length < 50) fitment.push({ make: t, model: '', year: '' });
        });
      }
    });
    return fitment.slice(0, 50);
  }

  extractAlibabaFitment() {
    const fitment = [];
    document.querySelectorAll('.fitment-table tr, .product-specs tr').forEach(row => {
      const cells = row.querySelectorAll('td');
      if (cells.length >= 2) {
        const text = cells[0]?.textContent?.trim();
        if (text && text.length < 50) fitment.push({ make: text, model: '', year: '' });
      }
    });
    return fitment.slice(0, 50);
  }

  generateSEOData(productData) {
    const brand = this.identifyBrand(productData.title);
    return {
      seoTitle: this.truncate(`${brand} ${productData.title.split(' ')[0]} ${productData.oemCodes[0] || ''}`, 60),
      seoDescription: this.truncate(`${brand} ${productData.title.substring(0, 80)} OEM: ${productData.oemCodes.join(', ')}`, 155),
      seoKeywords: [brand, ...productData.oemCodes.slice(0, 5)],
      urlSlug: productData.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').substring(0, 100),
      imageAltText: `${brand} ${productData.title}`,
      h1Title: productData.title,
      h2Title: `${brand} ${productData.oemCodes.join(' ')}`
    };
  }

  identifyBrand(title) {
    const lower = title.toLowerCase();
    const brands = { toyota: 'Toyota', honda: 'Honda', nissan: 'Nissan', bmw: 'BMW', mercedes: 'Mercedes-Benz', audi: 'Audi', ford: 'Ford', chevrolet: 'Chevrolet', hyundai: 'Hyundai', kia: 'Kia', byd: 'BYD' };
    for (const [k, v] of Object.entries(brands)) { if (lower.includes(k)) return v; }
    return 'Auto Parts';
  }

  truncate(text, len) { return text.length <= len ? text : text.substring(0, len - 3) + '...'; }

  async uploadToOSS(productData) {
    return new Promise(r => chrome.runtime.sendMessage({ action: 'uploadToOSS', data: productData }, res => r(res || { success: false })));
  }
  
  async uploadSEOToGitHub(productData) {
    return new Promise(r => chrome.runtime.sendMessage({ action: 'uploadSEOToGitHub', data: productData }, res => r(res || { success: false })));
  }

  showCollectionSummary(productData) {
    this.log('━━━━━━━━━━━━━━━', 'info');
    this.log(`平台: ${this.getPlatformName()}`, 'info');
    this.log(`标题: ${productData.title.substring(0, 40)}...`, 'info');
    this.log(`图片数: ${productData.images.length}`, 'info');
    if (productData.oemCodes.length > 0) this.log(`OEM: ${productData.oemCodes.slice(0, 3).join(', ')}`, 'info');
    if (productData.hasFitment) this.log(`车型: ${productData.fitment.length}条`, 'info');
    this.log('━━━━━━━━━━━━━━━', 'info');
  }
}

// 启动采集器
function initCollector() {
  try {
    new MultiPlatformCollector();
  } catch (e) {
    console.error('采集器初始化失败:', e);
  }
}

// 延迟启动，等待页面完全加载
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => setTimeout(initCollector, 1000));
} else {
  setTimeout(initCollector, 1000);
}
