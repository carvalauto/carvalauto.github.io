// Alibaba商品采集器 - 后台脚本（完全嵌入式配置版本 - 修复版）
// 修复内容：
// 1. 修复OSS签名算法 - 使用正确的HMAC-SHA1
// 2. 修复sender未定义错误
// 3. 增强错误处理

// 导入嵌入式配置
const EMBEDDED_CONFIG = {
  oss: {
    region: 'oss-cn-hangzhou',
    bucket: 'carvalauto-products',
    accessKeyId: 'LTAI5t6J7yx17mKc8psEdqFp',
    accessKeySecret: 'uXIGY7vhf62Ep1Hjj9MtgkKLKq6LTo',
    directory: 'products/',
    endpoint: 'https://carvalauto-products.oss-cn-hangzhou.aliyuncs.com',
    productsUrl: 'https://carvalauto-products.oss-cn-hangzhou.aliyuncs.com/products.json'
  },
  website: {
    domain: 'https://carvalautopart.com',
    adminPage: 'https://carvalautopart.com/admin.html',
    productPage: 'https://carvalautopart.com/product.html'
  },
  github: {
    username: 'carvalauto',
    repository: 'carvalauto.github.io',
    branch: 'main',
    domain: 'https://carvalautopart.com',
    // 多Token轮换配置
    tokens: [
      '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',
      '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',
      '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',
      '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',
      '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'
    ],
    currentTokenIndex: 0,  // 当前使用的Token索引
    lastTokenResetTime: Date.now(),  // 上次重置Token时间
    requestsThisHour: 0  // 当前小时请求数
  },
  analytics: {
    trackingId: '529242507',
    enabled: true
  },
  collection: {
    collectImages: true,
    collectFitment: true,
    skipLogoImages: true,
    autoSEO: true,
    retryCount: 3,
    timeoutSeconds: 120,
    maxImages: 6
  }
};


// ========== v4-gen_2imgs: 15-category content table ==========
// Auto-generated from gen_2imgs.py CATEGORY_CONTENT (15 categories × 6 fields each)
// Auto-generated from gen_2imgs.py CATEGORY_CONTENT (v4-gen_2imgs)
// 15 categories: lower_guard, brake, light, oil, body, intake, cooling, suspension, filter, sensor, mirror, electrical, pump, drivetrain, general

const CATEGORY_CONTENT = {
      lower_guard: {
        app_cards: [
          [
            "🛡️ Engine Underbody Protection",
            [
              "Shields engine oil pan from road debris",
              "Protects transmission lower housing",
              "Reduces rock chip damage on long drives",
              "Prevents water splash into engine bay",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Daily city driving over potholes and speed bumps",
              "Highway driving on gravel or rough roads",
              "Light off-road and unpaved surface driving",
              "Winter driving with road salt and slush",
            ],
          ],
          [
            "🔧 Replacement Use Cases",
            [
              "Replacing cracked or broken OEM guard",
              "Restoring factory protection after repair",
              "Insurance claim replacement parts",
              "Wholesale distribution to repair shops",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Dealership parts departments",
              "Independent repair shops and garages",
              "Online auto parts e-commerce platforms",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of a Damaged Lower Engine Guard",
        symptoms_intro: "If you notice any of the following, the lower guard may need replacement:",
        symptoms: [
          "Visible cracks, holes, or broken sections in the plastic guard",
          "Rattling or scraping noises from underneath the engine bay",
          "Lower engine bay temperature in cold weather (loss of aerodynamic shield)",
          "Scraping sounds when driving over speed bumps or steep driveways",
          "Engine oil pan or transmission exposed after losing the guard",
          "Increased road noise inside the cabin during highway driving",
          "Water splashing onto engine components during rain or puddle driving",
        ],
        symptoms_warning: "Don't delay replacement — a missing or damaged lower guard exposes critical engine components to damage that can cost hundreds of dollars to repair.",
        install_time: "25-35 minutes",
        install_skill: "Beginner / DIY",
        install_tools: "Socket wrench, screwdriver, jack & stands",
        install_steps: [
          [
            "Park the vehicle on a level surface",
            "Park on a flat, level surface. Turn off the engine and allow it to cool down completely. Engage the parking brake.",
          ],
          [
            "Raise the front of the vehicle safely",
            "Use a hydraulic jack to lift the front to a comfortable working height. Secure with jack stands on both sides. Never work under a vehicle supported only by a jack.",
          ],
          [
            "Locate and inspect the old lower guard",
            "Locate the existing lower engine guard under the front engine bay. Inspect mounting bolts and plastic clips. Note position of any wiring harnesses or hoses near the guard.",
          ],
          [
            "Remove the old lower guard",
            "Using a socket wrench and screwdriver, remove all mounting bolts and plastic clips. Keep hardware organized for reinstallation. Gently lower and remove the damaged guard.",
          ],
          [
            "Install the new OEM part",
            "Align the new lower guard with the mounting holes. Hand-tighten all bolts and clips first to ensure proper alignment, then torque to manufacturer specification.",
          ],
          [
            "Verify fitment and lower the vehicle",
            "Double-check that the guard is securely mounted, all bolts are torqued, no wires or hoses are pinched. Carefully lower the vehicle. Test drive at low speed to confirm no rattles.",
          ],
        ],
        faq_q1: "What is this OEM part used for?",
        faq_a1: "This is the lower engine guard plate (engine skid plate / underbody shield) that protects the engine bay underside from road debris, rocks, water splashes, and minor impacts. Essential for drivers on rough roads or off-road conditions.",
        related_parts_hint: "Customers who order this lower guard also frequently order these related parts:",
      },
      brake: {
        app_cards: [
          [
            "🛑 Braking Performance",
            [
              "Restores factory braking power",
              "Reduces brake squeal and vibration",
              "Improves pedal feel and response",
              "Ensures even pad wear on both sides",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Daily city stop-and-go traffic",
              "Highway driving with frequent deceleration",
              "Mountain and downhill braking",
              "Heavy-load and towing applications",
            ],
          ],
          [
            "🔧 Replacement Use Cases",
            [
              "Replacing worn OEM brake pads",
              "Restoring braking performance after service",
              "Brake system overhaul projects",
              "Wholesale distribution to repair shops",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Brake service shops and tire centers",
              "Independent repair shops",
              "Fleet maintenance operations",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of Worn Brake Pads / Discs",
        symptoms_intro: "If you notice any of the following, your brake components may need replacement:",
        symptoms: [
          "High-pitched squealing or chirping noise when braking",
          "Grinding or metallic scraping sound during braking",
          "Vibration or pulsation felt in the brake pedal or steering wheel",
          "Longer stopping distances than usual",
          "Brake warning light illuminated on dashboard",
          "Visible thinness of brake pad material below 3mm",
          "Deep grooves or scoring on brake disc surface",
        ],
        symptoms_warning: "Don't ignore brake warning signs — driving with worn brake components can lead to brake failure, rotor damage, and expensive repairs. Replace promptly to maintain safe stopping power.",
        install_time: "45-60 minutes",
        install_skill: "Intermediate",
        install_tools: "Jack, stands, lug wrench, C-clamp, socket set",
        install_steps: [
          [
            "Loosen lug nuts and raise the vehicle",
            "Loosen the lug nuts on the wheel. Use a jack to lift the vehicle and secure with jack stands. Remove the wheel to access the brake assembly.",
          ],
          [
            "Remove the caliper and old pads",
            "Remove the caliper bolts and slide the caliper off the rotor. Support the caliper with wire — never let it hang by the brake hose. Remove the old brake pads.",
          ],
          [
            "Compress the caliper piston",
            "Use a C-clamp or brake piston tool to compress the caliper piston back into the bore. This creates clearance for the new thicker pads. Open the brake fluid reservoir cap to allow fluid expansion.",
          ],
          [
            "Install the new brake pads",
            "Apply brake grease to the back of the new pads at the contact points. Install the new pads into the caliper bracket, ensuring the wear indicator is positioned correctly.",
          ],
          [
            "Reinstall the caliper and wheel",
            "Reinstall the caliper over the new pads and torque the caliper bolts to specification. Reinstall the wheel and hand-tighten the lug nuts.",
          ],
          [
            "Lower the vehicle and bed in the new pads",
            "Lower the vehicle and torque the lug nuts. Pump the brake pedal several times to seat the pads against the rotor. Perform a gradual bedding-in process: 5-10 moderate stops from 50 km/h.",
          ],
        ],
        faq_q1: "When should brake pads / discs be replaced?",
        faq_a1: "Brake pads should be replaced when friction material thickness is below 3mm, or when you notice squealing, reduced braking performance, or vibration. Brake discs typically last 2-3 sets of pads and should be replaced when worn below minimum thickness or scored deeply.",
        related_parts_hint: "Customers who order brake components also frequently order these related parts:",
      },
      light: {
        app_cards: [
          [
            "💡 Lighting Performance",
            [
              "Restores full headlight brightness and beam pattern",
              "Improves night driving visibility and safety",
              "Replaces dim or yellowed original lights",
              "Provides DOT/SAE compliant road-legal lighting",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Night driving on rural or unlit roads",
              "Driving in fog, rain, or snow conditions",
              "Replacing damaged or cracked headlight assemblies",
              "Restoring OEM appearance after collision",
            ],
          ],
          [
            "🔧 Replacement Use Cases",
            [
              "Replacing burned out or dim original lights",
              "Restoring factory lighting performance",
              "Insurance claim replacement parts",
              "Wholesale distribution to body shops",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Body shops and collision repair centers",
              "Independent repair shops",
              "Used car dealers and refurbishers",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of Failing Headlights / Tail Lights",
        symptoms_intro: "If you notice any of the following, your lighting component may need replacement:",
        symptoms: [
          "Dim or significantly reduced light output",
          "Flickering or intermittent operation",
          "Cracked or foggy lens cover",
          "Moisture or condensation inside the lens",
          "One side noticeably dimmer than the other",
          "Warning light on dashboard (for LED-equipped vehicles)",
          "Visible burnt out bulb or damaged wiring",
        ],
        symptoms_warning: "Driving with faulty lighting is both unsafe and illegal in most regions. Replace promptly to maintain visibility and road legality.",
        install_time: "20-40 minutes",
        install_skill: "Beginner / DIY",
        install_tools: "Socket wrench, screwdriver, trim removal tools",
        install_steps: [
          [
            "Disconnect the battery",
            "For safety, disconnect the negative battery terminal before working on electrical components. This prevents short circuits and accidental airbag deployment.",
          ],
          [
            "Access the headlight / tail light assembly",
            "Open the hood (for headlights) or trunk (for tail lights). Remove any trim covers, plastic clips, or screws securing the light assembly.",
          ],
          [
            "Disconnect the electrical connector",
            "Locate the wiring harness connector on the back of the light. Press the release tab and gently pull the connector straight out. Do not pull by the wires.",
          ],
          [
            "Remove the old light assembly",
            "Remove the mounting bolts or screws holding the light assembly. Carefully slide the assembly forward/out of the mounting position.",
          ],
          [
            "Install the new light assembly",
            "Align the new light with the mounting holes. Reinstall the mounting bolts and torque to specification. Reconnect the electrical connector until it clicks into place.",
          ],
          [
            "Reconnect battery and test operation",
            "Reconnect the battery. Test high beam, low beam, and turn signals (for headlights) or running lights, brake lights, and turn signals (for tail lights). Adjust beam pattern if needed.",
          ],
        ],
        faq_q1: "What vehicles is this headlight / tail light compatible with?",
        faq_a1: "This lighting assembly is designed as a direct OEM replacement for the specific vehicle models listed in the fitment table on this page. Please verify your vehicle make, model, and year match before ordering. For vehicles with HID or LED lighting, ensure the connector type matches.",
        related_parts_hint: "Customers who order this light also frequently order these related parts:",
      },
      oil: {
        app_cards: [
          [
            "🛢️ Engine Protection & Performance",
            [
              "Reduces engine wear during cold starts",
              "Protects against high-temperature breakdown",
              "Cleans engine internals and prevents sludge",
              "Improves fuel economy and engine efficiency",
            ],
          ],
          [
            "🌡️ Climate Adaptation",
            [
              "Multi-grade viscosity for all-season use",
              "Stable performance in extreme cold (5W)",
              "High-temperature stability in hot climates",
              "Suitable for stop-and-go city traffic",
            ],
          ],
          [
            "🚚 Fleet & Commercial Use",
            [
              "Extended drain intervals for fleet vehicles",
              "Heavy-duty protection for commercial trucks",
              "Compatible with high-mileage engines",
              "Reduces maintenance costs over time",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Quick-lube shops and service centers",
              "Fleet maintenance operations",
              "Car dealerships and OEM service departments",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms Your Engine Needs Fresh Oil",
        symptoms_intro: "If you notice any of the following, your engine may be due for an oil change or oil-related service:",
        symptoms: [
          "Oil change reminder light illuminated on dashboard",
          "Dark, dirty, or gritty oil on the dipstick",
          "Engine running louder than usual (knocking or ticking sounds)",
          "Decreased fuel economy",
          "Oil warning light or low oil pressure warning",
          "Excessive exhaust smoke (blue or dark)",
          "Engine running hot or temperature gauge higher than normal",
        ],
        symptoms_warning: "Regular oil changes are the single most important maintenance task for engine longevity. Neglecting oil changes can lead to engine wear, sludge buildup, and catastrophic engine failure.",
        install_time: "15-25 minutes",
        install_skill: "Beginner / DIY",
        install_tools: "Wrench, oil drain pan, funnel, jack & stands (optional)",
        install_steps: [
          [
            "Warm up the engine briefly",
            "Start the engine and let it run for 2-3 minutes to warm the oil. Warm oil drains faster and more completely. Turn off the engine and wait 5 minutes for oil to settle in the pan.",
          ],
          [
            "Locate drain plug and position drain pan",
            "Position an oil drain pan under the engine oil pan. Locate the drain plug — typically a single bolt on the bottom of the oil pan. Place the pan directly under the plug.",
          ],
          [
            "Remove the drain plug and drain old oil",
            "Using the correct size wrench, turn the drain plug counter-clockwise to remove it. Let the oil drain completely (5-10 minutes). Be careful — oil may be hot.",
          ],
          [
            "Replace the oil filter",
            "Using an oil filter wrench, remove the old oil filter. Apply a thin layer of fresh oil to the rubber gasket of the new filter. Install the new filter hand-tight plus 3/4 turn.",
          ],
          [
            "Refill with new engine oil",
            "Reinstall the drain plug with a new washer and torque to specification. Using a funnel, pour the recommended grade and quantity of new engine oil into the oil filler cap. Check the dipstick to confirm level.",
          ],
          [
            "Run engine and check for leaks",
            "Start the engine and let it run for 30 seconds, then shut off. Wait 2 minutes and check the dipstick — add oil if below the full mark. Inspect the drain plug and filter for leaks. Reset the oil life indicator if applicable.",
          ],
        ],
        faq_q1: "What viscosity grade is this engine oil?",
        faq_a1: "This engine oil is a multi-grade synthetic blend suitable for a wide range of vehicles. Check your vehicle owner's manual for the manufacturer-recommended viscosity grade (e.g., 5W-30, 5W-40, 10W-40). Using the correct grade ensures proper engine protection and fuel economy.",
        related_parts_hint: "Customers who order engine oil also frequently order these related items:",
      },
      body: {
        app_cards: [
          [
            "🚗 Exterior Restoration",
            [
              "Restores factory appearance after collision",
              "Replaces cracked or damaged original panels",
              "Maintains resale value and aesthetic appeal",
              "Direct OEM-style fit and finish",
            ],
          ],
          [
            "🔧 Body Shop Applications",
            [
              "Insurance claim replacement parts",
              "Collision repair and restoration projects",
              "Used car refurbishment and detailing",
              "Fleet vehicle appearance maintenance",
            ],
          ],
          [
            "🌦️ Weather Protection",
            [
              "Shields engine bay and radiator from debris",
              "Improves aerodynamics and fuel efficiency",
              "Protects critical components from road damage",
              "UV-resistant materials for long service life",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto body shops and collision centers",
              "Auto parts distributors and wholesalers",
              "Used car dealers and refurbishers",
              "Insurance-approved repair networks",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of a Damaged Body Panel",
        symptoms_intro: "If you notice any of the following, the body panel may need replacement:",
        symptoms: [
          "Visible cracks, dents, or holes in the panel",
          "Misalignment with adjacent panels (gaps or overlap)",
          "Loose or broken mounting clips and brackets",
          "Paint peeling or fading on the panel surface",
          "Vibration or flapping at high speeds",
          "Water or debris entering the engine bay / interior",
          "Visible damage from minor parking lot impacts",
        ],
        symptoms_warning: "Damaged body panels can lead to water intrusion, aerodynamic drag, and reduced vehicle value. Replace damaged panels promptly to protect underlying components and maintain vehicle appearance.",
        install_time: "60-120 minutes",
        install_skill: "Intermediate to Advanced",
        install_tools: "Socket wrench set, screwdriver, trim tools, panel clip pliers",
        install_steps: [
          [
            "Remove surrounding trim and hardware",
            "Remove any trim pieces, screws, plastic clips, or accessories that overlap or attach to the panel. Document the position of all hardware for reinstallation.",
          ],
          [
            "Disconnect electrical connections",
            "If the panel has lights, sensors, or cameras, disconnect the wiring harness connectors. Mark connector positions for reassembly.",
          ],
          [
            "Remove mounting bolts and screws",
            "Locate and remove all bolts, screws, and clips securing the panel to the vehicle frame. Keep hardware organized by location.",
          ],
          [
            "Carefully separate the panel from the vehicle",
            "With all fasteners removed, gently pull the panel away from the vehicle. Use trim tools to release any remaining plastic clips. Have a helper support the panel to avoid dropping it.",
          ],
          [
            "Transfer hardware to the new panel",
            "Transfer any mounting brackets, clips, or hardware from the old panel to the new one. Compare the new and old panels to confirm part number match.",
          ],
          [
            "Install the new panel and verify fitment",
            "Align the new panel with the mounting holes. Hand-tighten all bolts first to check fitment, then torque to specification. Reinstall trim, electrical connections, and test all functions (lights, sensors).",
          ],
        ],
        faq_q1: "Is this body panel primed and ready to paint?",
        faq_a1: "Yes, this body panel comes primed and ready for painting. We recommend professional paint matching and finishing by a qualified body shop to ensure color match with your vehicle. The primer surface should be lightly sanded before applying the top coat and clear coat.",
        related_parts_hint: "Customers who order this body panel also frequently order these related parts:",
      },
      intake: {
        app_cards: [
          [
            "🌬️ Engine Air Intake Performance",
            [
              "Restores factory air flow to the engine",
              "Improves throttle response and acceleration",
              "Replaces cracked or leaking intake manifold",
              "Reduces air leaks that trigger check engine lights",
            ],
          ],
          [
            "🔧 Repair & Replacement",
            [
              "Fixing intake manifold gasket leaks",
              "Resolving rough idle and stalling issues",
              "Repairing P0171/P0174 lean code triggers",
              "Restoring factory performance after engine work",
            ],
          ],
          [
            "🚗 Common Failure Symptoms",
            [
              "Rough idle or stalling at stop lights",
              "Reduced fuel economy",
              "Check engine light related to lean condition",
              "Vacuum leaks causing high RPM at idle",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Independent repair shops and garages",
              "Engine rebuild specialists",
              "Dealership service departments",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of a Failing Intake Manifold",
        symptoms_intro: "If you notice any of the following, the intake manifold or related component may need replacement:",
        symptoms: [
          "Rough idle or engine misfires, especially at low RPM",
          "Check engine light with codes P0171, P0174, or P0101",
          "Reduced fuel economy compared to normal",
          "Hissing or whistling sound from the engine bay (vacuum leak)",
          "Stalling or hesitation during acceleration",
          "Visible cracks or damage on the intake manifold",
          "Oil residue or carbon deposits around the intake ports",
        ],
        symptoms_warning: "Ignoring intake manifold issues can lead to poor fuel economy, increased emissions, catalytic converter damage, and eventual engine performance loss. Replace promptly to restore factory performance.",
        install_time: "90-150 minutes",
        install_skill: "Intermediate to Advanced",
        install_tools: "Socket wrench set, screwdriver, pliers, torque wrench",
        install_steps: [
          [
            "Disconnect the battery and relieve fuel pressure",
            "Disconnect the negative battery terminal. For fuel-injected engines, relieve fuel pressure by removing the fuel pump fuse and running the engine until it stalls.",
          ],
          [
            "Remove engine cover and air intake components",
            "Remove the engine cover and air filter housing to access the intake manifold. Disconnect the mass airflow (MAF) sensor connector if applicable.",
          ],
          [
            "Disconnect vacuum lines and electrical connectors",
            "Label and disconnect all vacuum hoses, electrical connectors, and coolant lines (if applicable) connected to the intake manifold. Photograph the configuration for reassembly.",
          ],
          [
            "Remove the intake manifold mounting bolts",
            "Remove the bolts securing the intake manifold to the cylinder head in a reverse pattern (outside-in) to prevent warping. Keep bolts organized by position.",
          ],
          [
            "Lift off the old intake manifold",
            "Carefully lift the intake manifold off the cylinder head. Remove the old gasket and clean the mounting surfaces on both the manifold and head with a plastic scraper.",
          ],
          [
            "Install new gaskets and the new intake manifold",
            "Install new gaskets on the cylinder head. Place the new intake manifold in position. Tighten the mounting bolts in a star pattern to manufacturer torque specification, in multiple stages. Reconnect all vacuum lines, electrical connectors, and reassemble components in reverse order.",
          ],
        ],
        faq_q1: "What causes intake manifold failure?",
        faq_a1: "Common causes include: aging plastic manifolds cracking from heat cycles, failed gaskets causing vacuum leaks, carbon buildup restricting ports, warping from overheating, and broken intake runner flaps (on V6/V8 engines). Regular maintenance and addressing check engine lights promptly can prevent further damage.",
        related_parts_hint: "Customers who order this intake component also frequently order these related parts:",
      },
      cooling: {
        app_cards: [
          [
            "🌡️ Engine Cooling Performance",
            [
              "Prevents engine overheating in traffic and towing",
              "Restores factory cooling efficiency",
              "Replaces leaking or failed cooling components",
              "Maintains optimal engine operating temperature",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Daily city driving in stop-and-go traffic",
              "Hot climate and high-temperature operation",
              "Mountain and steep grade driving",
              "Towing and heavy-load applications",
            ],
          ],
          [
            "🔧 Replacement Use Cases",
            [
              "Replacing failed OEM radiator or thermostat",
              "Restoring cooling system after overheating",
              "Cooling system overhaul projects",
              "Wholesale distribution to repair shops",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Independent repair shops and garages",
              "Fleet maintenance operations",
              "Truck and commercial vehicle service centers",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of Cooling System Failure",
        symptoms_intro: "If you notice any of the following, your cooling component may need replacement:",
        symptoms: [
          "Engine temperature gauge reading higher than normal",
          "Coolant warning light illuminated on dashboard",
          "Visible coolant leaks under the vehicle (green, pink, or yellow fluid)",
          "Sweet smell of coolant from the engine bay",
          "Engine overheating, especially in traffic or hot weather",
          "Steam or white smoke from under the hood",
          "Low coolant level requiring frequent top-ups",
        ],
        symptoms_warning: "Engine overheating can cause catastrophic engine damage including blown head gaskets, warped cylinder heads, and seized pistons. Address cooling system issues immediately.",
        install_time: "60-120 minutes",
        install_skill: "Intermediate",
        install_tools: "Socket wrench set, pliers, drain pan, funnel",
        install_steps: [
          [
            "Allow the engine to cool completely",
            "Never work on a hot cooling system. Allow the engine to cool completely (1-2 hours) before opening the radiator cap. The cooling system is pressurized and hot coolant can cause severe burns.",
          ],
          [
            "Drain the coolant",
            "Place a drain pan under the radiator drain petcock. Open the petcock and drain the coolant into the pan. Dispose of used coolant at an approved recycling facility — it is toxic to pets and wildlife.",
          ],
          [
            "Remove the old component",
            "Remove any hoses, brackets, or shrouds blocking access to the failed component. Disconnect hoses, electrical connectors, and mounting bolts. Remove the failed component.",
          ],
          [
            "Transfer hardware and prepare new component",
            "Transfer any sensors, gaskets, or mounting hardware from the old component to the new one. Inspect hoses and replace if cracked or hardened.",
          ],
          [
            "Install the new component",
            "Position the new component in the mounting location. Reinstall mounting bolts and torque to specification. Reconnect hoses with new hose clamps if applicable.",
          ],
          [
            "Refill coolant and bleed air from the system",
            "Refill the cooling system with the manufacturer-specified coolant type. Many vehicles require bleeding air from the system via bleeder screws. Run the engine with the radiator cap off until the thermostat opens, then top off coolant. Reinstall the cap and check for leaks.",
          ],
        ],
        faq_q1: "What type of coolant should I use?",
        faq_a1: "Always use the coolant type specified in your vehicle owner's manual. Common types include: IAT (Inorganic Additive Technology — green), OAT (Organic Acid Technology — orange/yellow), and HOAT (Hybrid OAT — yellow/turquoise). Mixing coolant types can cause gel formation and cooling system damage.",
        related_parts_hint: "Customers who order cooling components also frequently order these related parts:",
      },
      suspension: {
        app_cards: [
          [
            "🏎️ Ride Quality & Handling",
            [
              "Restores factory ride quality and comfort",
              "Reduces body roll and improves cornering stability",
              "Replaces worn or leaking original shocks",
              "Improves braking stability and tire contact",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Daily driving on rough or potholed roads",
              "Highway driving with reduced body motion",
              "Carrying heavy loads or towing",
              "Restoring handling after collision damage",
            ],
          ],
          [
            "🔧 Replacement Use Cases",
            [
              "Replacing worn OEM shocks / struts",
              "Restoring ride quality after 50,000+ miles",
              "Insurance claim replacement after accident",
              "Wholesale distribution to repair shops",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Tire and alignment shops",
              "Independent repair shops",
              "Fleet maintenance operations",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of Worn Suspension Components",
        symptoms_intro: "If you notice any of the following, your suspension component may need replacement:",
        symptoms: [
          "Excessive bouncing after going over bumps",
          "Nose-dive during hard braking",
          "Body roll during cornering or lane changes",
          "Uneven tire wear (cupping or scalloping)",
          "Visible oil leaks on the shock / strut body",
          "Clunking or rattling noises from the suspension",
          "Vehicle sitting lower than normal on one side",
        ],
        symptoms_warning: "Worn suspension components affect braking, handling, and tire life. Driving with bad shocks increases stopping distance by up to 20% and causes premature tire wear. Replace in pairs (front or rear) for balanced handling.",
        install_time: "90-180 minutes per pair",
        install_skill: "Intermediate to Advanced",
        install_tools: "Jack, stands, spring compressor (for struts), socket wrench set, torque wrench",
        install_steps: [
          [
            "Loosen lug nuts and raise the vehicle",
            "Loosen the lug nuts. Raise the vehicle with a jack and secure with jack stands. Remove the wheel to access the suspension component.",
          ],
          [
            "Disconnect brake lines and ABS sensors",
            "Carefully unclip any brake lines or ABS sensor wires from the suspension component. Support the brake caliper with wire — do not let it hang by the hose.",
          ],
          [
            "Remove mounting bolts",
            "Remove the bolts securing the suspension component to the vehicle: typically two bolts at the top (for struts) or one at the top and one at the bottom (for shocks).",
          ],
          [
            "Remove the old component",
            "For struts: use a spring compressor to safely compress the coil spring before removing the strut assembly. For shocks: simply remove the mounting bolts and pull the old shock out.",
          ],
          [
            "Install the new component",
            "Transfer any mounting hardware from the old component to the new one. Install in reverse order. For struts: install the new strut with the coil spring compressed, then slowly release the compressor.",
          ],
          [
            "Reassemble and test",
            "Reinstall the wheel and torque lug nuts to specification. Lower the vehicle. Bounce the corner of the vehicle a few times to settle the suspension. Test drive at low speed to confirm proper operation. Recommend wheel alignment after suspension work.",
          ],
        ],
        faq_q1: "Should I replace suspension components in pairs?",
        faq_a1: "Yes — we strongly recommend replacing suspension components in pairs (both front or both rear) at the same time. This ensures balanced handling, even tire wear, and predictable braking. Replacing only one side causes uneven handling and can lead to premature wear on the older component.",
        related_parts_hint: "Customers who order suspension components also frequently order these related parts:",
      },
      filter: {
        app_cards: [
          [
            "🔧 Filtration Performance",
            [
              "Removes contaminants to protect engine components",
              "Restores factory filtration efficiency",
              "Extends engine and component service life",
              "Maintains optimal fluid or air flow rates",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Regular scheduled maintenance intervals",
              "Dusty or dirty operating environments",
              "Heavy-duty or extreme condition driving",
              "Pre-purchase vehicle service preparation",
            ],
          ],
          [
            "🔄 Replacement Use Cases",
            [
              "Scheduled filter replacement service",
              "Restoring performance after extended use",
              "Pre-purchase inspection service items",
              "Wholesale distribution to service shops",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Quick-lube shops and service centers",
              "Independent repair shops",
              "Fleet maintenance operations",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of a Clogged or Failed Filter",
        symptoms_intro: "If you notice any of the following, the filter may need replacement:",
        symptoms: [
          "Reduced engine performance or fuel economy",
          "Restricted air flow or unusual engine sounds",
          "Dirty or dark colored fluid (for oil/fuel filters)",
          "Strong fuel or exhaust odors inside the cabin",
          "Service reminder or maintenance light on dashboard",
          "Visible dirt, debris, or saturation on the filter",
          "Engine running rough or stalling (severely clogged filter)",
        ],
        symptoms_warning: "A clogged filter reduces performance, increases wear on other components, and can lead to expensive damage. Replace filters at manufacturer-recommended intervals to protect your engine and maintain efficiency.",
        install_time: "10-30 minutes",
        install_skill: "Beginner / DIY",
        install_tools: "Filter wrench (for oil filters), screwdriver, drain pan",
        install_steps: [
          [
            "Locate the filter and gather tools",
            "Locate the filter (engine bay for oil/air filters, fuel line for fuel filter, behind glove box for cabin filter). Position drain pan if needed and gather appropriate tools.",
          ],
          [
            "Prepare the area",
            "For oil filters: run the engine briefly to warm oil, then shut off. Place a drain pan under the filter. For cabin filters: open the glove box and remove the damper rod.",
          ],
          [
            "Remove the old filter",
            "For oil filters: use a filter wrench to loosen the old filter. Unscrew by hand, allowing oil to drain into the pan. For air filters: open the airbox and remove the old filter element. For cabin filters: remove the access cover and slide out the old filter.",
          ],
          [
            "Prepare the new filter",
            "For oil filters: apply a thin layer of fresh oil to the rubber gasket of the new filter. For air/cabin filters: compare the new filter to the old one to confirm size and orientation match.",
          ],
          [
            "Install the new filter",
            "For oil filters: install the new filter hand-tight plus 3/4 turn. For air filters: place the new filter in the airbox with the airflow arrow pointing in the correct direction. For cabin filters: slide the new filter into the housing with the airflow arrow pointing down or toward the blower.",
          ],
          [
            "Verify and reset",
            "For oil filters: run the engine for 30 seconds and check for leaks. Check oil level and add if needed. For air/cabin filters: reinstall the airbox cover, glove box, or access cover. Reset the service reminder if applicable.",
          ],
        ],
        faq_q1: "How often should this filter be replaced?",
        faq_a1: "Replacement intervals vary by filter type: oil filter — every oil change (5,000-10,000 km); air filter — every 15,000-30,000 km; fuel filter — every 30,000-50,000 km; cabin air filter — every 15,000-25,000 km. Check your vehicle owner's manual for the manufacturer-recommended interval, and replace more frequently in dusty or severe conditions.",
        related_parts_hint: "Customers who order this filter also frequently order these related items:",
      },
      sensor: {
        app_cards: [
          [
            "⚙️ Sensor Performance",
            [
              "Restores accurate sensor readings",
              "Resolves check engine or warning lights",
              "Improves fuel economy and emissions",
              "Returns engine management to factory operation",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Daily city and highway driving",
              "Replacing failed OEM sensors",
              "Passing emissions and inspection tests",
              "Restoring performance after diagnostic trouble codes",
            ],
          ],
          [
            "🔧 Replacement Use Cases",
            [
              "Replacing failed OEM sensor",
              "Clearing persistent check engine codes",
              "Emissions system repair and restoration",
              "Wholesale distribution to diagnostic shops",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Independent repair shops",
              "Emissions and diagnostic specialists",
              "Dealership service departments",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of a Failed Sensor",
        symptoms_intro: "If you notice any of the following, the sensor may need replacement:",
        symptoms: [
          "Check engine light or other warning light illuminated",
          "Failed emissions test or readiness monitor not set",
          "Poor fuel economy compared to normal",
          "Rough idle, hesitation, or stalling",
          "Erratic engine behavior under load",
          "Failed diagnostic trouble codes related to the sensor",
          "Visible damage or contamination on the sensor",
        ],
        symptoms_warning: "Driving with failed sensors can reduce fuel economy, increase emissions, cause catalytic converter damage, and prevent your vehicle from passing inspection. Replace promptly and clear trouble codes after installation.",
        install_time: "20-60 minutes",
        install_skill: "Beginner to Intermediate",
        install_tools: "Sensor wrench or O2 sensor socket, jack & stands, wire brush",
        install_steps: [
          [
            "Disconnect the battery",
            "Disconnect the negative battery terminal before working on electrical components. This prevents short circuits and ensures safety while handling the sensor.",
          ],
          [
            "Locate the sensor and access it",
            "Identify the sensor location. Some sensors (oxygen, ABS wheel speed) require raising the vehicle and removing shields or wheels. Plan the access path before starting work.",
          ],
          [
            "Disconnect the electrical connector",
            "Locate the wiring harness connector on the sensor. Press the release tab and gently pull the connector apart. Do not pull by the wires. Inspect the connector for corrosion or damage.",
          ],
          [
            "Remove the old sensor",
            "For threaded sensors (oxygen, coolant temperature): use the appropriate sensor wrench or socket to unscrew counter-clockwise. For plug-in sensors: release the mounting clip and pull out. Apply penetrating oil if stuck.",
          ],
          [
            "Install the new sensor",
            "Apply anti-seize compound to the threads of threaded sensors (do not get compound on the sensor tip). Screw the new sensor in hand-tight, then torque to specification. Reconnect the electrical connector until it clicks.",
          ],
          [
            "Reconnect battery and clear codes",
            "Reconnect the battery. Start the engine and verify the warning light is off. Use an OBD-II scanner to clear any stored trouble codes. Test drive to confirm the sensor is operating correctly and the light does not return.",
          ],
        ],
        faq_q1: "Do I need to program or calibrate the new sensor?",
        faq_a1: "Most replacement sensors are plug-and-play and do not require programming. However, some vehicles (especially European makes like BMW, Mercedes, VW) may require coding via a diagnostic tool to register the new sensor with the ECU. Check your vehicle service manual for specific requirements.",
        related_parts_hint: "Customers who order this sensor also frequently order these related parts:",
      },
      mirror: {
        app_cards: [
          [
            "🪞 Visibility & Safety",
            [
              "Restores factory rear visibility",
              "Improves blind spot awareness",
              "Replaces damaged or broken original mirrors",
              "Maintains DOT/SAE compliance",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Replacing cracked or broken mirror glass",
              "Restoring power fold or heated mirror function",
              "Insurance claim replacement after accident",
              "Restoring OEM appearance and function",
            ],
          ],
          [
            "🔧 Replacement Use Cases",
            [
              "Replacing broken or damaged mirror",
              "Restoring power mirror adjustment",
              "Insurance claim replacement parts",
              "Wholesale distribution to body shops",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto body shops and collision centers",
              "Auto parts distributors and wholesalers",
              "Used car dealers and refurbishers",
              "Insurance-approved repair networks",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of a Damaged Side Mirror",
        symptoms_intro: "If you notice any of the following, the side mirror may need replacement:",
        symptoms: [
          "Cracked, broken, or missing mirror glass",
          "Mirror does not adjust properly (for power mirrors)",
          "Heated mirror function not working",
          "Power fold function not working (for power fold mirrors)",
          "Turn signal indicator not flashing (for mirrors with indicators)",
          "Loose or vibrating mirror housing at highway speed",
          "Visible damage from minor parking lot impacts",
        ],
        symptoms_warning: "Driving with a damaged or missing side mirror is both unsafe and illegal in most regions. Replace promptly to maintain visibility, road legality, and vehicle appearance.",
        install_time: "20-45 minutes",
        install_skill: "Beginner / DIY",
        install_tools: "Socket wrench, screwdriver, trim removal tools, Torx set (often required)",
        install_steps: [
          [
            "Remove the mirror glass (if replacing glass only)",
            "For glass-only replacement: tilt the mirror glass to access the back. Press the release tabs and pull the glass off the motor mount. Disconnect the heating element connector if present.",
          ],
          [
            "Remove the mirror housing cover",
            "For full mirror assembly replacement: locate and remove the small triangular trim cover on the inside of the door (near the mirror mounting point). This usually pops off with a trim tool.",
          ],
          [
            "Disconnect electrical connectors",
            "Disconnect the wiring harness connectors for power mirror, heating, power fold, and turn signal (if equipped). Mark connector positions for reassembly.",
          ],
          [
            "Remove the mirror mounting bolts",
            "Remove the 3-4 bolts (typically Torx) securing the mirror assembly to the door. Support the mirror with one hand while removing the last bolt to prevent dropping it.",
          ],
          [
            "Install the new mirror assembly",
            "Position the new mirror assembly. Reinstall the mounting bolts and torque to specification. Reconnect all electrical connectors until they click into place.",
          ],
          [
            "Test all functions and reassemble trim",
            "Reconnect the battery (if disconnected). Test power mirror adjustment, heating, power fold, and turn signal functions. Reinstall the triangular trim cover on the inside of the door.",
          ],
        ],
        faq_q1: "Is this mirror paintable to match my vehicle color?",
        faq_a1: "Yes, this mirror housing comes primed and ready for painting. We recommend professional paint matching and finishing by a qualified body shop to ensure color match with your vehicle. The primer surface should be lightly sanded before applying the top coat and clear coat for best results.",
        related_parts_hint: "Customers who order this mirror also frequently order these related parts:",
      },
      electrical: {
        app_cards: [
          [
            "⚡ Electrical Performance",
            [
              "Restores reliable starting and charging",
              "Replaces failed OEM electrical components",
              "Improves battery charging efficiency",
              "Resolves intermittent electrical issues",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Daily city and highway driving",
              "Replacing failed alternators or starters",
              "Restoring charging system after failure",
              "Resolving battery drain issues",
            ],
          ],
          [
            "🔧 Replacement Use Cases",
            [
              "Replacing failed OEM alternator or starter",
              "Restoring charging system performance",
              "Insurance claim replacement parts",
              "Wholesale distribution to repair shops",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Independent repair shops",
              "Fleet maintenance operations",
              "Dealership service departments",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of Electrical Component Failure",
        symptoms_intro: "If you notice any of the following, the electrical component may need replacement:",
        symptoms: [
          "Dim or flickering headlights and interior lights",
          "Battery warning light illuminated on dashboard",
          "Engine slow to crank or clicking sound when starting",
          "Battery frequently dead or requires jump-starts",
          "Strange electrical behavior (random warnings, accessory failures)",
          "Visible damage or burning smell from the component",
          "Voltage test shows out-of-spec charging or battery drain",
        ],
        symptoms_warning: "Driving with a failed alternator or starter can leave you stranded. Battery drain issues can also damage other electrical components. Replace failed parts promptly to avoid being stuck with a non-starting vehicle.",
        install_time: "60-120 minutes",
        install_skill: "Intermediate",
        install_tools: "Socket wrench set, multimeter, battery terminal cleaner",
        install_steps: [
          [
            "Disconnect the battery",
            "Always disconnect the negative battery terminal first and the positive terminal second. This prevents short circuits while working on electrical components. Wait 5 minutes for capacitors to discharge.",
          ],
          [
            "Locate the failed component",
            "Identify the location of the failed component: alternator is typically engine-mounted and driven by the serpentine belt; starter is mounted on the bell housing near the engine-transmission junction.",
          ],
          [
            "Disconnect electrical connectors",
            "Label and disconnect the main power wire (usually a large gauge wire with a nut terminal), the ground wire, and any signal connectors. Mark positions for reassembly.",
          ],
          [
            "Remove mounting bolts and the old component",
            "For alternators: loosen the belt tensioner, remove the serpentine belt, and remove the mounting bolts. For starters: remove the mounting bolts (typically 2-3). Support the component as you remove the last bolt.",
          ],
          [
            "Install the new component",
            "Compare the new and old components to confirm part number match. Position the new component and hand-tighten mounting bolts. Reconnect all electrical connectors and tighten terminal nuts to specification.",
          ],
          [
            "Reinstall belt (alternator) and test",
            "For alternators: reinstall the serpentine belt and verify proper routing. Reconnect the battery. Start the engine and use a multimeter to verify charging voltage (13.5-14.5V). Test all electrical accessories for proper operation.",
          ],
        ],
        faq_q1: "How do I know if my alternator or starter is failing?",
        faq_a1: "Alternator failure symptoms: dim lights, battery warning light, dead battery, voltage reading below 13.5V when running. Starter failure symptoms: clicking sound but no crank, slow cranking, no response when turning the key. A mechanic can perform a charging system test to confirm which component has failed.",
        related_parts_hint: "Customers who order electrical components also frequently order these related parts:",
      },
      pump: {
        app_cards: [
          [
            "💧 Fluid Transfer Performance",
            [
              "Restores factory fluid flow rates",
              "Replaces leaking or failed OEM pumps",
              "Maintains proper system pressure",
              "Improves overall system efficiency",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Daily city and highway driving",
              "Replacing failed OEM water or fuel pump",
              "Restoring cooling or fuel system performance",
              "Addressing pressure-related issues",
            ],
          ],
          [
            "🔧 Replacement Use Cases",
            [
              "Replacing failed OEM pump",
              "Restoring factory fluid flow and pressure",
              "Cooling system overhaul projects",
              "Wholesale distribution to repair shops",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Independent repair shops",
              "Fleet maintenance operations",
              "Dealership service departments",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of a Failing Pump",
        symptoms_intro: "If you notice any of the following, the pump may need replacement:",
        symptoms: [
          "Engine overheating (water pump failure)",
          "Coolant leaks near the front of the engine",
          "Whining or grinding noise from the pump area",
          "Low fuel pressure or engine sputtering (fuel pump)",
          "Hard starting or no-start condition (fuel pump)",
          "Visible coolant or fuel leaks under the vehicle",
          "Loss of power or poor acceleration",
        ],
        symptoms_warning: "A failed water pump can cause catastrophic engine overheating and damage. A failed fuel pump can leave you stranded. Address pump issues immediately to prevent further damage.",
        install_time: "60-180 minutes",
        install_skill: "Intermediate to Advanced",
        install_tools: "Socket wrench set, pliers, drain pan, pulley removal tools (for water pump)",
        install_steps: [
          [
            "Drain fluid and disconnect the battery",
            "Drain the appropriate fluid (coolant for water pump, fuel for fuel pump) into a drain pan. Disconnect the negative battery terminal. Allow components to cool completely.",
          ],
          [
            "Remove components blocking pump access",
            "Remove the serpentine belt, timing cover, or other components blocking access to the pump. Document the configuration for reassembly.",
          ],
          [
            "Disconnect hoses and electrical connectors",
            "Label and disconnect hoses, electrical connectors, and mounting hardware from the pump. Have rags ready to catch residual fluid.",
          ],
          [
            "Remove the old pump",
            "Remove the mounting bolts (typically 2-5 bolts) and remove the old pump. Compare the new and old pumps to confirm part number match. Clean the mounting surface on the engine block.",
          ],
          [
            "Install the new pump with new gasket",
            "Install a new gasket or O-ring on the new pump. Position the pump and hand-tighten mounting bolts. Then torque bolts to specification in a star pattern to ensure even sealing.",
          ],
          [
            "Reassemble and refill fluid",
            "Reconnect hoses and electrical connectors. Reinstall the serpentine belt or timing cover. Refill the appropriate fluid. Start the engine and check for leaks. Verify proper pressure and operation.",
          ],
        ],
        faq_q1: "Should I replace the timing belt at the same time as the water pump?",
        faq_a1: "If your water pump is driven by the timing belt, yes — we strongly recommend replacing the timing belt, tensioner, and water pump at the same time. This saves significant labor cost (since the timing cover must be removed to access the water pump anyway) and prevents future breakdowns when the timing belt wears out before the new water pump does.",
        related_parts_hint: "Customers who order pumps also frequently order these related parts:",
      },
      drivetrain: {
        app_cards: [
          [
            "⚙️ Drivetrain Performance",
            [
              "Restores smooth power delivery to the wheels",
              "Eliminates vibration and clunking noises",
              "Replaces worn or failed OEM components",
              "Maintains factory drivetrain geometry",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Daily city and highway driving",
              "Replacing worn CV joints or drive axles",
              "Restoring smooth acceleration",
              "Addressing vibration at speed",
            ],
          ],
          [
            "🔧 Replacement Use Cases",
            [
              "Replacing failed OEM CV joint or axle",
              "Restoring smooth power delivery",
              "Insurance claim replacement parts",
              "Wholesale distribution to repair shops",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Independent repair shops",
              "Tire and alignment shops",
              "Fleet maintenance operations",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of Drivetrain Component Failure",
        symptoms_intro: "If you notice any of the following, the drivetrain component may need replacement:",
        symptoms: [
          "Clicking or popping sound when turning (CV joint)",
          "Vibration that increases with vehicle speed",
          "Grease on the inside of the wheel or on the ground",
          "Shuddering during acceleration",
          "Clunking noise when shifting between drive and reverse",
          "Visible damage to the CV boot (cracked, torn, or leaking grease)",
          "Uneven or shuddering acceleration from a stop",
        ],
        symptoms_warning: "Driving with a failed CV joint or drive axle can lead to complete separation, leaving the vehicle undriveable. It can also damage other drivetrain components. Replace at the first sign of failure.",
        install_time: "90-180 minutes per side",
        install_skill: "Intermediate to Advanced",
        install_tools: "Jack, stands, socket wrench set, pry bar, axle puller (may be needed)",
        install_steps: [
          [
            "Loosen lug nuts and raise the vehicle",
            "Loosen the lug nuts on the affected wheel. Raise the vehicle and secure with jack stands. Remove the wheel to access the drivetrain component.",
          ],
          [
            "Remove the axle nut (for drive axles)",
            "Remove the large center axle nut from the wheel hub. This is typically very tight and may require impact tools or a long breaker bar with the vehicle on the ground.",
          ],
          [
            "Separate the ball joint or strut",
            "For front drive axles: separate the ball joint or strut to allow the hub to move outward, creating clearance to remove the axle from the hub.",
          ],
          [
            "Remove the axle from the transmission",
            "For front drive axles: carefully pry the inner CV joint out of the transmission. Use a pry bar behind the inner CV joint housing. Have a drain pan ready for transmission fluid that may spill.",
          ],
          [
            "Install the new axle or CV joint",
            "Install new snap rings on the new axle. Insert the inner joint into the transmission until the snap ring clicks into place. Reinstall the outer joint into the hub, then reinstall the ball joint or strut.",
          ],
          [
            "Reassemble and test",
            "Reinstall the axle nut and torque to specification (typically very high torque). Reinstall the wheel and lower the vehicle. Test drive at low speed to confirm no clicking, vibration, or leaks. Check transmission fluid level and top up if needed.",
          ],
        ],
        faq_q1: "Should I replace CV joints or the entire drive axle assembly?",
        faq_a1: "This depends on the extent of damage. If the CV boot is just torn and the joint itself is still in good condition, replacing the boot and repacking the joint with grease is sufficient. If the joint is clicking, clunking, or has run dry for an extended period, replace the entire drive axle assembly for reliability and labor savings.",
        related_parts_hint: "Customers who order drivetrain components also frequently order these related parts:",
      },
      general: {
        app_cards: [
          [
            "🔧 Product Performance",
            [
              "Restores factory function and reliability",
              "Replaces worn or failed OEM component",
              "Maintains original equipment specifications",
              "Improves overall vehicle operation",
            ],
          ],
          [
            "🚗 Driving Scenarios",
            [
              "Daily city and highway driving",
              "Replacing failed or worn OEM parts",
              "Restoring factory performance after repair",
              "Wholesale distribution to repair shops",
            ],
          ],
          [
            "🔄 Replacement Use Cases",
            [
              "Replacing failed OEM component",
              "Restoring factory function and performance",
              "Insurance claim replacement parts",
              "Wholesale distribution networks",
            ],
          ],
          [
            "🌍 Target Markets",
            [
              "Auto parts distributors and wholesalers",
              "Independent repair shops and garages",
              "Dealership service departments",
              "Fleet maintenance operations",
            ],
          ],
        ],
        symptoms_title: "⚠️ Symptoms of Component Failure",
        symptoms_intro: "If you notice any of the following, this component may need replacement:",
        symptoms: [
          "Visible damage, wear, or leaks on the component",
          "Unusual noises from the affected system",
          "Reduced performance compared to factory specifications",
          "Warning lights or diagnostic trouble codes",
          "Vibration or irregular operation",
          "Fluid leaks or contamination",
          "Component fails to operate or operates intermittently",
        ],
        symptoms_warning: "Driving with a failed or worn component can lead to further damage and expensive repairs. Replace promptly to restore factory function and reliability.",
        install_time: "30-90 minutes",
        install_skill: "Beginner to Intermediate",
        install_tools: "Basic socket wrench set, screwdrivers, pliers",
        install_steps: [
          [
            "Disconnect the battery if working on electrical components",
            "For electrical work, disconnect the negative battery terminal to prevent short circuits. Allow capacitors to discharge before working on sensitive electronics.",
          ],
          [
            "Access the component",
            "Remove any covers, shields, or adjacent components needed to access the failed part. Document hardware positions for reassembly.",
          ],
          [
            "Disconnect electrical and mechanical connections",
            "Label and disconnect electrical connectors, hoses, linkages, and mounting hardware. Mark positions for reassembly.",
          ],
          [
            "Remove the old component",
            "Remove the mounting bolts or clips. Carefully remove the old component without damaging surrounding parts. Compare the new and old parts to confirm correct replacement.",
          ],
          [
            "Install the new component",
            "Transfer any required hardware from the old component to the new one. Position the new component and reinstall mounting hardware. Torque to manufacturer specification.",
          ],
          [
            "Reassemble and test",
            "Reconnect all electrical and mechanical connections. Reinstall any covers or shields. Test the component operation to confirm proper function.",
          ],
        ],
        faq_q1: "Is this a direct OEM replacement?",
        faq_a1: "Yes, this is an OEM-equivalent replacement part. It matches the original specifications, fitment, and durability of the factory-installed part, with direct installation requiring no modifications.",
        related_parts_hint: "Customers who order this component also frequently order these related parts:",
      },
    };

class CollectorBackground {
  constructor() {
    // 使用硬编码配置
    this.ossConfig = EMBEDDED_CONFIG.oss;
    this.websiteConfig = EMBEDDED_CONFIG.website;
    this.githubConfig = EMBEDDED_CONFIG.github;
    this.analyticsConfig = EMBEDDED_CONFIG.analytics;
    this.collectionConfig = EMBEDDED_CONFIG.collection;

    this.collectionQueue = [];
    this.processedItems = new Map();
    this.stats = {
      total: 0,
      success: 0,
      failed: 0,
      startTime: null
    };

    console.log('🚀 阿里巴巴采集器启动（修复版）');
    console.log('📋 OSS配置:', this.ossConfig);
    console.log('🌐 网站配置:', this.websiteConfig);
    
    // 品牌到分类目录的映射
    this.brandCategoryMap = {
      // 日系
      'TOYOTA': 'Japanese', 'HONDA': 'Japanese', 'NISSAN': 'Japanese',
      'MAZDA': 'Japanese', 'SUBARU': 'Japanese', 'MITSUBISHI': 'Japanese',
      'SUZUKI': 'Japanese', 'LEXUS': 'Japanese', 'INFINITI': 'Japanese', 'ACURA': 'Japanese',
      'SCION': 'Japanese', 'DAIHATSU': 'Japanese', 'HINO': 'Japanese', 'ISUZU': 'Japanese',
      'JAPANESE': 'Japanese',
      // 德系
      'BMW': 'German', 'MERCEDES-BENZ': 'German', 'MERCEDES': 'German', 'AUDI': 'German',
      'VOLKSWAGEN': 'German', 'VW': 'German', 'PORSCHE': 'German', 'OPEL': 'German',
      'GERMAN': 'German',
      // 美系
      'FORD': 'American', 'CHEVROLET': 'American', 'DODGE': 'American',
      'GMC': 'American', 'JEEP': 'American', 'RAM': 'American', 'CADILLAC': 'American',
      'BUICK': 'American', 'LINCOLN': 'American', 'CHRYSLER': 'American',
      'TESLA': 'American', 'Rivian': 'American',
      'AMERICAN': 'American',
      // 韩系
      'HYUNDAI': 'Korean', 'KIA': 'Korean', 'GENESIS': 'Korean', 'SSANGYONG': 'Korean',
      'KOREAN': 'Korean',
      // 国产
      'WULING': 'Chinese', 'BAOJUN': 'Chinese', 'CHERY': 'Chinese', 'GEELY': 'Chinese',
      'BYD': 'Chinese', 'HAVAL': 'Chinese', 'GREAT WALL': 'Chinese', 'CHANGAN': 'Chinese',
      'MG': 'Chinese', 'ROEWE': 'Chinese', 'BESTUNE': 'Chinese', 'HONGQI': 'Chinese',
      'JAC': 'Chinese', 'FAW': 'Chinese', 'DONGFENG': 'Chinese', 'GAC': 'Chinese',
      'NIO': 'Chinese', 'XPENG': 'Chinese', 'LI AUTO': 'Chinese', 'LI': 'Chinese',
      'LIXIANG': 'Chinese', 'CHANGAN': 'Chinese', 'OUSHA': 'Chinese', 'CHANGAN': 'Chinese',
      'CHINESE': 'Chinese', 'SGMW': 'Chinese'
    };
    
    this.init();
  }

  // 根据车型适配表自动分类
  autoClassifyByFitment(fitmentData) {
    console.log('🔍 开始自动分类, fitmentData:', fitmentData);
    
    if (!fitmentData) {
      return 'other';
    }
    
    const dataArray = Array.isArray(fitmentData) ? fitmentData : [];
    
    if (dataArray.length === 0) {
      return 'other';
    }
    
    console.log('📊 fitmentData有', dataArray.length, '条数据');
    
    // 统计各品牌出现次数 - 使用更多字段名和变体
    const brandCount = {};
    const brandAliases = {
      // 日系
      'NISSAN': 'Japanese', 'Nissan': 'Japanese', 'nissan': 'Japanese',
      'TOYOTA': 'Japanese', 'Toyota': 'Japanese', 'toyota': 'Japanese',
      'HONDA': 'Japanese', 'Honda': 'Japanese', 'honda': 'Japanese',
      'MITSUBISHI': 'Japanese', 'Mitsubishi': 'Japanese', 'mitsubishi': 'Japanese',
      'MAZDA': 'Japanese', 'Mazda': 'Japanese', 'mazda': 'Japanese',
      'SUBARU': 'Japanese', 'Subaru': 'Japanese', 'subaru': 'Japanese',
      'SUZUKI': 'Japanese', 'Suzuki': 'Japanese', 'suzuki': 'Japanese',
      'LEXUS': 'Japanese', 'Lexus': 'Japanese',
      'INFINITI': 'Japanese', 'Infiniti': 'Japanese',
      'ACURA': 'Japanese', 'Acura': 'Japanese',
      'SCION': 'Japanese', 'Scion': 'Japanese',
      'DAIHATSU': 'Japanese', 'Daihatsu': 'Japanese',
      // 德系
      'BMW': 'German', 'Bmw': 'German', 'bmw': 'German',
      'MERCEDES-BENZ': 'German', 'MERCEDES': 'German', 'Mercedes': 'German', 'Mercedes-Benz': 'German',
      'AUDI': 'German', 'Audi': 'German', 'audi': 'German',
      'VOLKSWAGEN': 'German', 'VOLKSWAGON': 'German', 'VW': 'German', 'Volkswagen': 'German',
      'PORSCHE': 'German', 'Porsche': 'German',
      // 美系
      'FORD': 'American', 'Ford': 'American', 'ford': 'American',
      'CHEVROLET': 'American', 'CHEVY': 'American', 'Chevrolet': 'American',
      'DODGE': 'American', 'Dodge': 'American', 'dodge': 'American',
      'GMC': 'American', 'Gmc': 'American',
      'JEEP': 'American', 'Jeep': 'American',
      'RAM': 'American', 'Ram': 'American',
      'CADILLAC': 'American', 'Cadillac': 'American',
      'BUICK': 'American', 'Buick': 'American',
      'LINCOLN': 'American', 'Lincoln': 'American',
      'CHRYSLER': 'American', 'Chrysler': 'American',
      'TESLA': 'American', 'Tesla': 'American',
      // 韩系
      'HYUNDAI': 'Korean', 'Hyundai': 'Korean', 'hyundai': 'Korean',
      'KIA': 'Korean', 'Kia': 'Korean', 'kia': 'Korean',
      'GENESIS': 'Korean', 'Genesis': 'Korean',
      'SSANGYONG': 'Korean', 'Ssangyong': 'Korean',
      // 国产
      'WULING': 'Chinese', 'Wuling': 'Chinese', 'wuling': 'Chinese',
      'BAOJUN': 'Chinese', 'Baojun': 'Chinese', 'baojun': 'Chinese',
      'BYD': 'Chinese', 'Byd': 'Chinese', 'byd': 'Chinese',
      'CHERY': 'Chinese', 'Chery': 'Chinese', 'chery': 'Chinese',
      'GEELY': 'Chinese', 'Geely': 'Chinese', 'geely': 'Chinese',
      'HAVAL': 'Chinese', 'Haval': 'Chinese', 'haval': 'Chinese',
      'GREAT WALL': 'Chinese', 'GREATWALL': 'Chinese', 'Great Wall': 'Chinese', 'Greatwall': 'Chinese',
      'CHANGAN': 'Chinese', 'Changan': 'Chinese', 'changan': 'Chinese',
      'MG': 'Chinese', 'Mg': 'Chinese', 'mg': 'Chinese',
      'ROEWE': 'Chinese', 'Roewe': 'Chinese', 'roewe': 'Chinese',
      'BESTUNE': 'Chinese', 'Bestune': 'Chinese',
      'HONGQI': 'Chinese', 'Hongqi': 'Chinese', 'hongqi': 'Chinese', 'Hongqi': 'Chinese',
      'JAC': 'Chinese', 'Jac': 'Chinese', 'jac': 'Chinese',
      'FAW': 'Chinese', 'Faw': 'Chinese', 'faw': 'Chinese',
      'DONGFENG': 'Chinese', 'Dongfeng': 'Chinese', 'dongfeng': 'Chinese',
      'GAC': 'Chinese', 'Gac': 'Chinese',
      'NIO': 'Chinese', 'Nio': 'Chinese', 'nio': 'Chinese',
      'XPENG': 'Chinese', 'Xpeng': 'Chinese', 'xpeng': 'Chinese',
      'LI AUTO': 'Chinese', 'LI AUTO': 'Chinese', 'LIXIANG': 'Chinese',
      'SGMW': 'Chinese', 'Sgmw': 'Chinese', 'sgmw': 'Chinese'
    };
    
    dataArray.forEach((item, index) => {
      // 支持多种字段名
      const makeRaw = item.make || item.brand || item.Make || item.Brand || '';
      const make = makeRaw.toUpperCase().trim();
      
      if (make && make.length > 1) {
        // 尝试匹配标准品牌名
        const standardBrand = brandAliases[make] || brandAliases[makeRaw] || null;
        const brandKey = standardBrand || make;
        
        brandCount[brandKey] = (brandCount[brandKey] || 0) + 1;
        console.log(`第${index}条: ${makeRaw} -> ${brandKey}`);
      }
    });
    
    console.log('📊 品牌统计:', brandCount);
    
    // 找出出现最多的品牌
    let maxCount = 0;
    let primaryBrand = null;
    for (const [brand, count] of Object.entries(brandCount)) {
      if (count > maxCount) {
        maxCount = count;
        primaryBrand = brand;
      }
    }
    
    console.log(`🏆 最多的品牌: ${primaryBrand} (${maxCount}次)`);
    
    // 直接使用识别出的品牌名
    if (primaryBrand) {
      const category = this.brandCategoryMap[primaryBrand.toUpperCase()];
      if (category) {
        console.log(`✅ 自动分类: ${primaryBrand} → ${category}`);
        return category;
      }
      // 如果品牌名本身就是标准格式
      if (['Japanese', 'German', 'American', 'Korean', 'Chinese'].includes(primaryBrand)) {
        console.log(`✅ 直接使用车系作为分类: ${primaryBrand}`);
        return primaryBrand;
      }
    }
    
    return 'other';
  }

  init() {
    this.loadConfiguration();
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      this.handleMessage(message, sender, sendResponse);
      return true;
    });

    setInterval(() => {
      this.saveStats();
    }, 30000);

    console.log('阿里巴巴采集器后台已启动（修复版）');
  }

  async loadConfiguration() {
    console.log('🔧 加载配置（修复版）');
    try {
      console.log('📋 OSS配置:', this.ossConfig);
      console.log('🌐 网站配置:', this.websiteConfig);
      console.log('📊 Analytics配置:', this.analyticsConfig);

      if (!this.validateOSSConfig()) {
        console.error('❌ OSS配置验证失败');
        throw new Error('OSS配置不完整');
      }

      console.log('✅ 配置加载完成，所有配置有效');
    } catch (error) {
      console.error('❌ 配置加载失败:', error);
      console.error('⚠️ 严重错误：硬编码配置无效，请检查embedded-config.js');
    }
  }

  async handleMessage(message, sender, sendResponse) {
    const { action, data } = message;
    try {
      switch (action) {
        case 'uploadToOSS':
          // 修复：传递sender参数
          const uploadResult = await this.handleOSSUpload(data, sender);
          sendResponse(uploadResult);
          break;
        case 'uploadSEOToGitHub':
          const seoResult = await this.handleSEOUpload(data);
          sendResponse(seoResult);
          break;
        
        case 'testOSSConnection':
          const testResult = await this.handleTestOSSConnection(data);
          sendResponse(testResult);
          break;
        case 'getStats':
          sendResponse({ success: true, stats: this.stats });
          break;
        case 'updateConfig':
          await this.updateConfiguration(data);
          sendResponse({ success: true });
          break;
        case 'clearErrors':
          this.processedItems.clear();
          sendResponse({ success: true });
          break;
        case 'generateSEOPage':
          // v2.3.0: 用户审核通过后手动触发 SEO 生成
          const genSeoResult = await this.handleSEOUpload(data);
          if (genSeoResult && genSeoResult.success) {
            await this.updateProductSEOStatus(data.id, 'published', genSeoResult.url);
          }
          sendResponse(genSeoResult);
          break;
        case 'getPendingProducts':
          // v2.3.0: admin 待审核页用
          const pendingResult = await this.getProductsJSON();
          if (pendingResult.success) {
            const pending = (pendingResult.data || []).filter(p => p.seo_status === 'pending');
            sendResponse({ success: true, products: pending });
          } else {
            sendResponse({ success: false, error: pendingResult.error });
          }
          break;
        default:
          sendResponse({ success: false, error: '未知操作' });
      }
    } catch (error) {
      console.error('处理消息失败:', error);
      sendResponse({ success: false, error: error.message });
    }
  }

  async handleOSSUpload(productData, sender) {
    console.log('开始处理OSS上传:', productData.url);
    try {
      if (!this.validateOSSConfig()) {
        throw new Error('OSS配置不完整，请先配置阿里云OSS信息');
      }

      const fileName = this.generateFileName(productData);
      const filePath = `${this.ossConfig.directory}${fileName}`;
      const uploadData = this.prepareUploadData(productData);

      // 自动格式检测和转换
      console.log('开始自动格式检测和转换...');
      const finalUploadData = this.ensureFlatFormat(uploadData);
      console.log('格式处理完成，准备上传...');

      // 从上传数据中提取ID，确保products.json中使用同一个ID
      const uploadDataObj = JSON.parse(finalUploadData);
      const productId = uploadDataObj.id;

      const uploadResult = await this.uploadWithRetry(filePath, finalUploadData);
      this.updateStats(true);

      // 下载并上传图片到OSS
      let ossImages = [];
      if (productData.images && productData.images.length > 0) {
        console.log('开始下载并上传图片到OSS...');
        for (let i = 0; i < productData.images.length; i++) {
          const originalUrl = productData.images[i];
          try {
            const ext = this.getImageExtension(originalUrl) || 'jpg';
            const titleSlug = this.slugifyTitle(productData.title);
            const imageFileName = `${titleSlug}-${i + 1}.${ext}`;
            const imagePath = `images/${imageFileName}`;
            
            // 下载原图
            const imageData = await this.downloadImage(originalUrl);
            if (imageData) {
              // 上传到OSS
              const imageUploadResult = await this.uploadWithRetry(imagePath, imageData);
              if (imageUploadResult && imageUploadResult.url) {
                ossImages.push(imageUploadResult.url);
                console.log(`✅ 图片${i + 1}上传成功: ${imageUploadResult.url}`);
              }
            }
          } catch (imgError) {
            console.log(`⚠️ 图片${i + 1}上传失败:`, imgError.message);
          }
        }
        console.log(`📸 图片上传完成: ${ossImages.length}/${productData.images.length}`);
      }

      // 新增：更新 products.json
      try {
        const oemCode = productData.oemCodes && productData.oemCodes.length > 0 ? productData.oemCodes[0] : '';
        // 优先使用OSS图片，否则用原始URL
        const finalImages = ossImages.length > 0 ? ossImages : productData.images;
        const imageString = finalImages && finalImages.length > 0 ? finalImages.join(',') : '';
        const fitmentData = productData.fitment || [];
        
        // 自动分类
        const titleBrand = this.identifyBrand(productData.title);
        const fitmentCategory = this.autoClassifyByFitment(fitmentData);
        let category = titleBrand && titleBrand !== 'Universal' ? titleBrand : fitmentCategory;
        
        const productInfo = {
          id: productId,
          name: productData.title,
          title: productData.title,
          category: category,
          oem: oemCode,
          oemCode: oemCode,
          url: productData.url,
          description: productData.description || productData.seoDescription || '',
          images: finalImages || [],
          image: imageString,
          fitmentTable: fitmentData,
          brand: titleBrand,
          collectedAt: productData.collectedAt,
          hasFitment: productData.hasFitment || false,
          uploadedAt: new Date().toISOString(),
          sourceUrl: productData.url,
          // v2.3.0: 默认 pending，admin 审核通过后改为 published
          seo_status: 'pending',
          seo_published_at: null,
          seo_url: null
        };

        const updateResult = await this.updateProductsJSON(fileName, productInfo);
        console.log('products.json更新完成, category:', category);
      } catch (error) {
        console.error('更新products.json失败:', error);
      }

      // 修复：添加sender检查
      if (sender && sender.tab) {
        this.notifyContentScript(sender.tab.id, {
          action: 'uploadSuccess',
          ossUrl: uploadResult.url,
          fileName: fileName
        });
      }

      console.log('✅ OSS上传成功:', uploadResult.url);
      return {
        success: true,
        ossUrl: uploadResult.url,
        fileName: fileName,
        uploadTime: new Date().toISOString()
      };
    } catch (error) {
      console.error('❌ OSS上传失败:', error);
      this.updateStats(false);

      // 修复：添加sender检查
      if (sender && sender.tab) {
        this.notifyContentScript(sender.tab.id, {
          action: 'uploadFailed',
          error: error.message,
          productUrl: productData.url
        });
      }

      return {
        success: false,
        error: error.message,
        productUrl: productData.url
      };
    }
  }

  async handleTestOSSConnection(ossConfig) {
    console.log('测试OSS连接:', ossConfig);
    try {
      if (!ossConfig || !ossConfig.region || !ossConfig.bucket || !ossConfig.accessKeyId || !ossConfig.accessKeySecret) {
        return { success: false, error: 'OSS配置不完整，请检查所有必需字段' };
      }

      const testPath = 'connection-test.json';
      const testData = JSON.stringify({
        test: true,
        timestamp: new Date().toISOString(),
        config: {
          region: ossConfig.region,
          bucket: ossConfig.bucket
        }
      }, null, 2);

      const endpoint = `https://${ossConfig.bucket}.${ossConfig.region}.aliyuncs.com/${testPath}`;

      try {
        const response = await fetch(endpoint, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': this.generateOSSAuth('PUT', `/${testPath}`, testData.length, ossConfig),
            'x-oss-object-acl': 'public-read',
            'x-oss-date': new Date().toUTCString()
          },
          body: testData
        });

        if (response.ok || response.status === 403) {
          return { success: true, message: 'OSS连接测试成功！存储桶访问正常' };
        } else {
          const errorText = await response.text();
          throw new Error(`OSS返回错误: ${response.status} - ${errorText}`);
        }
      } catch (fetchError) {
        console.log('详细测试失败，尝试基本连接测试:', fetchError);
        const configValid = this.validateOSSFormat(ossConfig);
        if (configValid) {
          return { success: true, message: 'OSS配置格式正确（注意：实际连接测试需要网络环境支持）' };
        } else {
          throw new Error('OSS配置格式不正确，请检查配置参数');
        }
      }
    } catch (error) {
      console.error('OSS连接测试失败:', error);
      return { success: false, error: error.message || '连接测试失败' };
    }
  }

  validateOSSFormat(ossConfig) {
    const regionRegex = /^oss-[a-z]+-\d+$/;
    const bucketRegex = /^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/;
    const accessKeyIdRegex = /^LTAI[A-Za-z0-9]+$/;
    return (
      regionRegex.test(ossConfig.region) &&
      bucketRegex.test(ossConfig.bucket) &&
      accessKeyIdRegex.test(ossConfig.accessKeyId) &&
      ossConfig.accessKeySecret &&
      ossConfig.accessKeySecret.length > 10
    );
  }

  validateOSSConfig() {
    return !!(
      this.ossConfig.region &&
      this.ossConfig.bucket &&
      this.ossConfig.accessKeyId &&
      this.ossConfig.accessKeySecret
    );
  }

  // 根据产品标题生成 URL-safe 的 slug（小写、中划线、英文）
  slugifyTitle(title) {
    if (!title) return 'product';
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .substring(0, 60);
  }

  // 图片文件名专用：用原标题做文件名（保留空格、&、/、.），仅清理系统禁用字符
  sanitizeTitleForFilename(title) {
    if (!title) return 'product';
    return title
      .replace(/[<>:"\\|?*\x00-\x1F]+/g, '_')
      .substring(0, 150);
  }

  // 文件名：按产品标题 + 时间戳（避免重名）
  generateFileName(productData) {
    const timestamp = Date.now();
    const titleSlug = this.slugifyTitle(productData.title);
    return `${titleSlug}-${timestamp}.json`;
  }

  // ========== 格式转换功能 ==========
  detectDataFormat(data) {
    try {
      const parsed = JSON.parse(data);
      // 检测是否为嵌套格式
      if (parsed.metadata && parsed.product) {
        console.log('检测到嵌套格式数据，需要转换');
        return 'nested';
      }
      // 检测是否为扁平格式
      if (parsed.title && parsed.oem && parsed.images) {
        console.log('检测到扁平格式数据，无需转换');
        return 'flat';
      }
      console.log('未知数据格式');
      return 'unknown';
    } catch (error) {
      console.error('格式检测失败:', error);
      return 'invalid';
    }
  }

  convertNestedToFlat(nestedData) {
    try {
      const product = nestedData.product || {};
      const metadata = nestedData.metadata || {};
      const seo = nestedData.seo || {};

      // 提取时间戳ID
      const timestamp = metadata.fileName ?
        metadata.fileName.split('_')[0] :
        Date.now().toString();

      // 提取OEM编码
      const oemCode = product.oemCodes && product.oemCodes.length > 0 ?
        product.oemCodes[0] : '';

      // 处理图片
      const images = product.images || [];
      const imageString = images.length > 0 ? images.join(',') : '';

      // 构建扁平格式
      const flatData = {
        id: parseInt(timestamp) || Date.now(),
        name: product.title || '',
        title: product.title || '',
        category: 'other',
        oem: oemCode,
        oemCode: oemCode,
        url: metadata.sourceUrl || product.url || '',
        description: product.description || seo.description || '',
        images: images,
        image: imageString,
        fitmentTable: product.fitment || [],
        brand: nestedData.brand || '',
        collectedAt: metadata.collectedAt || new Date().toISOString(),
        hasFitment: product.hasFitment || false
      };

      console.log('格式转换成功:', flatData.title);
      return flatData;
    } catch (error) {
      console.error('格式转换失败:', error);
      throw new Error('数据格式转换失败');
    }
  }

  ensureFlatFormat(data) {
    try {
      // 检测数据格式
      const format = this.detectDataFormat(data);

      if (format === 'flat') {
        // 已经是扁平格式，直接使用
        return data;
      } else if (format === 'nested') {
        // 嵌套格式，需要转换
        const nestedData = JSON.parse(data);
        const flatData = this.convertNestedToFlat(nestedData);
        return JSON.stringify(flatData, null, 2);
      } else {
        console.warn('未知格式数据，保持原样');
        return data;
      }
    } catch (error) {
      console.error('格式处理失败:', error);
      return data; // 出错时保持原样
    }
  }
  // ========== 结束：格式转换功能 ==========

  prepareUploadData(productData) {
    // 生成与旧产品兼容的扁平结构
    const oemCode = productData.oemCodes && productData.oemCodes.length > 0 ? productData.oemCodes[0] : '';
    const imageString = productData.images && productData.images.length > 0 ? productData.images.join(',') : '';
    
    // 优先从标题识别品牌
    const titleBrand = this.identifyBrand(productData.title);
    console.log('🔍 标题识别品牌:', titleBrand);
    
    // 从车型适配表自动分类
    const fitmentData = productData.fitment || [];
    const fitmentCategory = this.autoClassifyByFitment(fitmentData);
    console.log('🔍 车型表分类:', fitmentCategory);
    
    // 添加品牌名到分类的映射
    const brandToCategory = {
      // 日系
      'Toyota': 'Japanese', 'Honda': 'Japanese', 'Nissan': 'Japanese', 'Mazda': 'Japanese',
      'Subaru': 'Japanese', 'Mitsubishi': 'Japanese', 'Suzuki': 'Japanese', 'Lexus': 'Japanese',
      'Infiniti': 'Japanese', 'Acura': 'Japanese', 'Scion': 'Japanese',
      // 德系
      'BMW': 'German', 'Mercedes-Benz': 'German', 'Audi': 'German', 'Volkswagen': 'German',
      'Porsche': 'German', 'Opel': 'German', 'Mini': 'German',
      // 美系
      'Ford': 'American', 'Chevrolet': 'American', 'Dodge': 'American', 'GMC': 'American',
      'Jeep': 'American', 'Ram': 'American', 'Cadillac': 'American', 'Buick': 'American',
      'Lincoln': 'American', 'Chrysler': 'American', 'Tesla': 'American',
      // 韩系
      'Hyundai': 'Korean', 'Kia': 'Korean', 'Genesis': 'Korean', 'Ssangyong': 'Korean',
      // 法系
      'Renault': 'French', 'Peugeot': 'French', 'Citroën': 'French', 'DS': 'French',
      // 英系
      'Land Rover': 'British', 'Jaguar': 'British', 'Mini': 'British',
      // 意系
      'Fiat': 'Italian', 'Alfa Romeo': 'Italian',
      // 中国品牌
      'Wuling': 'Chinese', 'Baojun': 'Chinese', 'Chery': 'Chinese', 'Geely': 'Chinese',
      'BYD': 'Chinese', 'Haval': 'Chinese', 'Great Wall': 'Chinese', 'Changan': 'Chinese',
      'MG': 'Chinese', 'Roewe': 'Chinese', 'Maxus': 'Chinese', 'JAC': 'Chinese',
      'FAW': 'Chinese', 'Dongfeng': 'Chinese', 'GAC': 'Chinese',
      'NIO': 'Chinese', 'XPeng': 'Chinese', 'Li Auto': 'Chinese',
      'Bestune': 'Chinese', 'Hongqi': 'Chinese', 'Voyah': 'Chinese'
    };
    // 将titleBrand转换为分类
    const titleCategory = brandToCategory[titleBrand] || titleBrand;
    
    // 优先使用标题识别的品牌，其次使用车型表分类
    let category = 'other';
    if (titleBrand && titleBrand !== 'Universal' && titleCategory !== 'Universal') {
      category = titleCategory;
    } else if (fitmentCategory && fitmentCategory !== 'other') {
      category = fitmentCategory;
    }
    console.log('✅ 最终分类:', category);
    
    return JSON.stringify({
      id: Date.now(), // 使用时间戳作为ID
      name: productData.title,
      title: productData.title,
      category: category,
      oem: oemCode,
      oemCode: oemCode,
      url: productData.url,
      description: productData.description || productData.seoDescription || '',
      images: productData.images || [],
      image: imageString, // 逗号分隔的图片字符串
      fitmentTable: fitmentData, // 适配表
      brand: titleBrand, // 品牌识别
      collectedAt: productData.collectedAt, // 采集时间
      hasFitment: productData.hasFitment || false,
      // SEO字段
      seoTitle: productData.seoTitle || '',
      seoDescription: productData.seoDescription || '',
      seoKeywords: productData.seoKeywords || [],
      urlSlug: productData.urlSlug || '',
      h1Title: productData.h1Title || '',
      h2Title: productData.h2Title || '',
      imageAltText: productData.imageAltText || ''
    }, null, 2);
  }

  // 获取图片扩展名
  getImageExtension(url) {
    if (!url) return 'jpg';
    const match = url.match(/\.(jpe?g|png|gif|webp)(\?|$)/i);
    if (match) return match[1].toLowerCase().replace('jpeg', 'jpg');
    return 'jpg';
  }

  // 下载图片（支持跨域）
  async downloadImage(url) {
    try {
      // 使用fetch下载图片，设置跨域模式
      const response = await fetch(url, {
        method: 'GET',
        mode: 'cors',
        credentials: 'omit'
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      const blob = await response.blob();
      return blob;
    } catch (error) {
      console.error('下载图片失败:', error);
      return null;
    }
  }

  async uploadWithRetry(filePath, data, maxRetries = 3) {
    let lastError = null;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`上传尝试 ${attempt}/${maxRetries}:`, filePath);
        const result = await this.uploadToOSS(filePath, data);
        return result;
      } catch (error) {
        lastError = error;
        console.error(`上传失败 (尝试 ${attempt}):`, error.message);
        if (attempt < maxRetries) {
          const delay = Math.pow(2, attempt) * 1000;
          console.log(`等待 ${delay}ms 后重试...`);
          await this.sleep(delay);
        }
      }
    }
    throw new Error(`上传失败，已重试 ${maxRetries} 次。最后错误: ${lastError.message}`);
  }

  async uploadToOSS(filePath, data) {
    const endpoint = `https://${this.ossConfig.bucket}.${this.ossConfig.region}.aliyuncs.com/${filePath}`;
    try {
      // 添加30秒超时控制
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);
      
      // 根据数据类型设置Content-Type
      let contentType = 'application/json';
      if (data instanceof Blob) {
        contentType = data.type || 'image/jpeg';
      }
      
      const response = await fetch(endpoint, {
        method: 'PUT',
        headers: {
          'Content-Type': contentType,
          'Authorization': this.generateOSSAuth('PUT', filePath, data.size || data.length || 0),
          'x-oss-date': new Date().toUTCString()
        },
        body: data,
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`OSS上传失败: ${response.status} - ${errorText}`);
      }

      return {
        url: endpoint,
        etag: response.headers.get('etag'),
        size: data.size || data.length
      };
    } catch (error) {
      if (error.name === 'TimeoutError') {
        throw new Error('上传超时（120秒），请检查网络连接');
      }
      throw error;
    }
  }

  generateOSSAuth(method, objectKey, contentLength) {
    const date = new Date().toUTCString();
    const canonicalizedResource = `/${this.ossConfig.bucket}${objectKey}`;
    const canonicalizedOSSHeaders = 'x-oss-date:' + date;
    const stringToSign = [
      method,
      '', // Content-MD5
      'application/json', // Content-Type
      date,
      canonicalizedOSSHeaders,
      canonicalizedResource
    ].join('\n');

    // 修复：使用正确的HMAC-SHA1签名
    return this.hmacSHA1(stringToSign, this.ossConfig.accessKeySecret).then(signature => {
      return `OSS ${this.ossConfig.accessKeyId}:${signature}`;
    });
  }

  async hmacSHA1(message, secret) {
    // 优先使用 Web Crypto API（现代浏览器）
    if (crypto && crypto.subtle) {
      try {
        const encoder = new TextEncoder();
        const cryptoKey = await crypto.subtle.importKey(
          'raw', encoder.encode(secret),
          { name: 'HMAC', hash: 'SHA-1' },
          false, ['sign']
        );
        const signature = await crypto.subtle.sign('HMAC', cryptoKey, encoder.encode(message));
        const signatureArray = Array.from(new Uint8Array(signature));
        return btoa(String.fromCharCode.apply(null, signatureArray));
      } catch (error) {
        console.warn('Web Crypto API 失败:', error);
      }
    }
    // 备选：JavaScript HMAC-SHA1
    return this.jsHmacSHA1(message, secret);
  }
  
  jsHmacSHA1(message, secret) {
    function rotl(n, s) { return (n << s) | (n >>> (32 - s)); }
    function sha1hex(str) {
      const hex = '0123456789abcdef';
      let h = '';
      for (let i = 0; i < str.length * 8; i += 8) {
        h += hex[(str.charCodeAt(i >> 5) >>> (24 - i % 32)) & 0xf];
        h += hex[(str.charCodeAt(i >> 5) >>> (16 - i % 32)) & 0xf];
        h += hex[(str.charCodeAt(i >> 5) >>> (8 - i % 32)) & 0xf];
        h += hex[(str.charCodeAt(i >> 5) >>> (0 - i % 32)) & 0xf];
      }
      return h;
    }
    function sha1add(x, y) { return ((x & 0x7fffffff) + (y & 0x7fffffff)) ^ (x & 0x80000000) ^ (y & 0x80000000); }
    
    const msg = unescape(encodeURIComponent(message));
    const words = [];
    for (let i = 0; i < msg.length; i++) words[i >> 2] |= (msg.charCodeAt(i) & 0xff) << (24 - (i % 4) * 8);
    words[msg.length >> 2] |= 0x80 << (24 - (msg.length % 4) * 8);
    words[(((msg.length + 8) >> 6) * 15) + 15] = msg.length * 8;
    
    let h0 = 0x67452301, h1 = 0xEFCDAB89, h2 = 0x98BADCFE, h3 = 0x10325476, h4 = 0xC3D2E1F0;
    
    for (let i = 0; i < words.length; i += 16) {
      const w = [];
      for (let j = 0; j < 16; j++) w[j] = words[i + j] || 0;
      for (let j = 16; j < 80; j++) w[j] = rotl(w[j-3] ^ w[j-8] ^ w[j-14] ^ w[j-16], 1);
      let a = h0, b = h1, c = h2, d = h3, e = h4;
      for (let j = 0; j < 80; j++) {
        let f, k;
        if (j < 20) { f = (b & c) | ((~b) & d); k = 0x5a827999; }
        else if (j < 40) { f = b ^ c ^ d; k = 0x6ed9eba1; }
        else if (j < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8f1bbcdc; }
        else { f = b ^ c ^ d; k = 0xca62c1d6; }
        const temp = sha1add(sha1add(rotl(a, 5), f), sha1add(sha1add(e, k), w[j]));
        e = d; d = c; c = rotl(b, 30); b = a; a = temp;
      }
      h0 = sha1add(h0, a); h1 = sha1add(h1, b); h2 = sha1add(h2, c);
      h3 = sha1add(h3, d); h4 = sha1add(h4, e);
    }
    
    const ipad = new Array(64).join('\x36');
    const opad = new Array(64).join('\x5c');
    const key = secret.length > 64 ? sha1hex(secret) : secret;
    let inner = '', outer = '';
    for (let i = 0; i < 64; i++) {
      inner += String.fromCharCode(key.charCodeAt(i) ^ ipad.charCodeAt(i));
      outer += String.fromCharCode(key.charCodeAt(i) ^ opad.charCodeAt(i));
    }
    return btoa(sha1hex(inner + message));
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  identifyBrand(title) {
    const titleLower = title.toLowerCase();
    const brandMap = {
      // 日系
      'toyota': 'Toyota', 'honda': 'Honda', 'nissan': 'Nissan', 'mazda': 'Mazda',
      'subaru': 'Subaru', 'mitsubishi': 'Mitsubishi', 'suzuki': 'Suzuki',
      'lexus': 'Lexus', 'infiniti': 'Infiniti', 'acura': 'Acura', 'scion': 'Scion',
      // 德系
      'bmw': 'BMW', 'mercedes': 'Mercedes-Benz', 'mercedes-benz': 'Mercedes-Benz',
      'audi': 'Audi', 'volkswagen': 'Volkswagen', 'vw ': 'Volkswagen', 'vw-': 'Volkswagen',
      'porsche': 'Porsche', 'opel': 'Opel', 'mini': 'Mini',
      // 美系
      'ford': 'Ford', 'chevrolet': 'Chevrolet', 'chevy': 'Chevrolet',
      'dodge': 'Dodge', 'gmc': 'GMC', 'jeep': 'Jeep', 'ram ': 'Ram', 'ram-': 'Ram',
      'cadillac': 'Cadillac', 'buick': 'Buick', 'lincoln': 'Lincoln',
      'chrysler': 'Chrysler', 'tesla': 'Tesla',
      // 韩系
      'hyundai': 'Hyundai', 'kia': 'Kia', 'genesis': 'Genesis', 'ssangyong': 'Ssangyong',
      // 法系
      'renault': 'Renault', 'peugeot': 'Peugeot', 'citroen': 'Citroën', 'ds': 'DS',
      // 英系
      'land rover': 'Land Rover', 'jaguar': 'Jaguar', 'mini ': 'Mini',
      // 意系
      'fiat': 'Fiat', 'alfa romeo': 'Alfa Romeo', 'lancia': 'Lancia',
      // 中国品牌
      'wuling': 'Wuling', 'baojun': 'Baojun', 'chery': 'Chery', 'geely': 'Geely',
      'byd': 'BYD', 'haval': 'Haval', 'great wall': 'Great Wall', 'greatwall': 'Great Wall',
      'changan': 'Changan', 'mg ': 'MG', 'roewe': 'Roewe', 'maxus': 'Maxus',
      'jac': 'JAC', 'faw': 'FAW', 'dongfeng': 'Dongfeng', 'gac': 'GAC',
      'nio': 'NIO', 'xpeng': 'XPeng', 'li auto': 'Li Auto', 'lione': 'Li Auto',
      'bestune': 'Bestune', 'hongqi': 'Hongqi', 'voyah': 'Voyah'
    };

    for (const [keyword, brand] of Object.entries(brandMap)) {
      if (titleLower.includes(keyword)) {
        return brand;
      }
    }
    return 'Universal';
  }

  updateStats(success) {
    this.stats.total++;
    if (success) {
      this.stats.success++;
    } else {
      this.stats.failed++;
    }
    if (!this.stats.startTime) {
      this.stats.startTime = new Date().toISOString();
    }
  }

  async saveStats() {
    try {
      await chrome.storage.local.set({
        collectorStats: this.stats,
        lastUpdate: new Date().toISOString()
      });
    } catch (error) {
      console.error('保存统计信息失败:', error);
    }
  }

  async updateConfiguration(newConfig) {
    try {
      if (newConfig.ossConfig) {
        this.ossConfig = { ...this.ossConfig, ...newConfig.ossConfig };
        await chrome.storage.sync.set({
          ossConfig: this.ossConfig,
          collectorConfig: newConfig.collectorConfig || {}
        });
        console.log('配置已更新:', this.ossConfig);
      }
    } catch (error) {
      console.error('更新配置失败:', error);
      throw error;
    }
  }

  notifyContentScript(tabId, message) {
    chrome.tabs.sendMessage(tabId, message).catch(error => {
      console.error('通知内容脚本失败:', error);
    });
  }

  // ========== 新增：products.json 管理功能 ==========

  // 获取当前的 products.json
  async getProductsJSON() {
    try {
      const endpoint = `${this.ossConfig.productsUrl}`;
      const response = await fetch(endpoint);
      
      if (response.ok) {
        const data = await response.json();
        console.log('获取products.json成功:', data);
        
        // 兼容数组格式和对象格式
        if (Array.isArray(data)) {
          // 数组格式：[{"id":1,...}, {"id":2,...}]
          console.log('检测到数组格式，产品数量:', data.length);
          return { success: true, data: data };
        } else if (data && typeof data === 'object' && Array.isArray(data.products)) {
          // 对象格式：{"products": [...], "lastUpdated": "..."}
          console.log('检测到对象格式，产品数量:', data.products.length);
          return { success: true, data: data.products };
        } else {
          // 格式无效，返回失败状态
          console.warn('products.json结构无效');
          return { success: false, error: 'products.json结构无效' };
        }
      } else if (response.status === 404) {
        // 文件不存在，返回空数组
        console.log('products.json不存在，返回空数组');
        return { success: true, data: [] };
      } else {
        throw new Error(`获取products.json失败: ${response.status}`);
      }
    } catch (error) {
      console.error('获取products.json失败:', error);
      // 网络不稳定时返回失败状态，不返回空数组
      return { success: false, error: '网络不稳定，读取products.json失败' };
    }
  }

  // 更新 products.json
  async updateProductsJSON(fileName, productInfo) {
    try {
      console.log('开始更新products.json，添加文件:', fileName);
      
      // 获取当前的 products.json
      const result = await this.getProductsJSON();
      
      // 检查是否读取成功
      if (!result.success) {
        console.error('❌ 更新products.json失败:', result.error);
        console.error('⚠️ 产品已上传到OSS，但未加入产品列表');
        console.error('⚠️ 请稍后重新采集以添加到产品列表');
        // OSS上传已成功，products.json更新失败不影响采集状态
        return { success: true, warning: result.error };
      }
      
      // 获取产品数组
      let productsArray = result.data || [];
      
      // 检查产品数量是否合理（防止意外覆盖）
      if (productsArray.length === 0) {
        console.warn('⚠️ products.json为空，将创建新产品列表');
      }
      
      // 检查是否已存在该产品
      const exists = productsArray.some(p => {
        // 兼容不同的数据结构
        const productFileName = p.fileName || p.name || p.title || JSON.stringify(p);
        return productFileName === fileName;
      });
      
      if (exists) {
        console.log('产品已存在，跳过添加:', fileName);
        return { success: true, message: '产品已存在' };
      }
      
      // 添加新产品到列表（最新产品在最前面）
      productsArray.unshift({
        fileName: fileName,
        ...productInfo
      });

      // 对整个数组进行格式检测和转换，确保所有产品都是扁平格式
      const convertedProductsArray = productsArray.map(product => {
        // 检查是否需要转换
        if (product.product || product.metadata) {
          // 嵌套格式，需要转换
          const flatProduct = this.convertNestedToFlat(product);
          return {
            fileName: product.fileName,
            ...flatProduct
          };
        }
        // 扁平格式，确保有fileName字段
        if (!product.fileName) {
          // 如果没有fileName，根据其他信息生成一个
          const timestamp = product.id || Date.now();
          const oemCode = product.oem || 'no-oem';
          const sanitizedTitle = (product.title || '').substring(0, 30).replace(/[^a-zA-Z0-9_-]/g, '_');
          product.fileName = `${timestamp}_${oemCode}_${sanitizedTitle}.json`;
        }
        return product;
      });

      // 更新时间戳
      const updatedData = Array.isArray(result.data)
        ? convertedProductsArray
        : {
            products: convertedProductsArray,
            lastUpdated: new Date().toISOString()
          };
      
      // 转换为JSON字符串
      const jsonData = JSON.stringify(updatedData, null, 2);
      
      // 上传到OSS
      const endpoint = `${this.ossConfig.productsUrl}`;
      const auth = await this.generateOSSAuth('PUT', '/products.json', jsonData.length);
      
      const response = await fetch(endpoint, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': auth,
          'x-oss-date': new Date().toUTCString()
        },
        body: jsonData
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`更新products.json失败: ${response.status} - ${errorText}`);
      }
      
      console.log('✅ products.json更新成功，当前产品数量:', productsArray.length);
      // 更新version.json，触发后台刷新
      await this.updateVersionJSON("plugin_collect");
      return {
        success: true,
        productCount: productsArray.length
      };
    } catch (error) {
      console.error('更新products.json失败:', error);
      throw error;
    }
  }
  
  // 更新 version.json（新增）
  async updateVersionJSON(source = 'plugin') {
    try {
      const newVersion = Date.now();
      const versionData = {
        version: newVersion,
        timestamp: new Date(newVersion).toISOString(),
        source: source
      };
      
      const jsonData = JSON.stringify(versionData, null, 2);
      const endpoint = `https://${this.ossConfig.bucket}.${this.ossConfig.region}.aliyuncs.com/version.json`;
      const auth = await this.generateOSSAuth('PUT', '/version.json', jsonData.length);
      
      const response = await fetch(endpoint, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': auth,
          'x-oss-date': new Date().toUTCString()
        },
        body: jsonData
      });
      
      if (!response.ok) {
        console.error('更新version.json失败:', response.status);
        return { success: false };
      }
      
      console.log('✅ version.json更新成功:', newVersion);
      return { success: true, version: newVersion };
    } catch (error) {
      console.error('更新version.json失败:', error);
      return { success: false };
    }
  }

  // v2.3.0: 更新单个产品的 SEO 状态（pending → published）
  async updateProductSEOStatus(productId, status, seoUrl = null) {
    try {
      const result = await this.getProductsJSON();
      if (!result.success) return { success: false, error: result.error };

      const productsArray = result.data || [];
      const idx = productsArray.findIndex(p => String(p.id) === String(productId));

      if (idx === -1) {
        console.warn('产品不存在:', productId);
        return { success: false, error: '产品不存在' };
      }

      productsArray[idx].seo_status = status;
      productsArray[idx].seo_published_at = status === 'published' ? new Date().toISOString() : null;
      if (seoUrl) {
        productsArray[idx].seo_url = seoUrl;
      }

      const jsonData = JSON.stringify(productsArray, null, 2);
      const endpoint = this.ossConfig.productsUrl;
      const auth = await this.generateOSSAuth('PUT', '/products.json', jsonData.length);

      const response = await fetch(endpoint, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': auth,
          'x-oss-date': new Date().toUTCString()
        },
        body: jsonData
      });

      if (!response.ok) {
        throw new Error(`更新产品状态失败: ${response.status}`);
      }

      console.log(`✅ 产品 ${productId} 状态更新: ${status}`);
      return { success: true };
    } catch (error) {
      console.error('更新产品状态失败:', error);
      return { success: false, error: error.message };
    }
  }

  // ========== SEO自动优化功能 ==========
  
  // GitHub API 请求（带多Token轮换和重试机制）
  async githubRequest(url, options, retries = 10, delay = 3000) {
    const tokens = this.githubConfig.tokens;
    let tokenIndex = this.githubConfig.currentTokenIndex || 0;
    
    // 每小时重置请求计数
    const now = Date.now();
    const hourMs = 60 * 60 * 1000;
    if (now - this.githubConfig.lastTokenResetTime > hourMs) {
      this.githubConfig.requestsThisHour = 0;
      this.githubConfig.lastTokenResetTime = now;
      tokenIndex = 0;
      console.log('🔄 Token请求计数已重置（新的一小时）');
    }
    
    for (let i = 0; i < retries; i++) {
      // 获取当前Token
      const currentToken = tokens[tokenIndex];
      
      // 修改Authorization header使用当前Token
      const modifiedOptions = { ...options };
      if (modifiedOptions.headers && typeof modifiedOptions.headers === 'object') {
        modifiedOptions.headers = { ...modifiedOptions.headers };
        modifiedOptions.headers['Authorization'] = 'token ' + currentToken;
      }
      
      try {
        this.githubConfig.requestsThisHour++;
        const response = await fetch(url, modifiedOptions);
        
        // 如果触发限流，切换到下一个Token
        if (response.status === 403 || response.status === 429) {
          tokenIndex = (tokenIndex + 1) % tokens.length;
          this.githubConfig.currentTokenIndex = tokenIndex;
          const waitTime = parseInt(response.headers.get('Retry-After')) || delay * 2;
          console.log(`⚠️ Token ${tokenIndex} 限流，切换到Token ${tokenIndex + 1}，等待${waitTime}ms`);
          await this.sleep(Math.min(waitTime, 60000));
          continue;
        }
        
        // 服务器错误，等待后重试
        if (response.status >= 500) {
          const waitTime = delay * (i + 1);
          console.log(`⚠️ GitHub服务器错误(${response.status})，等待${waitTime}ms后重试 (${i + 1}/${retries})`);
          await this.sleep(waitTime);
          continue;
        }
        
        return response;
      } catch (error) {
        if (i === retries - 1) throw error;
        console.log(`⚠️ 请求失败，Token ${tokenIndex + 1}，等待${delay * (i + 1)}ms后重试 (${i + 1}/${retries})`);
        await this.sleep(delay * (i + 1));
      }
    }
    throw new Error('GitHub API 请求失败，已重试' + retries + '次');
  }
  
  // 获取当前使用的Token
  getCurrentToken() {
    const tokenIndex = this.githubConfig.currentTokenIndex || 0;
    return this.githubConfig.tokens[tokenIndex];
  }
  
  // 获取Token使用状态
  getTokenStatus() {
    return {
      currentTokenIndex: this.githubConfig.currentTokenIndex || 0,
      requestsThisHour: this.githubConfig.requestsThisHour || 0,
      totalTokens: this.githubConfig.tokens ? this.githubConfig.tokens.length : 0,
      currentToken: this.getCurrentToken()
    };
  }
  
  // 延迟函数
  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  // ========== v4-gen_2imgs: 15-category SEO page generator ==========
  // Inlined from gen_2imgs.py (1654 lines) → JS, validated against 971 products shipped 22:34.
  // 7 sections: What is OEM + Application + Symptoms + Installation + FAQ + Wholesale Process + About Us
  // 3 Schemas: Product + HowTo + FAQPage (JSON-LD)

  // ---------- 1. Category detection (15 categories) ----------
  detectCategory(name) {
    const n = (name || '').toLowerCase();
    const has = (kws) => kws.some(k => n.includes(k));
    if (has(['lower guard', 'engine guard', 'skid plate', 'under cover', 'underbody', 'engine cover', 'underbody shield'])) return 'lower_guard';
    if (has(['brake pad', 'brake disc', 'brake rotor', 'brake caliper', 'brake shoe'])) return 'brake';
    if (has(['headlight', 'head lamp', 'headlamp', 'tail light', 'taillight', 'fog light', 'signal light', 'corner light'])) return 'light';
    if (has(['engine oil', 'motor oil', 'lubricant', 'gear oil', 'transmission oil', 'transmission fluid', 'atf', 'atf+', 'dexron', 'mercon', 'cvt fluid', 'dct fluid', 'cvt oil', 'dct oil', '5w-', '5w30', '5w40', '5w-30', '5w-40', '0w-', '0w20', '0w30', '0w40', '10w-', '10w40', '15w-', '15w40', '20w-', '20w50', ' synthetic oil', 'semi-synthetic oil', 'full synthetic oil', 'engine fluid', 'cvt', 'mercon v', 'mercon lv', 'dexron vi', 'dexron iii', 'afw+', 'lifetime warranty'])) return 'oil';
    if (has(['bumper', 'grille', 'fender', 'hood', 'door panel', 'tailgate'])) return 'body';
    if (has(['intake manifold', 'throttle body', 'air filter housing'])) return 'intake';
    if (has(['radiator', 'cooling fan', 'thermostat', 'coolant tank'])) return 'cooling';
    if (has(['shock absorber', 'shock', 'strut', 'spring', 'suspension'])) return 'suspension';
    if (has(['oil filter', 'air filter', 'fuel filter', 'cabin filter', 'filter'])) return 'filter';
    if (has(['oxygen sensor', 'o2 sensor', 'abs sensor', 'wheel speed sensor', 'sensor'])) return 'sensor';
    if (has(['side mirror', 'rearview mirror', 'wing mirror', 'mirror'])) return 'mirror';
    if (has(['alternator', 'starter motor', 'ignition coil', 'spark plug'])) return 'electrical';
    if (has(['water pump', 'fuel pump', 'oil pump', 'pump'])) return 'pump';
    if (has(['cv joint', 'drive shaft', 'axle', 'half shaft'])) return 'drivetrain';
    return 'general';
  }

  // ---------- 3. Helper: get all images (max 2) ----------
  getAllSEOUrls(productData) {
    const safeImgs = [];
    const seen = new Set();
    const candidates = [];
    // First try .images[] (collected images)
    if (Array.isArray(productData.images)) candidates.push(...productData.images);
    // Then comma-separated .image
    if (productData.image && typeof productData.image === 'string') {
      candidates.push(...productData.image.split(',').map(s => s.trim()));
    }
    // Then .ossImages (uploaded to OSS)
    if (Array.isArray(productData.ossImages)) candidates.push(...productData.ossImages);

    const PLACEHOLDER = 'https://cdn.jsdelivr.net/gh/carvalauto/carvalauto.github.io@main/placeholder.jpg';
    for (const url of candidates) {
      if (!url || !url.startsWith('http')) continue;
      if (seen.has(url)) continue;
      // Filter out blocked / risky domains (matches gen_2imgs.py)
      const u = url.toLowerCase();
      if (u.includes('ebayimg.com') || u.includes('media-amazon.com')) continue;
      const risky = ['hoover', 'bosch', 'ngk', 'denso', 'mopar', 'acdelco', 'motorcraft',
                     'mahle', 'mann', 'valeo', 'hella', 'wix', 'fram', 'champion',
                     'brembo', 'febi', 'sachs', 'liqui', 'moly', 'shell-', 'mobil-',
                     'castrol', 'motul', 'meguiars', 'mothers',
                     'gates-', 'dayco', 'continental', 'aisin', 'exedy', 'luk',
                     'k&n', 'aem-', 'aemintake', 'knfilter',
                     'wurth', 'permatex', 'loctite', 'sonax', 'autoglym'];
      if (risky.some(k => u.includes(k))) continue;
      seen.add(url);
      safeImgs.push(url);
      if (safeImgs.length >= 2) return safeImgs;
    }
    return safeImgs.length ? safeImgs : [PLACEHOLDER];
  }

  // ---------- 4. Helper: vehicle summary from fitmentTable ----------
  getVehicleSummary(productData) {
    if (!Array.isArray(productData.fitmentTable) || !productData.fitmentTable.length) {
      return null;
    }
    const makes = new Set(), models = new Set(), years = new Set();
    for (const f of productData.fitmentTable) {
      if (f.make) makes.add(f.make);
      if (f.model) models.add(f.model);
      if (f.year) years.add(String(f.year).slice(0, 4));
    }
    if (!makes.size && !models.size && !years.size) return null;
    const sortedMakes = [...makes].sort().slice(0, 3);
    const sortedModels = [...models].sort().slice(0, 3);
    const yearArr = [...years].sort();
    const yearStr = yearArr.length > 1 ? `${yearArr[0]}-${yearArr[yearArr.length-1]}` : (yearArr[0] || '');
    return {
      make: sortedMakes.join(', ') || 'multiple',
      model: sortedModels.join(', ') || 'variants',
      year: yearStr,
      count: productData.fitmentTable.length,
      first: productData.fitmentTable[0] || null
    };
  }

  getMainVehicle(productData) {
    const s = this.getVehicleSummary(productData);
    if (!s) return null;
    return `${s.make} ${s.model} ${s.year}`.trim();
  }

  // ---------- 5. Find related products (best-effort, no all_products cache) ----------
  findRelatedProductsFallback(productData) {
    // We don't have all_products in handleSEOUpload context, so use brand/category siblings
    // from the data we DO have. Empty fallback.
    return [];
  }

  // ---------- 6. Schema: Product ----------
  buildProductSchema(productData, url, catContent) {
    const images = this.getAllSEOUrls(productData);
    const firstImage = images[0];
    const name = productData.name || productData.title || '';
    const oem = productData.oem || productData.oemCode || '';
    return {
      "@context": "https://schema.org",
      "@type": "Product",
      "name": name,
      "productID": String(productData.id || ''),
      "sku": oem || String(productData.id || ''),
      "mpn": oem,
      "brand": { "@type": "Brand", "name": "Carval Auto Parts" },
      "description": (productData.description || '').slice(0, 500) || name,
      "image": images.slice(0, 5).length ? images.slice(0, 5) : [firstImage],
      "url": url,
      "offers": {
        "@type": "Offer",
        "priceCurrency": "USD",
        "availability": "https://schema.org/ContactForOffer",
        "seller": { "@type": "Organization", "name": "Guangzhou Carval Auto Parts Co., Ltd." }
      }
    };
  }

  // ---------- 7. Schema: HowTo ----------
  buildHowToSchema(productData, catContent) {
    const name = productData.name || productData.title || '';
    const oem = productData.oem || '';
    const vehicle = this.getMainVehicle(productData) || 'your vehicle';
    const steps = (catContent.install_steps || []).map(([stepName, stepText]) => ({
      "@type": "HowToStep",
      "name": stepName,
      "text": stepText
    }));
    return {
      "@context": "https://schema.org",
      "@type": "HowTo",
      "name": `How to install ${name} on ${vehicle}`,
      "step": steps,
      "totalTime": "PT30M"
    };
  }

  // ---------- 8. Schema: FAQPage ----------
  buildFAQSchema(productData, catContent) {
    const name = productData.name || productData.title || '';
    const oem = productData.oem || productData.oemCode || '';
    const summary = this.getVehicleSummary(productData);
    const faqs = [];
    // Q1: category-specific
    faqs.push({
      "@type": "Question",
      "name": catContent.faq_q1,
      "acceptedAnswer": { "@type": "Answer", "text": catContent.faq_a1 }
    });
    // Q2: compatibility
    if (summary) {
      faqs.push({
        "@type": "Question",
        "name": oem
          ? `What vehicles is ${oem} compatible with?`
          : `What vehicles is this part compatible with?`,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": `This part fits ${summary.count} variants of ${summary.make} ${summary.model} ${summary.year}. Please check the fitment table on this page for the complete list of compatible vehicles.`
        }
      });
    } else {
      faqs.push({
        "@type": "Question",
        "name": oem
          ? `What vehicles is ${oem} compatible with?`
          : `What vehicles is this part compatible with?`,
        "acceptedAnswer": {
          "@type": "Answer",
          "text": `This part is designed for compatible vehicles. Contact us with your vehicle make, model, and year to confirm compatibility before ordering.`
        }
      });
    }
    // Q3: installation
    faqs.push({
      "@type": "Question",
      "name": `How do I install ${name}?`,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": `Installation takes about ${catContent.install_time} with basic hand tools. The detailed step-by-step guide is available on this page. Skill level required: ${catContent.install_skill}.`
      }
    });
    // Q4: symptoms
    faqs.push({
      "@type": "Question",
      "name": `What are the symptoms that indicate replacement?`,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": catContent.symptoms_intro + ' ' + (catContent.symptoms || []).slice(0, 3).join(' ')
      }
    });
    // Q5: direct replacement
    faqs.push({
      "@type": "Question",
      "name": "Is this a direct OEM replacement?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, this is an OEM-equivalent replacement part. It matches the original specifications, fitment, and durability of the factory-installed part, with direct installation requiring no modifications."
      }
    });
    // Q6: MOQ
    faqs.push({
      "@type": "Question",
      "name": "What is the MOQ for wholesale orders?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Minimum order quantity (MOQ) is 5 pieces. Mixed model orders are accepted. Sample orders are also available for quality testing, with the sample fee refundable on bulk orders."
      }
    });
    // Q7: warranty
    faqs.push({
      "@type": "Question",
      "name": "What is the warranty on this part?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "All parts come with a 12-month quality warranty covering manufacturing defects. In the unlikely event of a defect, we provide free replacement or full refund."
      }
    });
    return { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": faqs };
  }

  // ---------- 9. HTML builder: assembles the 7 sections ----------
  buildSEOHtml(productData, catContent, productSchema, howtoSchema, faqSchema) {
    const name = (productData.name || productData.title || '').toString();
    const oem = productData.oem || productData.oemCode || '';
    const description = productData.description || '';
    const images = this.getAllSEOUrls(productData);
    const firstImage = images[0];
    const productId = productData.id || Date.now();
    const summary = this.getVehicleSummary(productData);
    const mainVehicle = this.getMainVehicle(productData);

    // Title & meta
    const title = (() => {
      const n = name.slice(0, 70);
      if (oem) return `${n} OEM ${oem} | Wholesale Supplier`.slice(0, 60);
      return `${n} | Wholesale Auto Parts`.slice(0, 60);
    })();
    let metaDesc = name.slice(0, 60);
    if (oem) metaDesc += ` OEM: ${oem}`;
    if (summary) metaDesc += ` for ${summary.make} ${summary.model} ${summary.year} (${summary.count} variants)`;
    metaDesc += ' | Application + Installation Guide | Wholesale MOQ 5pcs | Free Quote';
    metaDesc = metaDesc.slice(0, 160);

    // File name: {id}.html (preserves the safeId pattern)
    const slug = String(productId);
    const url = `https://carvalautopart.com/products/${slug}.html`;

    // 1) Fitment table HTML
    let fitmentHtml = '';
    if (summary && Array.isArray(productData.fitmentTable)) {
      fitmentHtml = `
        <div class="fitment-section">
            <h2>Vehicle Fitment (${summary.count} Compatible Variants)</h2>
            <table class="fitment-table">
                <thead>
                    <tr><th>Make</th><th>Model</th><th>Year</th><th>Engine</th></tr>
                </thead>
                <tbody>`;
      for (const row of productData.fitmentTable.slice(0, 15)) {
        if (row.make && row.model) {
          fitmentHtml += `
                    <tr><td>${this.htmlEsc(row.make)}</td><td>${this.htmlEsc(row.model)}</td><td>${this.htmlEsc(row.year || '')}</td><td>${this.htmlEsc(row.engine || '')}</td></tr>`;
        }
      }
      fitmentHtml += `
                </tbody>
            </table>
        </div>`;
    }

    // 2) Compatibility check
    let compatHtml = '';
    if (summary) {
      const firstFit = summary.first || {};
      const engineDesc = firstFit.engine || '';
      if (engineDesc) {
        compatHtml = `
            <div class="compatibility-check">
                <strong>Quick Compatibility Check:</strong> Does your ${this.htmlEsc(summary.make)} ${this.htmlEsc(summary.model)} have a ${this.htmlEsc(engineDesc)} engine made between ${this.htmlEsc(summary.year)}? If yes, this ${this.htmlEsc(oem || 'part')} is compatible with your vehicle.
            </div>`;
      } else {
        compatHtml = `
            <div class="compatibility-check">
                <strong>Quick Compatibility Check:</strong> Confirm your ${this.htmlEsc(summary.make)} ${this.htmlEsc(summary.model)} (${this.htmlEsc(summary.year)}) matches the ${summary.count} variants in the fitment table on this page.
            </div>`;
      }
    }

    // 3) Application cards
    let appHtml = '';
    for (const [cardTitle, items] of (catContent.app_cards || [])) {
      appHtml += `                <div class="app-card">
                    <h4>${this.htmlEsc(cardTitle)}</h4>
                    <ul>
`;
      for (const item of items) {
        appHtml += `                        <li>${this.htmlEsc(item)}</li>
`;
      }
      appHtml += `                    </ul>
                </div>
`;
    }

    // 4) Symptoms list
    let symptomsHtml = '';
    for (const s of (catContent.symptoms || [])) {
      symptomsHtml += `                    <li>${this.htmlEsc(s)}</li>
`;
    }

    // 5) Install steps
    let installHtml = '';
    (catContent.install_steps || []).forEach(([stepName, stepText], idx) => {
      installHtml += `            <div class="install-step">
                <div class="install-num">${idx + 1}</div>
                <div class="install-content">
                    <h4>${this.htmlEsc(stepName)}</h4>
                    <p>${this.htmlEsc(stepText)}</p>
                </div>
            </div>
`;
    });

    // 6) Related products (best-effort empty fallback)
    const relatedProducts = this.findRelatedProductsFallback(productData);
    let relatedHtml = '';
    if (relatedProducts.length) {
      for (const rp of relatedProducts) {
        const rpName = (rp.name || 'Related Part').slice(0, 50);
        const rpOem = rp.oem || rp.oemCode || '';
        const rpId = rp.id || '';
        relatedHtml += `                <a href="/products/${rpId}.html" class="related-card">
                    <div style="font-size: 2rem;">🔧</div>
                    <div class="oem">OEM ${this.htmlEsc(rpOem || '—')}</div>
                    <div class="name">${this.htmlEsc(rpName)}</div>
                </a>
`;
      }
    } else {
      // Fallback: 3 catalog links
      relatedHtml = `                <a href="/products.html" class="related-card">
                    <div style="font-size: 2rem;">🔧</div>
                    <div class="oem">Browse All Parts</div>
                    <div class="name">View all auto parts catalog</div>
                </a>
                <a href="/japanese-cars.html" class="related-card">
                    <div style="font-size: 2rem;">🚗</div>
                    <div class="oem">Japanese Cars</div>
                    <div class="name">OEM parts for Japanese vehicles</div>
                </a>
                <a href="/korean-cars.html" class="related-card">
                    <div style="font-size: 2rem;">🚙</div>
                    <div class="oem">Korean Cars</div>
                    <div class="name">OEM parts for Korean vehicles</div>
                </a>
`;
    }

    // 7) FAQ HTML
    let faqHtml = '';
    for (const q of faqSchema.mainEntity) {
      faqHtml += `            <div class="faq-item">
                <div class="faq-q">${this.htmlEsc(q.name)}</div>
                <div class="faq-a">${this.htmlEsc(q.acceptedAnswer.text)}</div>
            </div>
`;
    }

    // 8) Description
    let descHtml = '';
    if (description) {
      const paras = description.includes('\n') ? description.split('\n') : [description];
      for (const p of paras.slice(0, 3)) {
        const t = p.trim();
        if (t) descHtml += `                <p>${this.htmlEsc(t)}</p>
`;
      }
    } else {
      descHtml = `                <p>OEM <strong>${this.htmlEsc(oem || name)}</strong> is a high-quality replacement part for ${this.htmlEsc(mainVehicle || 'compatible vehicles')}. Manufactured to meet original factory specifications for fit, function, and durability.</p>
`;
    }

    // 9) Thumbs (max 2)
    const imagesJson = JSON.stringify(images).replace(/'/g, "&#39;");
    let thumbHtml = '';
    let imgCounterHtml = '';
    if (images.length > 1) {
      const thumbItems = [];
      images.slice(0, 2).forEach((img, i) => {
        const active = i === 0 ? ' active' : '';
        const alt = oem
          ? `${name} - Product Image ${i + 1} of ${images.length} - OEM ${oem}`
          : `${name} - Product Image ${i + 1} of ${images.length}`;
        thumbItems.push(`<img src="${this.htmlEsc(img)}" alt="${this.htmlEsc(alt)}" class="thumb${active}" data-idx="${i}" loading="lazy">`);
      });
      thumbHtml = thumbItems.join('\n                    ');
      imgCounterHtml = `<div class="img-counter" id="imgCounter">Image 1 of ${images.length} - Click thumbnails to view all product images</div>`;
    }

    // 10) Company gallery
    const cdn = 'https://cdn.jsdelivr.net/gh/carvalauto/carvalauto.github.io@main';
    const companyData = [
      [`${cdn}/office1.jpg`, 'Guangzhou Carval Auto Parts Office - Reception Area'],
      [`${cdn}/office2.jpg`, 'Carval Auto Parts Sales Office in Guangzhou'],
      [`${cdn}/repair1.jpg`, 'Carval Auto Repair Shop - Diagnostic Equipment'],
      [`${cdn}/repair2.jpg`, 'Guangzhou Carval Vehicle Repair Workshop'],
      [`${cdn}/factory1.jpg`, 'Carval Auto Parts Warehouse and Factory Floor'],
      [`${cdn}/factory2.jpg`, 'Carval OEM Auto Parts Manufacturing Facility']
    ];
    const companyItems = companyData.map(([u, a]) =>
      `<figure><img src="${u}" alt="${this.htmlEsc(a)}" loading="lazy"><figcaption>${this.htmlEsc(a)}</figcaption></figure>`
    );
    const companyGalleryHtml = companyItems.join('\n                    ');

    const whatIsHtml = `
        <div class="product-desc">
            <h2>What is OEM ${this.htmlEsc(oem || name.slice(0, 30))}?</h2>
${descHtml}            ${compatHtml}
        </div>`;

    const categoryName = (productData.category || 'other').toString();

    // Compose final HTML (template literal)
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${this.htmlEsc(title)}</title>
    <meta name="description" content="${this.htmlEsc(metaDesc)}">
    <meta name="keywords" content="${this.htmlEsc(name)}, OEM auto parts, wholesale auto parts, ${this.htmlEsc(categoryName)}, ${this.htmlEsc(oem)}, ${this.htmlEsc(mainVehicle || 'auto parts')}">
    <link rel="canonical" href="${url}">
    <meta property="og:title" content="${this.htmlEsc(title)}">
    <meta property="og:description" content="${this.htmlEsc(metaDesc)}">
    <meta property="og:image" content="${firstImage}">
    <meta property="og:url" content="${url}">
    <meta property="og:type" content="product">
    <meta property="og:site_name" content="Carval Auto Parts">
    <link rel="alternate" hreflang="en" href="${url}">
    <link rel="alternate" hreflang="x-default" href="${url}">

    <script type="application/ld+json">
${JSON.stringify(productSchema, null, 2)}
    </script>
    <script type="application/ld+json">
${JSON.stringify(howtoSchema, null, 2)}
    </script>
    <script type="application/ld+json">
${JSON.stringify(faqSchema, null, 2)}
    </script>

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; line-height: 1.6; color: #333; background: #f5f5f5; }
        .header { background: #2c3e50; color: white; padding: 20px; text-align: center; }
        .header a { color: #3498db; text-decoration: none; font-size: 1.5rem; font-weight: bold; }
        .header .sub { font-size: 0.9rem; margin-top: 5px; opacity: 0.9; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .breadcrumb { padding: 15px 0; font-size: 0.9rem; }
        .breadcrumb a { color: #3498db; text-decoration: none; }
        .breadcrumb span { color: #999; margin: 0 5px; }
        .product-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .main-image { width: 100%; height: 400px; object-fit: contain; border: 1px solid #ddd; border-radius: 4px; background: #fafafa; cursor: zoom-in; transition: opacity 0.2s; }
        .main-image.loading { opacity: 0.5; }
        .thumb-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; margin-top: 12px; }
        .thumb-grid img { width: 100%; height: 70px; object-fit: cover; border: 2px solid transparent; border-radius: 4px; cursor: pointer; background: #fafafa; transition: border-color 0.2s; }
        .thumb-grid img:hover { border-color: #3498db; }
        .thumb-grid img.active { border-color: #e74c3c; }
        .img-counter { font-size: 0.85rem; color: #666; margin-top: 8px; text-align: center; }
        .company-gallery { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .company-gallery h3 { color: #2c3e50; margin-bottom: 18px; font-size: 1.2rem; padding-bottom: 10px; border-bottom: 2px solid #3498db; }
        .company-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
        .company-grid figure { margin: 0; }
        .company-grid img { width: 100%; height: 180px; object-fit: cover; border-radius: 6px; box-shadow: 0 1px 4px rgba(0,0,0,0.1); }
        .company-grid figcaption { font-size: 0.82rem; color: #666; margin-top: 6px; text-align: center; line-height: 1.3; }
        .product-info h1 { font-size: 1.4rem; margin-bottom: 15px; color: #2c3e50; }
        .oem-badge { background: #e8f4f8; padding: 12px 15px; border-radius: 4px; margin: 15px 0; font-weight: bold; border-left: 4px solid #3498db; }
        .oem-badge span { color: #3498db; }
        .fitment-summary { background: #f0f7ff; padding: 12px; border-radius: 6px; margin: 15px 0; }
        .product-desc { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .product-desc h2 { color: #2c3e50; margin-bottom: 15px; font-size: 1.3rem; padding-bottom: 10px; border-bottom: 2px solid #3498db; }
        .product-desc p { margin-bottom: 12px; color: #555; }
        .compatibility-check { background: #f0f7ff; padding: 15px 20px; border-radius: 6px; margin: 15px 0; border-left: 4px solid #2196f3; }
        .compatibility-check strong { color: #1976d2; }
        .fitment-section { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .fitment-section h2 { color: #2c3e50; margin-bottom: 20px; font-size: 1.3rem; padding-bottom: 10px; border-bottom: 2px solid #3498db; }
        .fitment-table { width: 100%; border-collapse: collapse; }
        .fitment-table th { background: #3498db; color: white; padding: 12px; text-align: left; }
        .fitment-table td { padding: 10px 12px; border-bottom: 1px solid #eee; }
        .fitment-table tr:hover { background: #f8f9fa; }
        .b2b-info { background: #fff9e6; padding: 25px; border-radius: 8px; border-left: 4px solid #f39c12; margin-bottom: 20px; }
        .b2b-info h3 { color: #d35400; margin-bottom: 15px; font-size: 1.2rem; }
        .b2b-info ul { list-style: none; padding-left: 0; }
        .b2b-info li { padding: 6px 0; color: #555; }
        .b2b-info li::before { content: "✓ "; color: #27ae60; font-weight: bold; margin-right: 8px; }
        .shipping-info { background: #e8f5e9; padding: 25px; border-radius: 8px; margin-bottom: 20px; }
        .shipping-info h3 { color: #2e7d32; margin-bottom: 15px; font-size: 1.2rem; }
        .shipping-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-top: 15px; }
        .shipping-card { background: white; padding: 15px; border-radius: 6px; text-align: center; }
        .shipping-card h4 { color: #2c3e50; margin-bottom: 8px; }
        .shipping-card p { color: #666; font-size: 0.9rem; }
        .about-us { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .about-us h2 { color: #2c3e50; margin-bottom: 20px; font-size: 1.3rem; padding-bottom: 10px; border-bottom: 2px solid #3498db; }
        .about-intro { color: #555; line-height: 1.8; margin-bottom: 20px; }
        .about-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin: 20px 0; }
        .about-card { text-align: center; padding: 15px; background: #f8f9fa; border-radius: 6px; }
        .about-card .num { font-size: 2rem; font-weight: bold; color: #3498db; }
        .about-card .label { color: #666; font-size: 0.9rem; }
        .contact { background: #2c3e50; color: white; padding: 25px; border-radius: 8px; }
        .contact h3 { margin-bottom: 15px; }
        .contact-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .contact-item { display: flex; align-items: center; gap: 10px; }
        .contact-item a { color: #3498db; text-decoration: none; }
        .cta-button { display: inline-block; background: #e74c3c; color: white; padding: 12px 30px; border-radius: 4px; text-decoration: none; font-weight: bold; margin-top: 15px; }
        .cta-button:hover { background: #c0392b; }
        .faq-section { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .faq-section h2 { color: #2c3e50; margin-bottom: 20px; font-size: 1.3rem; padding-bottom: 10px; border-bottom: 2px solid #3498db; }
        .faq-item { padding: 18px; border-bottom: 1px solid #eee; }
        .faq-item:last-child { border-bottom: none; }
        .faq-q { font-weight: bold; color: #2c3e50; font-size: 1.05rem; margin-bottom: 8px; }
        .faq-q::before { content: "Q: "; color: #e74c3c; font-weight: bold; }
        .faq-a { color: #555; padding-left: 20px; }
        .faq-a::before { content: "A: "; color: #27ae60; font-weight: bold; }
        .process-section { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .process-section h2 { color: #2c3e50; margin-bottom: 20px; font-size: 1.3rem; padding-bottom: 10px; border-bottom: 2px solid #3498db; }
        .steps { counter-reset: step-counter; list-style: none; padding-left: 0; }
        .steps li { counter-increment: step-counter; padding: 12px 12px 12px 50px; position: relative; margin-bottom: 10px; background: #f8f9fa; border-radius: 4px; color: #555; }
        .steps li::before { content: counter(step-counter); position: absolute; left: 12px; top: 12px; background: #3498db; color: white; width: 28px; height: 28px; border-radius: 50%; text-align: center; line-height: 28px; font-weight: bold; }
        .application-section { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .application-section h2 { color: #2c3e50; margin-bottom: 20px; font-size: 1.3rem; padding-bottom: 10px; border-bottom: 2px solid #3498db; }
        .app-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 15px; }
        .app-card { background: #f8f9fa; padding: 20px; border-radius: 6px; border-left: 4px solid #27ae60; }
        .app-card h4 { color: #27ae60; margin-bottom: 10px; font-size: 1.05rem; }
        .app-card ul { list-style: none; padding-left: 0; }
        .app-card li { padding: 5px 0 5px 22px; position: relative; color: #555; font-size: 0.95rem; }
        .app-card li::before { content: "▸"; position: absolute; left: 5px; top: 5px; color: #27ae60; font-weight: bold; }
        .symptom-section { background: #fff3e0; padding: 25px; border-radius: 8px; border-left: 4px solid #ff9800; margin-bottom: 20px; }
        .symptom-section h3 { color: #e65100; margin-bottom: 15px; font-size: 1.2rem; }
        .symptom-section ul { list-style: none; padding-left: 0; }
        .symptom-section li { padding: 8px 0 8px 25px; position: relative; color: #555; }
        .symptom-section li::before { content: "⚠️"; position: absolute; left: 0; top: 8px; }
        .install-section { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .install-section h2 { color: #2c3e50; margin-bottom: 20px; font-size: 1.3rem; padding-bottom: 10px; border-bottom: 2px solid #3498db; }
        .install-meta { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin: 20px 0; }
        .install-meta-card { background: #f0f7ff; padding: 15px; border-radius: 6px; text-align: center; }
        .install-meta-card .icon { font-size: 1.8rem; margin-bottom: 5px; }
        .install-meta-card .label { color: #666; font-size: 0.85rem; }
        .install-meta-card .value { color: #2c3e50; font-weight: bold; font-size: 1rem; }
        .install-step { display: flex; gap: 15px; padding: 15px 0; border-bottom: 1px solid #eee; }
        .install-step:last-child { border-bottom: none; }
        .install-num { flex-shrink: 0; background: #3498db; color: white; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; }
        .install-content h4 { color: #2c3e50; margin-bottom: 5px; }
        .install-content p { color: #555; font-size: 0.95rem; }
        .related-section { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .related-section h2 { color: #2c3e50; margin-bottom: 20px; font-size: 1.3rem; padding-bottom: 10px; border-bottom: 2px solid #3498db; }
        .related-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-top: 15px; }
        .related-card { background: #f8f9fa; padding: 15px; border-radius: 6px; text-align: center; text-decoration: none; color: #333; border: 1px solid #e0e0e0; }
        .related-card .oem { color: #3498db; font-weight: bold; font-size: 0.9rem; margin: 8px 0; }
        .related-card .name { font-size: 0.9rem; color: #555; }
        @media (max-width: 768px) {
            .product-grid, .related-grid, .shipping-grid, .about-grid, .contact-grid, .app-grid, .install-meta { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="header">
        <a href="https://carvalautopart.com/">Carval Auto Parts</a>
        <div class="sub">OEM Quality Auto Parts Wholesale Supplier Since 2008</div>
    </div>

    <div class="container">
        <nav class="breadcrumb">
            <a href="https://carvalautopart.com/">Home</a> <span>/</span>
            <a href="https://carvalautopart.com/products.html">Products</a> <span>/</span>
            <span>${this.htmlEsc(name.slice(0, 50))}${name.length > 50 ? '...' : ''}</span>
        </nav>

        <div class="product-grid">
            <div>
                <img src="${firstImage}" alt="${this.htmlEsc(name)}${oem ? ' - OEM ' + this.htmlEsc(oem) : ''}" class="main-image" id="mainImage" data-images='${imagesJson}' data-current="0">
                <div class="thumb-grid" id="thumbGrid">
                    ${thumbHtml}
                </div>
                ${imgCounterHtml}
            </div>
            <div class="product-info">
                <h1>${this.htmlEsc(name)}</h1>
                ${oem ? `<div class="oem-badge">OEM Part Number: <span>${this.htmlEsc(oem)}</span></div>` : ''}
                ${summary
                  ? `<div class="fitment-summary"><strong>Vehicle Fitment:</strong> ${this.htmlEsc(mainVehicle)} (${summary.count} variants)</div>`
                  : '<div class="fitment-summary"><strong>Vehicle Fitment:</strong> Contact us with your vehicle details to confirm compatibility.</div>'}
                <p style="margin: 15px 0; color: #27ae60;">✓ In Stock &nbsp; ✓ OEM Quality &nbsp; ✓ Wholesale Price &nbsp; ✓ 12-Month Warranty</p>
                <a href="mailto:carvalxie@foxmail.com?subject=Inquiry: ${encodeURIComponent(name.slice(0, 50))}" class="cta-button">Request Wholesale Quote →</a>
            </div>
        </div>

${whatIsHtml}
${fitmentHtml}
        <div class="application-section">
            <h2>Product Application &amp; Use Cases</h2>
            <p style="color: #555; margin-bottom: 15px;">This OEM ${this.htmlEsc(oem || name.slice(0, 30))} is engineered for the following applications:</p>
            <div class="app-grid">
${appHtml}            </div>
        </div>

        <div class="symptom-section">
            <h3>${this.htmlEsc(catContent.symptoms_title)}</h3>
            <p style="color: #555; margin-bottom: 10px;">${this.htmlEsc(catContent.symptoms_intro)}</p>
            <ul>
${symptomsHtml}            </ul>
            <p style="color: #d35400; margin-top: 15px;"><strong>${this.htmlEsc(catContent.symptoms_warning)}</strong></p>
        </div>

        <div class="install-section">
            <h2>Installation Guide</h2>
            <p style="color: #555; margin-bottom: 10px;">Installing this ${this.htmlEsc(oem || name.slice(0, 30))} is a straightforward process. The full job takes about ${this.htmlEsc(catContent.install_time)}.</p>
            <div class="install-meta">
                <div class="install-meta-card">
                    <div class="icon">⏱️</div>
                    <div class="label">Estimated Time</div>
                    <div class="value">${this.htmlEsc(catContent.install_time)}</div>
                </div>
                <div class="install-meta-card">
                    <div class="icon">🔧</div>
                    <div class="label">Skill Level</div>
                    <div class="value">${this.htmlEsc(catContent.install_skill)}</div>
                </div>
                <div class="install-meta-card">
                    <div class="icon">🛠️</div>
                    <div class="label">Tools Required</div>
                    <div class="value">${this.htmlEsc(catContent.install_tools)}</div>
                </div>
            </div>
${installHtml}
        </div>

        <div class="faq-section">
            <h2>Frequently Asked Questions (FAQ)</h2>
${faqHtml}        </div>

        <div class="process-section">
            <h2>How to Order (Wholesale Process)</h2>
            <ol class="steps">
                <li>Send us an email with the OEM number (${this.htmlEsc(oem || 'part number')}), quantity needed, and destination country.</li>
                <li>We reply with a wholesale price quote and shipping options within 24 hours.</li>
                <li>Confirm the order, pay the deposit (T/T, L/C, PayPal, or Western Union).</li>
                <li>We prepare the goods, conduct quality inspection, and ship within 7-15 days.</li>
                <li>You receive tracking info and the goods arrive at your destination port in 20-35 days (sea) or 5-10 days (air).</li>
            </ol>
        </div>

        <div class="b2b-info">
            <h3>Wholesale Business Information</h3>
            <ul>
                <li><strong>MOQ:</strong> 5 Pieces (mixed models accepted)</li>
                <li><strong>Payment Terms:</strong> T/T, L/C, Western Union, PayPal accepted</li>
                <li><strong>Price Terms:</strong> FOB Guangzhou / CIF your port / EXW</li>
                <li><strong>Sample Policy:</strong> Available for quality testing (fee refundable on order)</li>
                <li><strong>Lead Time:</strong> 7-15 days for stock items, 30 days for bulk production</li>
                <li><strong>Quality Guarantee:</strong> OEM equivalent quality with 12-month warranty</li>
                <li><strong>Customization:</strong> OEM/ODM service available for bulk orders</li>
                <li><strong>Packaging:</strong> Neutral packaging or custom branded packaging available</li>
            </ul>
        </div>

        <div class="shipping-info">
            <h3>Shipping &amp; Logistics Options</h3>
            <p style="color: #555; margin-bottom: 15px;">We offer flexible shipping methods to meet your timeline and budget requirements:</p>
            <div class="shipping-grid">
                <div class="shipping-card">
                    <h4>🚢 Sea Freight</h4>
                    <p>Most economical for bulk orders<br>20-35 days transit time<br>FCL / LCL both available</p>
                </div>
                <div class="shipping-card">
                    <h4>✈️ Air Freight</h4>
                    <p>Faster delivery option<br>5-10 days transit time<br>Best for urgent orders</p>
                </div>
                <div class="shipping-card">
                    <h4>📦 Express (DHL/FedEx)</h4>
                    <p>Fastest delivery worldwide<br>3-7 days door-to-door<br>Best for samples &amp; small orders</p>
                </div>
            </div>
        </div>

        <div class="related-section">
            <h2>Compatible / Related Parts</h2>
            <p style="color: #555;">${this.htmlEsc(catContent.related_parts_hint)}</p>
            <div class="related-grid">
${relatedHtml}            </div>
        </div>

        <div class="about-us">
            <h2>About Guangzhou Carval Auto Parts Co., Ltd.</h2>
            <p class="about-intro">Founded in 2008, Guangzhou Carval Auto Parts Co., Ltd. is a professional wholesale supplier of OEM-quality auto parts serving customers in over 80 countries worldwide. With 16+ years of industry experience, we specialize in providing comprehensive auto parts solutions for Japanese, Korean, German, and Chinese vehicles, including body parts, engine components, electrical parts, lubricants, and aftermarket accessories.</p>
            <p class="about-intro">Our 80+ member team operates from a 5,000 sqm facility in Guangzhou, China, maintaining extensive inventory of 10,000+ SKU items. We serve auto parts distributors, dealership parts departments, repair shops, and e-commerce platforms globally, offering competitive pricing, reliable quality, and professional export services including multilingual support, custom packaging, and flexible shipping arrangements.</p>
            <div class="about-grid">
                <div class="about-card"><div class="num">16+</div><div class="label">Years Experience</div></div>
                <div class="about-card"><div class="num">80+</div><div class="label">Team Members</div></div>
                <div class="about-card"><div class="num">80+</div><div class="label">Countries Served</div></div>
                <div class="about-card"><div class="num">10K+</div><div class="label">SKU Available</div></div>
            </div>
            <div class="company-gallery">
                <h3>🏢 Company Facilities &amp; Gallery</h3>
                <p style="color:#666; font-size:0.9rem; margin-bottom:15px;">Guangzhou Carval Auto Parts Co., Ltd. operates from a 5,000 sqm facility with offices, repair shops, and warehouses. Here are some photos of our facilities:</p>
                <div class="company-grid">
                    ${companyGalleryHtml}
                </div>
            </div>
        </div>

        <div class="contact">
            <h3>Contact Guangzhou Carval Auto Parts Co., Ltd.</h3>
            <div class="contact-grid">
                <div class="contact-item">📧 Email: <a href="mailto:carvalxie@foxmail.com">carvalxie@foxmail.com</a></div>
                <div class="contact-item">📞 Phone: <a href="tel:+86 195 2122 8657">+86 195 2122 8657</a></div>
                <div class="contact-item">💬 WhatsApp: <a href="https://wa.me/8619521228657">+86 195 2122 8657</a></div>
                <div class="contact-item">📍 No. 450, Huangshi East Road, Baiyun District, Guangzhou, China</div>
            </div>
        </div>
    </div>
<script>
(function() {
    var main = document.getElementById('mainImage');
    var grid = document.getElementById('thumbGrid');
    if (!main || !grid) return;
    var imgs;
    try { imgs = JSON.parse(main.getAttribute('data-images') || '[]'); } catch(e) { imgs = []; }
    grid.addEventListener('click', function(e) {
        var t = e.target;
        if (t && t.classList.contains('thumb')) {
            var idx = parseInt(t.getAttribute('data-idx') || '0', 10);
            if (imgs[idx]) {
                main.classList.add('loading');
                main.src = imgs[idx];
                main.alt = t.alt;
                main.setAttribute('data-current', String(idx));
                grid.querySelectorAll('.thumb').forEach(function(el){ el.classList.remove('active'); });
                t.classList.add('active');
                var c = document.getElementById('imgCounter');
                if (c) c.textContent = 'Image ' + (idx+1) + ' of ' + imgs.length + ' - Click thumbnails to view all product images';
                setTimeout(function(){ main.classList.remove('loading'); }, 200);
            }
        }
    });
    main.addEventListener('click', function() {
        var win = window.open(main.src, '_blank');
        if (win) win.focus();
    });
})();
</script>
</body>
</html>`;
  }

  // ---------- 10. HTML escaper ----------
  htmlEsc(s) {
    if (s === null || s === undefined) return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // ---------- 11. Main handleSEOUpload (v4-gen_2imgs) ----------
  async handleSEOUpload(data) {
    try {
      const productData = data;
      const name = productData.name || productData.title || '';
      const oem = productData.oem || productData.oemCode || '';

      // 1) Detect category (15 categories)
      const catKey = this.detectCategory(name);
      const catContent = CATEGORY_CONTENT[catKey] || CATEGORY_CONTENT['general'];

      // 2) Build 3 Schemas (Product + HowTo + FAQPage)
      const safeId = String(productData.id || oem || Date.now()).replace(/[^a-zA-Z0-9-_]/g, '_');
      const fileName = 'products/' + safeId + '.html';
      const url = 'https://carvalautopart.com/' + fileName;

      const productSchema = this.buildProductSchema(productData, url, catContent);
      const howtoSchema = this.buildHowToSchema(productData, catContent);
      const faqSchema = this.buildFAQSchema(productData, catContent);

      // 3) Build full HTML (7 sections)
      const html = this.buildSEOHtml(productData, catContent, productSchema, howtoSchema, faqSchema);

      // 4) Upload to GitHub (preserve existing logic: sha check, PUT, multi-token rotation)
      const apiUrl = 'https://api.github.com/repos/' + this.githubConfig.username + '/' + this.githubConfig.repository + '/contents/' + fileName;
      let sha = null;
      try {
        const checkResponse = await this.githubRequest(apiUrl, { headers: { 'Authorization': 'token ' + this.getCurrentToken() } }, 3, 2000);
        if (checkResponse.ok) sha = (await checkResponse.json()).sha;
      } catch (e) { console.log('检查文件存在性失败，继续上传'); }

      const bodyObj = {
        message: 'Add SEO: ' + (name || oem || 'product'),
        content: btoa(unescape(encodeURIComponent(html))),
        branch: this.githubConfig.branch
      };
      if (sha) bodyObj.sha = sha;

      const response = await this.githubRequest(apiUrl, {
        method: 'PUT',
        headers: { 'Authorization': 'token ' + this.getCurrentToken(), 'Content-Type': 'application/json' },
        body: JSON.stringify(bodyObj)
      }, 10, 3000);

      if (!response.ok) throw new Error('GitHub: ' + response.status);

      return { success: true, url: 'https://carvalautopart.com/' + fileName, fileName };
    } catch (error) {
      console.error('SEO upload error:', error);
      return { success: false, error: error.message };
    }
  }



  // ========== 结束：products.json 管理功能 ==========
}

// 初始化后台服务
const collectorBackground = new CollectorBackground();

// 监听扩展安装/更新事件
chrome.runtime.onInstalled.addListener((details) => {
  console.log('扩展安装/更新:', details.reason);
  if (details.reason === 'install') {
    chrome.tabs.create({ url: 'popup.html?mode=setup' });
  }
});

// 监听网络请求（可选，用于调试）
chrome.webRequest.onCompleted.addListener(
  (details) => {
    if (details.url.includes('aliyuncs.com')) {
      console.log('OSS请求完成:', details);
    }
  },
  { urls: ['https://*.aliyuncs.com/*'] }
);
