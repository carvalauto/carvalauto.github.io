// Carval Auto 采集器 - 后台脚本 v3.2
const GITHUB_TOKEN = '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';
const REPO = 'carvalauto/carvalauto.github.io';
const BRANCH = 'main';

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'PUSH') {
    uploadToGitHub(message.data).then(res => sendResponse(res)).catch(e => sendResponse({ok: false, error: e.message}));
    return true;
  }
});

async function uploadToGitHub(product) {
  try {
    // 生成SEO优化数据
    const seoData = generateSEO(product);

    // 立即上传单个产品（0延迟）
    const url = `https://api.github.com/repos/${REPO}/contents/products.json`;
    const getRes = await fetch(url, {
      headers: {
        'Authorization': `token ${GITHUB_TOKEN}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    });

    let existingProducts = [];
    let sha = '';
    if (getRes.ok) {
      const data = await getRes.json();
      sha = data.sha;
      const content = decodeURIComponent(escape(atob(data.content)));
      existingProducts = JSON.parse(content);
    }

    // 添加新产品，包含SEO数据
    const newProduct = {
      ...product,
      ...seoData,
      id: Date.now()
    };
    existingProducts.push(newProduct);

    const jsonStr = JSON.stringify(existingProducts, null, 2);
    const encodedContent = btoa(unescape(encodeURIComponent(jsonStr)));

    const putRes = await fetch(url, {
      method: 'PUT',
      headers: {
        'Authorization': `token ${GITHUB_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: `新增产品: ${product.name.substring(0, 30)}... with SEO优化`,
        content: encodedContent,
        sha: sha,
        branch: BRANCH
      })
    });

    if (!putRes.ok) throw new Error('上传失败');

    // 更新version.json
    await updateVersion(existingProducts.length, 'single_upload_v32');

    return {ok: true, total: existingProducts.length};
  } catch (e) {
    console.error('上传错误:', e);
    return {ok: false, error: e.message};
  }
}

function generateSEO(product) {
  // 提取车型信息
  const models = product.fitmentTable && product.fitmentTable.length > 0
    ? product.fitmentTable.map(f => `${f.brand} ${f.model}`).join(', ')
    : 'Universal';

  // 生成SEO相关数据
  return {
    metaTitle: `${product.name} ${product.oem} for ${models} | Carval Auto`,
    metaDescription: `${product.name} - Quality OEM replacement part ${product.oem} for ${models}. Fast shipping, competitive prices at Carval Auto.`,
    metaKeywords: `${product.name}, ${product.oem}, ${models}, car parts, auto parts, OEM, replacement, Carval Auto`,
    urlTitle: product.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, ''),
    imageAlt: `${product.name} ${product.oem} for ${models}`,
    h1Title: product.name,
    h2Title: `${product.oem} - ${models}`
  };
}

async function updateVersion(total, source) {
  const version = {
    version: Date.now(),
    message: `新增产品 (total: ${total}) with SEO优化 at ${new Date().toLocaleString()}`,
    totalProducts: total,
    lastUpdate: new Date().toISOString(),
    source: source
  };

  const url = `https://api.github.com/repos/${REPO}/contents/version.json`;
  const getRes = await fetch(url, {
    headers: {
      'Authorization': `token ${GITHUB_TOKEN}`,
      'Accept': 'application/vnd.github.v3+json'
    }
  });

  let sha = '';
  if (getRes.ok) {
    const data = await getRes.json();
    sha = data.sha;
  }

  const jsonStr = JSON.stringify(version, null, 2);
  const encodedContent = btoa(unescape(encodeURIComponent(jsonStr)));

  await fetch(url, {
    method: 'PUT',
    headers: {
      'Authorization': `token ${GITHUB_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      message: '更新版本号',
      content: encodedContent,
      sha: sha,
      branch: BRANCH
    })
  });
}
