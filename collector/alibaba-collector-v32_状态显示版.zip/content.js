// Carval Auto 采集器 - 内容脚本 v3.2 状态显示版
(function() {
  if (location.hostname.includes('alibaba.com')) {
    setTimeout(addButton, 1500);
  }

  let statusPanel = null;

  function addButton() {
    if (document.getElementById('carval-collect-btn')) return;

    // 创建状态面板
    statusPanel = document.createElement('div');
    statusPanel.id = 'carval-status-panel';
    statusPanel.style.cssText = `
      position: fixed; top: 60px; right: 10px; z-index: 99999;
      background: white; border-radius: 8px; padding: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      font-family: Arial, sans-serif; min-width: 200px;
    `;
    statusPanel.innerHTML = `
      <div style="font-size: 12px; color: #666; margin-bottom: 8px; font-weight: bold;">
        📊 采集状态
      </div>
      <div id="status-collecting" style="display: flex; align-items: center; padding: 8px 0; border-bottom: 1px solid #eee;">
        <span id="icon-collecting" style="font-size: 18px; margin-right: 10px;">⚪</span>
        <span style="font-size: 13px; color: #999;">采集中</span>
      </div>
      <div id="status-uploading" style="display: flex; align-items: center; padding: 8px 0; border-bottom: 1px solid #eee;">
        <span id="icon-uploading" style="font-size: 18px; margin-right: 10px;">⚪</span>
        <span style="font-size: 13px; color: #999;">上传中</span>
      </div>
      <div id="status-completed" style="display: flex; align-items: center; padding: 8px 0;">
        <span id="icon-completed" style="font-size: 18px; margin-right: 10px;">⚪</span>
        <span style="font-size: 13px; color: #999;">上传完成</span>
      </div>
    `;
    document.body.appendChild(statusPanel);

    const btn = document.createElement('button');
    btn.id = 'carval-collect-btn';
    btn.innerHTML = '📦 采集到 GitHub';
    btn.style.cssText = `
      position: fixed; top: 10px; right: 10px; z-index: 99999;
      padding: 12px 20px; background: #e74c3c; color: white;
      border: none; border-radius: 6px; font-size: 14px;
      font-weight: bold; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    `;
    btn.onclick = collect;
    document.body.appendChild(btn);
  }

  function updateStatus(status) {
    const icons = {
      collecting: document.getElementById('icon-collecting'),
      uploading: document.getElementById('icon-uploading'),
      completed: document.getElementById('icon-completed')
    };

    // 重置所有状态
    Object.values(icons).forEach(icon => {
      icon.textContent = '⚪';
      icon.nextElementSibling.style.color = '#999';
    });

    // 更新当前状态
    if (status === 'collecting') {
      icons.collecting.textContent = '🔵';
      icons.collecting.nextElementSibling.style.color = '#007bff';
    } else if (status === 'uploading') {
      icons.collecting.textContent = '✅';
      icons.collecting.nextElementSibling.style.color = '#28a745';
      icons.uploading.textContent = '🔵';
      icons.uploading.nextElementSibling.style.color = '#007bff';
    } else if (status === 'completed') {
      icons.collecting.textContent = '✅';
      icons.collecting.nextElementSibling.style.color = '#28a745';
      icons.uploading.textContent = '✅';
      icons.uploading.nextElementSibling.style.color = '#28a745';
      icons.completed.textContent = '✅';
      icons.completed.nextElementSibling.style.color = '#28a745';
    }
  }

  function collect() {
    const btn = document.getElementById('carval-collect-btn');
    btn.innerHTML = '⏳ 采集中...';
    btn.disabled = true;

    // 更新状态：采集中
    updateStatus('collecting');

    try {
      // 采集标题
      const title = document.querySelector('h1, .module-pdp-title, [class*="title"]')?.textContent?.trim() || '';

      // 采集主图（最多6张）
      const imgs = [];
      document.querySelectorAll('img[class*="image"], img[src*="cbu"], img[src*="alicdn"]').forEach(img => {
        if (imgs.length < 6 && img.src && !img.src.includes('avatar') && !img.src.includes('logo')) {
          const url = img.src.replace(/_\d+x\d+\./, '.').split('?')[0];
          if (!imgs.includes(url)) imgs.push(url);
        }
      });

      // 采集OEM
      const oem = document.body.innerText.match(/(?:OE\s*NO\.?|OEM|Model\s*Number)[:\s]*([A-Z0-9\-]+)/i)?.[1] || '';

      // 采集车型表格
      const fitment = [];
      document.querySelectorAll('table').forEach(table => {
        const headers = Array.from(table.querySelectorAll('th')).map(th => th.textContent.trim().toLowerCase());
        if (headers.some(h => /make|model|year|fitment|car/i.test(h))) {
          table.querySelectorAll('tbody tr').forEach(tr => {
            const cells = tr.querySelectorAll('td');
            if (cells.length >= 2) {
              fitment.push({
                brand: cells[0]?.textContent?.trim() || '',
                model: cells[1]?.textContent?.trim() || '',
                year: cells[2]?.textContent?.trim() || ''
              });
            }
          });
        }
      });

      // 自动分类
      let cat = 'other';
      const t = title.toLowerCase();
      if (/toyota|honda|nissan|mazda|mitsubishi|subaru|lexus|infiniti|acura|suzuki|daihatsu|isuzu/.test(t)) cat = 'japanese';
      else if (/hyundai|kia|daewoo|samsung|genesis/.test(t)) cat = 'korean';
      else if (/bmw|mercedes|audi|volkswagen|vw|porsche|opel/.test(t)) cat = 'german';
      else if (/geely|byd|chery|great.wall|chang'an|dongfeng|gac/.test(t)) cat = 'chinese';
      else if (/oil|lubricant|引擎油|机油/.test(t)) cat = 'oil';

      const product = {
        name: title,
        category: cat,
        oem: oem,
        description: fitment.length > 0 ? fitment.map(f => `${f.brand} ${f.model} ${f.year}`.trim()).join(' | ') : '',
        image: imgs.join(','),
        fitmentTable: fitment,
        url: location.href.split('?')[0],
        collectedAt: new Date().toISOString()
      };

      if (!product.name) {
        showMsg('❌ 无法采集标题', 'red');
        btn.innerHTML = '📦 采集到 GitHub';
        btn.disabled = false;
        return;
      }

      // 更新状态：上传中
      updateStatus('uploading');

      chrome.runtime.sendMessage({type: 'PUSH', data: product}, res => {
        if (res?.ok) {
          // 更新状态：完成
          updateStatus('completed');
          showMsg(`✅ 成功！总产品: ${res.total}`, 'green');
          btn.innerHTML = '✅ 采集成功';
          setTimeout(() => {
            btn.innerHTML = '📦 采集到 GitHub';
            btn.disabled = false;
          }, 3000);
        } else {
          showMsg(`❌ ${res?.error || '失败'}`, 'red');
          btn.innerHTML = '📦 采集到 GitHub';
          btn.disabled = false;
        }
      });

    } catch (e) {
      showMsg('❌ 采集错误: ' + e.message, 'red');
      btn.innerHTML = '📦 采集到 GitHub';
      btn.disabled = false;
    }
  }

  function showMsg(text, color) {
    const div = document.createElement('div');
    div.textContent = text;
    div.style.cssText = `
      position: fixed; top: 260px; right: 10px; z-index: 99999;
      padding: 15px 25px; background: ${color === 'green' ? '#27ae60' : '#e74c3c'};
      color: white; border-radius: 6px; font-size: 14px; font-weight: bold;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    `;
    document.body.appendChild(div);
    setTimeout(() => div.remove(), 3000);
  }
})();
