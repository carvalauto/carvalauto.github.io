// background.js - GitHub API 推送服务 v19 (完整修复版)
// 修复大文件获取问题，确保与网页和后台完全兼容
// v19 更新: 使用 CDN 获取现有产品，优化推送逻辑

const GH_REPO = 'carvalauto/carvalauto.github.io';
const GH_FILE = 'products.json';
const GH_BRANCH = 'main';

let config = { token: '', repo: GH_REPO, file: GH_FILE };

// 加载配置
async function loadConfig() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['gh_token', 'gh_repo', 'gh_file'], (result) => {
      if (result.gh_token) config.token = result.gh_token;
      if (result.gh_repo) config.repo = result.gh_repo;
      if (result.gh_file) config.file = result.gh_file;
      console.log('[v19] 配置加载完成, token:', config.token ? '已设置' : '未设置');
      resolve();
    });
  });
}

// 保存配置
async function saveConfig(token, repo, file) {
  return new Promise((resolve) => {
    chrome.storage.local.set({
      gh_token: token,
      gh_repo: repo || GH_REPO,
      gh_file: file || GH_FILE
    }, resolve);
  });
}

// 获取文件SHA
async function getFileSha() {
  const url = `https://api.github.com/repos/${config.repo}/contents/${config.file}`;
  
  const response = await fetch(url, {
    headers: {
      'Authorization': `token ${config.token}`,
      'Accept': 'application/vnd.github.v3+json'
    }
  });
  
  if (response.status === 404) {
    console.log('[v19] 文件不存在');
    return null;
  }
  
  if (!response.ok) {
    throw new Error(`获取SHA失败: ${response.status}`);
  }
  
  const data = await response.json();
  return data.sha;
}

// 获取文件内容（使用 CDN 优先，避免 GitHub API 大文件问题）
async function getFileContent() {
  try {
    // 方案1: 使用 jsDelivr CDN（最快最稳定）
    const cdnUrl = `https://cdn.jsdelivr.net/gh/${config.repo}@main/${config.file}?t=${Date.now()}`;
    const cdnResp = await fetch(cdnUrl);
    if (cdnResp.ok) {
      const data = await cdnResp.json();
      console.log('[v19] CDN 获取成功，产品数:', data.length);
      return Array.isArray(data) ? data : [];
    }
  } catch (e) {
    console.log('[v19] CDN 获取失败，尝试 GitHub API:', e.message);
  }
  
  try {
    // 方案2: GitHub API + download_url
    const url = `https://api.github.com/repos/${config.repo}/contents/${config.file}`;
    const response = await fetch(url, {
      headers: {
        'Authorization': `token ${config.token}`,
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    
    if (response.status === 404) {
      return [];
    }
    
    if (!response.ok) {
      throw new Error(`获取文件失败: ${response.status}`);
    }
    
    const data = await response.json();
    
    // 大文件使用 download_url
    if (data.download_url) {
      const rawResp = await fetch(data.download_url + '?t=' + Date.now());
      const content = await rawResp.json();
      console.log('[v19] GitHub API 获取成功，产品数:', content.length);
      return Array.isArray(content) ? content : [];
    }
    
    // 小文件直接解码
    if (data.content) {
      const decoded = decodeURIComponent(escape(atob(data.content.replace(/\n/g, ''))));
      const content = JSON.parse(decoded);
      return Array.isArray(content) ? content : [];
    }
  } catch (e) {
    console.error('[v19] GitHub API 获取失败:', e.message);
  }
  
  return [];
}

// 上传文件
async function uploadFile(content, sha) {
  const url = `https://api.github.com/repos/${config.repo}/contents/${config.file}`;
  
  console.log('[v19] 上传文件, 产品数量:', content.length);
  
  // 编码内容
  const contentStr = JSON.stringify(content, null, 2);
  const base64Content = btoa(unescape(encodeURIComponent(contentStr)));
  
  const body = {
    message: `Add products via Carval Collector v19 - ${new Date().toLocaleString()}`,
    content: base64Content,
    branch: GH_BRANCH
  };
  
  if (sha) {
    body.sha = sha;
  }
  
  const response = await fetch(url, {
    method: 'PUT',
    headers: {
      'Authorization': `token ${config.token}`,
      'Accept': 'application/vnd.github.v3+json',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  
  if (!response.ok) {
    const errorText = await response.text();
    console.error('[v17] 上传失败:', errorText);
    throw new Error(`上传失败: ${response.status}`);
  }
  
  return await response.json();
}

// 自动分类
function detectCategory(title, fitmentTable) {
  const text = (title + ' ' + (fitmentTable || []).map(f => f.make || '').join(' ')).toLowerCase();
  
  if (text.includes('oil') || text.includes('润滑油') || text.includes('机油')) return 'oil';
  
  const japaneseBrands = ['toyota', 'honda', 'nissan', 'mazda', 'mitsubishi', 'subaru', 'lexus', 'infiniti', 'suzuki', 'daihatsu', 'isuzu'];
  if (japaneseBrands.some(b => text.includes(b))) return 'japanese';
  
  const koreanBrands = ['hyundai', 'kia', 'daewoo', 'ssangyong', 'genesis'];
  if (koreanBrands.some(b => text.includes(b))) return 'korean';
  
  const germanBrands = ['bmw', 'mercedes', 'audi', 'volkswagen', 'vw', 'porsche', 'opel'];
  if (germanBrands.some(b => text.includes(b))) return 'german';
  
  const chineseBrands = ['byd', 'geely', 'chery', 'great wall', 'haval', 'changan', 'gac', 'saic', 'baojun', 'wuling', 'hongguang'];
  if (chineseBrands.some(b => text.includes(b))) return 'chinese';
  
  return 'other';
}

// 构建 description
function buildDescription(product) {
  const parts = [];
  
  if (product.brand) {
    parts.push(`Brand: ${product.brand}`);
  }
  
  if (product.fitmentTable && product.fitmentTable.length > 0) {
    const makes = [...new Set(product.fitmentTable.map(f => f.make).filter(Boolean))];
    if (makes.length > 0) {
      parts.push(`Compatible with: ${makes.slice(0, 5).join(', ')}`);
    }
  }
  
  if (product.specs) {
    parts.push(`Specs: ${product.specs}`);
  }
  
  if (product.description) {
    parts.push(product.description);
  }
  
  if (parts.length === 0) {
    if (product.fitmentTable && product.fitmentTable.length > 0) {
      parts.push(`适配车型: ${product.fitmentTable.length}款`);
    } else {
      parts.push('High-quality auto parts');
    }
  }
  
  return parts.join(' | ');
}

// 生成产品 ID
function generateProductId(productsList) {
  if (!productsList || !Array.isArray(productsList) || productsList.length === 0) {
    return 1;
  }
  
  const validIds = productsList
    .map(p => typeof p.id === 'number' && !isNaN(p.id) && isFinite(p.id) ? p.id : null)
    .filter(id => id !== null && id > 0);
  
  if (validIds.length === 0) return 1;
  
  return Math.max(...validIds) + 1;
}

// 处理推送请求
async function handlePushProducts(products) {
  if (!config.token) {
    throw new Error('请先在插件设置中配置 GitHub Token');
  }
  
  console.log('[v19] 开始处理', products.length, '个产品');
  
  // 获取 SHA
  let sha = null;
  try {
    sha = await getFileSha();
    console.log('[v19] 当前文件SHA:', sha ? sha.substring(0, 10) + '...' : '新建');
  } catch (e) {
    console.error('[v17] 获取SHA失败:', e);
    throw new Error('无法获取GitHub文件状态，请检查Token');
  }
  
  // 获取现有内容
  let existingProducts = [];
  if (sha) {
    try {
      existingProducts = await getFileContent();
      console.log('[v19] 现有产品数量:', existingProducts.length);
    } catch (e) {
      console.error('[v17] 获取内容失败:', e);
      throw new Error('无法获取现有产品数据');
    }
  }
  
  let productsList = Array.isArray(existingProducts) ? [...existingProducts] : [];
  
  // 处理新产品
  for (const product of products) {
    const existingIndex = productsList.findIndex(p =>
      (p.url && p.url === product.url) || 
      (p.name && product.title && p.name === product.title)
    );
    
    let newId = generateProductId(productsList);
    
    if (existingIndex >= 0 && productsList[existingIndex].id) {
      newId = productsList[existingIndex].id;
    }
    
    const category = detectCategory(product.title || '', product.fitmentTable);
    
    const formattedProduct = {
      id: newId,
      name: product.title || product.name || 'Unknown Product',
      oem: product.oemCode || product.oem || '',
      description: buildDescription(product),
      image: product.images && product.images.length > 0 
        ? product.images.join(',') 
        : '',
      category: category,
      url: product.url || '',
      fitmentTable: product.fitmentTable || [],
      collectedAt: product.collectedAt || new Date().toISOString()
    };
    
    if (existingIndex >= 0) {
      productsList[existingIndex] = formattedProduct;
      console.log('[v19] 更新产品:', formattedProduct.name);
    } else {
      productsList.push(formattedProduct);
      console.log('[v19] 添加新产品:', formattedProduct.name);
    }
  }
  
  console.log('[v19] 处理完成，总产品数:', productsList.length);
  
  // 重新获取 SHA 防止冲突
  try {
    sha = await getFileSha();
  } catch (e) {
    console.log('[v19] 重新获取SHA失败');
  }
  
  // 上传
  await uploadFile(productsList, sha);
  
  return { 
    success: true, 
    addedCount: products.length, 
    totalCount: productsList.length 
  };
}

// 消息监听 - 兼容多种消息类型
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[v19] 收到消息:', message.type || message.action, '来自:', sender.tab?.url || 'popup');
  
  // 兼容两种消息格式
  const msgType = message.type || message.action;
  
  if (msgType === 'PUSH_PRODUCTS' || msgType === 'syncProducts') {
    const products = message.products || [];
    console.log('[v19] 收到推送请求, 产品数:', products.length);
    
    loadConfig().then(() => {
      handlePushProducts(products)
        .then(result => {
          console.log('[v19] 推送成功:', result);
          sendResponse(result);
        })
        .catch(error => {
          console.error('[v17] 推送失败:', error);
          sendResponse({ success: false, error: error.message });
        });
    });
    return true;
  }
  
  if (msgType === 'SAVE_CONFIG' || msgType === 'saveConfig') {
    saveConfig(message.token, message.repo, message.file)
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
  
  if (msgType === 'GET_CONFIG' || msgType === 'getConfig') {
    loadConfig().then(() => {
      sendResponse({ 
        token: config.token ? '****' + config.token.slice(-4) : '', 
        repo: config.repo, 
        file: config.file,
        hasToken: !!config.token
      });
    });
    return true;
  }
  
  // 默认返回未处理
  return false;
});

// 初始化
chrome.runtime.onInstalled.addListener(() => {
  console.log('[v19] Carval Auto 采集器 v19 已安装');
  loadConfig();
});

chrome.runtime.onStartup.addListener(() => {
  console.log('[v19] Service Worker 启动');
  loadConfig();
});
