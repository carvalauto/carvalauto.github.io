// Alibaba商品采集器 - 后台脚本（完全嵌入式配置版本 - 修复版）
// 修复内容：
// 1. 修复OSS签名算法 - 使用正确的HMAC-SHA1
// 2. 修复sender未定义错误
// 3. 增强错误处理

// 导入嵌入式配置
const EMBEDDED_CONFIG = {
  oss: {
    region: 'oss-cn-hangzhou',
    bucket: 'carvalauto-products',
    accessKeyId: 'LTAI5tKCovsg5dJWKxoXwDr2',
    accessKeySecret: 'vDdWLEKBnnmFFZwOeLzX73vRo8k0WW',
    directory: 'products/',
    endpoint: 'https://carvalauto-products.oss-cn-hangzhou.aliyuncs.com',
    productsUrl: 'https://carvalauto-products.oss-cn-hangzhou.aliyuncs.com/products.json'
  },
  website: {
    domain: 'https://carvalautopart.com',
    adminPage: 'https://carvalautopart.com/admin.html',
    productPage: 'https://carvalautopart.com/product.html'
  },
  github: {
    username: 'carvalauto',
    repository: 'carvalauto.github.io',
    branch: 'main',
    domain: 'https://carvalautopart.com',
    token: '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'
  },
  analytics: {
    trackingId: '529242507',
    enabled: true
  },
  collection: {
    collectImages: true,
    collectFitment: true,
    skipLogoImages: true,
    autoSEO: true,
    retryCount: 3,
    timeoutSeconds: 120,
    maxImages: 6
  }
};

class CollectorBackground {
  constructor() {
    // 使用硬编码配置
    this.ossConfig = EMBEDDED_CONFIG.oss;
    this.websiteConfig = EMBEDDED_CONFIG.website;
    this.githubConfig = EMBEDDED_CONFIG.github;
    this.analyticsConfig = EMBEDDED_CONFIG.analytics;
    this.collectionConfig = EMBEDDED_CONFIG.collection;

    this.collectionQueue = [];
    this.processedItems = new Map();
    this.stats = {
      total: 0,
      success: 0,
      failed: 0,
      startTime: null
    };

    console.log('🚀 阿里巴巴采集器启动（修复版）');
    console.log('📋 OSS配置:', this.ossConfig);
    console.log('🌐 网站配置:', this.websiteConfig);
    
    // 品牌到分类目录的映射
    // 品牌到系统分类的映射
    this.brandCategoryMap = {
      // 日系
      'TOYOTA': 'japanese', 'HONDA': 'japanese', 'NISSAN': 'japanese',
      'MAZDA': 'japanese', 'SUBARU': 'japanese', 'MITSUBISHI': 'japanese',
      'SUZUKI': 'japanese', 'LEXUS': 'japanese', 'INFINITI': 'japanese', 'ACURA': 'japanese',
      // 德系
      'BMW': 'german', 'MERCEDES-BENZ': 'german', 'AUDI': 'german',
      'VOLKSWAGEN': 'german', 'PORSCHE': 'german',
      // 美系（暂时归为other，因为网站没有美系分类）
      'FORD': 'other', 'CHEVROLET': 'other', 'DODGE': 'other',
      'GMC': 'other', 'JEEP': 'other', 'RAM': 'other', 'CADILLAC': 'other', 'BUICK': 'other',
      // 韩系
      'HYUNDAI': 'korean', 'KIA': 'korean', 'GENESIS': 'korean',
      // 国产
      'CHERY': 'chinese', 'GEELY': 'chinese', 'BYD': 'chinese', 'HAVAL': 'chinese',
      'GREAT WALL': 'chinese', 'CHANGAN': 'chinese', 'MG': 'chinese',
      'WULING': 'chinese', '五菱': 'chinese', 'MINI EV': 'chinese'
    };
    
    this.init();
  }

  // 根据车型适配表自动分类
  autoClassifyByFitment(fitmentData) {
    console.log('🔍 开始自动分类, fitmentData:', fitmentData);
    
    if (!fitmentData) {
      return 'other';
    }
    
    const dataArray = Array.isArray(fitmentData) ? fitmentData : [];
    
    if (dataArray.length === 0) {
      return 'other';
    }
    
    console.log('📊 fitmentData有', dataArray.length, '条数据');
    
    // 统计各品牌出现次数 - 使用更多字段名和变体
    const brandCount = {};
    const brandAliases = {
      // 日系
      'NISSAN': 'Nissan', 'Nissan': 'Nissan', 'nissan': 'Nissan',
      'TOYOTA': 'Toyota', 'Toyota': 'Toyota', 'toyota': 'Toyota',
      'HONDA': 'Honda', 'Honda': 'Honda', 'honda': 'Honda',
      'MITSUBISHI': 'Mitsubishi', 'Mitsubishi': 'Mitsubishi', 'mitsubishi': 'Mitsubishi',
      'MAZDA': 'Mazda', 'Mazda': 'Mazda', 'mazda': 'Mazda',
      'SUBARU': 'Subaru', 'Subaru': 'Subaru', 'subaru': 'Subaru',
      'SUZUKI': 'Suzuki', 'Suzuki': 'Suzuki', 'suzuki': 'Suzuki',
      'LEXUS': 'Lexus', 'Lexus': 'Lexus',
      'INFINITI': 'Infiniti', 'Infiniti': 'Infiniti',
      // 德系
      'BMW': 'BMW', 'Bmw': 'BMW', 'bmw': 'BMW',
      'MERCEDES-BENZ': 'Mercedes-Benz', 'MERCEDES': 'Mercedes-Benz', 'Mercedes': 'Mercedes-Benz',
      'AUDI': 'Audi', 'Audi': 'Audi', 'audi': 'Audi',
      'VOLKSWAGEN': 'Volkswagen', 'VOLKSWAGON': 'Volkswagen', 'VW': 'Volkswagen',
      // 美系
      'FORD': 'Ford', 'Ford': 'Ford', 'ford': 'Ford',
      'CHEVROLET': 'Chevrolet', 'CHEVY': 'Chevrolet', 'Chevrolet': 'Chevrolet',
      'DODGE': 'Dodge', 'Dodge': 'Dodge', 'dodge': 'Dodge',
      'GMC': 'GMC', 'Gmc': 'GMC',
      'JEEP': 'Jeep', 'Jeep': 'Jeep',
      // 韩系
      'HYUNDAI': 'Hyundai', 'Hyundai': 'Hyundai', 'hyundai': 'Hyundai',
      'KIA': 'Kia', 'Kia': 'Kia', 'kia': 'Kia',
      // 国产
      'BYD': 'BYD', 'Byd': 'BYD',
      'CHERY': 'Chery', 'Chery': 'Chery',
      'GEELY': 'Geely', 'Geely': 'Geely',
      'HAVAL': 'Haval', 'Haval': 'Haval',
      'GREAT WALL': 'Great Wall', 'GREATWALL': 'Great Wall',
      'CHANGAN': 'Changan', 'Changan': 'Changan',
      'MG': 'MG', 'Mg': 'MG'
    };
    
    dataArray.forEach((item, index) => {
      // 支持多种字段名
      const makeRaw = item.make || item.brand || item.Make || item.Brand || '';
      const make = makeRaw.toUpperCase().trim();
      
      if (make && make.length > 1) {
        // 尝试匹配标准品牌名
        const standardBrand = brandAliases[make] || brandAliases[makeRaw] || null;
        const brandKey = standardBrand || make;
        
        brandCount[brandKey] = (brandCount[brandKey] || 0) + 1;
        console.log(`第${index}条: ${makeRaw} -> ${brandKey}`);
      }
    });
    
    console.log('📊 品牌统计:', brandCount);
    
    // 找出出现最多的品牌
    let maxCount = 0;
    let primaryBrand = null;
    for (const [brand, count] of Object.entries(brandCount)) {
      if (count > maxCount) {
        maxCount = count;
        primaryBrand = brand;
      }
    }
    
    console.log(`🏆 最多的品牌: ${primaryBrand} (${maxCount}次)`);
    
    // 直接使用识别出的品牌名
    if (primaryBrand) {
      const category = this.brandCategoryMap[primaryBrand.toUpperCase()];
      if (category) {
        console.log(`✅ 自动分类: ${primaryBrand} → ${category}`);
        return category;
      }
      // 如果品牌名本身就是标准格式
      if (['Toyota', 'Honda', 'Nissan', 'BMW', 'Mercedes-Benz', 'Audi', 'Ford', 'Chevrolet', 'Hyundai', 'Kia', 'BYD', 'Mitsubishi', 'Mitsubishi'].includes(primaryBrand)) {
        // 品牌→系统分类
        const catMap = {
          'Toyota': 'japanese', 'Honda': 'japanese', 'Nissan': 'japanese', 'Mitsubishi': 'japanese',
          'BMW': 'german', 'Mercedes-Benz': 'german', 'Audi': 'german',
          'Ford': 'other', 'Chevrolet': 'other', 'Hyundai': 'korean', 'Kia': 'korean', 'BYD': 'chinese'
        };
        const cat = catMap[primaryBrand] || 'other';
        console.log(`✅ 直接使用品牌作为分类: ${primaryBrand} → ${cat}`);
        return cat;
      }
    }
    
    return 'other';
  }

  init() {
    this.loadConfiguration();
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      this.handleMessage(message, sender, sendResponse);
      return true;
    });

    setInterval(() => {
      this.saveStats();
    }, 30000);

    console.log('阿里巴巴采集器后台已启动（修复版）');
  }

  async loadConfiguration() {
    console.log('🔧 加载配置（修复版）');
    try {
      console.log('📋 OSS配置:', this.ossConfig);
      console.log('🌐 网站配置:', this.websiteConfig);
      console.log('📊 Analytics配置:', this.analyticsConfig);

      if (!this.validateOSSConfig()) {
        console.error('❌ OSS配置验证失败');
        throw new Error('OSS配置不完整');
      }

      console.log('✅ 配置加载完成，所有配置有效');
    } catch (error) {
      console.error('❌ 配置加载失败:', error);
      console.error('⚠️ 严重错误：硬编码配置无效，请检查embedded-config.js');
    }
  }

  async handleMessage(message, sender, sendResponse) {
    const { action, data } = message;
    try {
      switch (action) {
        case 'uploadToOSS':
          // 修复：传递sender参数
          const uploadResult = await this.handleOSSUpload(data, sender);
          sendResponse(uploadResult);
          break;
        case 'uploadSEOToGitHub':
          const seoResult = await this.handleSEOUpload(data);
          sendResponse(seoResult);
          break;
        
        case 'testOSSConnection':
          const testResult = await this.handleTestOSSConnection(data);
          sendResponse(testResult);
          break;
        case 'getStats':
          sendResponse({ success: true, stats: this.stats });
          break;
        case 'updateConfig':
          await this.updateConfiguration(data);
          sendResponse({ success: true });
          break;
        case 'clearErrors':
          this.processedItems.clear();
          sendResponse({ success: true });
          break;
        default:
          sendResponse({ success: false, error: '未知操作' });
      }
    } catch (error) {
      console.error('处理消息失败:', error);
      sendResponse({ success: false, error: error.message });
    }
  }

  async handleOSSUpload(productData, sender) {
    console.log('开始处理OSS上传:', productData.url);
    try {
      if (!this.validateOSSConfig()) {
        throw new Error('OSS配置不完整，请先配置阿里云OSS信息');
      }

      const fileName = this.generateFileName(productData);
      const filePath = `${this.ossConfig.directory}${fileName}`;
      const uploadData = this.prepareUploadData(productData);

      // 自动格式检测和转换
      console.log('开始自动格式检测和转换...');
      const finalUploadData = this.ensureFlatFormat(uploadData);
      console.log('格式处理完成，准备上传...');

      // 从上传数据中提取ID，确保products.json中使用同一个ID
      const uploadDataObj = JSON.parse(finalUploadData);
      const productId = uploadDataObj.id;

      const uploadResult = await this.uploadWithRetry(filePath, finalUploadData);
      this.updateStats(true);

      // 新增：更新 products.json
      try {
        const oemCode = productData.oemCodes && productData.oemCodes.length > 0 ? productData.oemCodes[0] : '';
        const imageString = productData.images && productData.images.length > 0 ? productData.images.join(',') : '';
        const fitmentData = productData.fitment || [];
        
        // 自动分类
        const titleBrand = this.identifyBrand(productData.title);
        const fitmentCategory = this.autoClassifyByFitment(fitmentData);
        let category = titleBrand && titleBrand !== 'Universal' ? titleBrand : fitmentCategory;
        
        const productInfo = {
          id: productId,
          name: productData.title,
          title: productData.title,
          category: category,
          oem: oemCode,
          oemCode: oemCode,
          url: productData.url,
          description: productData.description || productData.seoDescription || '',
          images: productData.images || [],
          image: imageString,
          fitmentTable: fitmentData,
          brand: titleBrand,
          collectedAt: productData.collectedAt,
          hasFitment: productData.hasFitment || false,
          uploadedAt: new Date().toISOString(),
          sourceUrl: productData.url
        };

        const updateResult = await this.updateProductsJSON(fileName, productInfo);
        console.log('products.json更新完成, category:', category);
      } catch (error) {
        console.error('更新products.json失败:', error);
      }

      // 修复：添加sender检查
      if (sender && sender.tab) {
        this.notifyContentScript(sender.tab.id, {
          action: 'uploadSuccess',
          ossUrl: uploadResult.url,
          fileName: fileName
        });
      }

      console.log('✅ OSS上传成功:', uploadResult.url);
      return {
        success: true,
        ossUrl: uploadResult.url,
        fileName: fileName,
        uploadTime: new Date().toISOString()
      };
    } catch (error) {
      console.error('❌ OSS上传失败:', error);
      this.updateStats(false);

      // 修复：添加sender检查
      if (sender && sender.tab) {
        this.notifyContentScript(sender.tab.id, {
          action: 'uploadFailed',
          error: error.message,
          productUrl: productData.url
        });
      }

      return {
        success: false,
        error: error.message,
        productUrl: productData.url
      };
    }
  }

  async handleTestOSSConnection(ossConfig) {
    console.log('测试OSS连接:', ossConfig);
    try {
      if (!ossConfig || !ossConfig.region || !ossConfig.bucket || !ossConfig.accessKeyId || !ossConfig.accessKeySecret) {
        return { success: false, error: 'OSS配置不完整，请检查所有必需字段' };
      }

      const testPath = 'connection-test.json';
      const testData = JSON.stringify({
        test: true,
        timestamp: new Date().toISOString(),
        config: {
          region: ossConfig.region,
          bucket: ossConfig.bucket
        }
      }, null, 2);

      const endpoint = `https://${ossConfig.bucket}.${ossConfig.region}.aliyuncs.com/${testPath}`;

      try {
        const response = await fetch(endpoint, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': this.generateOSSAuth('PUT', `/${testPath}`, testData.length, ossConfig),
            'x-oss-object-acl': 'public-read',
            'x-oss-date': new Date().toUTCString()
          },
          body: testData
        });

        if (response.ok || response.status === 403) {
          return { success: true, message: 'OSS连接测试成功！存储桶访问正常' };
        } else {
          const errorText = await response.text();
          throw new Error(`OSS返回错误: ${response.status} - ${errorText}`);
        }
      } catch (fetchError) {
        console.log('详细测试失败，尝试基本连接测试:', fetchError);
        const configValid = this.validateOSSFormat(ossConfig);
        if (configValid) {
          return { success: true, message: 'OSS配置格式正确（注意：实际连接测试需要网络环境支持）' };
        } else {
          throw new Error('OSS配置格式不正确，请检查配置参数');
        }
      }
    } catch (error) {
      console.error('OSS连接测试失败:', error);
      return { success: false, error: error.message || '连接测试失败' };
    }
  }

  validateOSSFormat(ossConfig) {
    const regionRegex = /^oss-[a-z]+-\d+$/;
    const bucketRegex = /^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/;
    const accessKeyIdRegex = /^LTAI[A-Za-z0-9]+$/;
    return (
      regionRegex.test(ossConfig.region) &&
      bucketRegex.test(ossConfig.bucket) &&
      accessKeyIdRegex.test(ossConfig.accessKeyId) &&
      ossConfig.accessKeySecret &&
      ossConfig.accessKeySecret.length > 10
    );
  }

  validateOSSConfig() {
    return !!(
      this.ossConfig.region &&
      this.ossConfig.bucket &&
      this.ossConfig.accessKeyId &&
      this.ossConfig.accessKeySecret
    );
  }

  generateFileName(productData) {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 8);
    const oemCode = productData.oemCodes[0] || 'no-oem';
    const sanitizedTitle = productData.title.substring(0, 30).replace(/[^a-zA-Z0-9_-]/g, '_');
    return `${timestamp}_${oemCode}_${sanitizedTitle}.json`;
  }

  // ========== 格式转换功能 ==========
  detectDataFormat(data) {
    try {
      const parsed = JSON.parse(data);
      // 检测是否为嵌套格式
      if (parsed.metadata && parsed.product) {
        console.log('检测到嵌套格式数据，需要转换');
        return 'nested';
      }
      // 检测是否为扁平格式
      if (parsed.title && parsed.oem && parsed.images) {
        console.log('检测到扁平格式数据，无需转换');
        return 'flat';
      }
      console.log('未知数据格式');
      return 'unknown';
    } catch (error) {
      console.error('格式检测失败:', error);
      return 'invalid';
    }
  }

  convertNestedToFlat(nestedData) {
    try {
      const product = nestedData.product || {};
      const metadata = nestedData.metadata || {};
      const seo = nestedData.seo || {};

      // 提取时间戳ID
      const timestamp = metadata.fileName ?
        metadata.fileName.split('_')[0] :
        Date.now().toString();

      // 提取OEM编码
      const oemCode = product.oemCodes && product.oemCodes.length > 0 ?
        product.oemCodes[0] : '';

      // 处理图片
      const images = product.images || [];
      const imageString = images.length > 0 ? images.join(',') : '';

      // 构建扁平格式
      const flatData = {
        id: parseInt(timestamp) || Date.now(),
        name: product.title || '',
        title: product.title || '',
        category: 'other',
        oem: oemCode,
        oemCode: oemCode,
        url: metadata.sourceUrl || product.url || '',
        description: product.description || seo.description || '',
        images: images,
        image: imageString,
        fitmentTable: product.fitment || [],
        brand: nestedData.brand || '',
        collectedAt: metadata.collectedAt || new Date().toISOString(),
        hasFitment: product.hasFitment || false
      };

      console.log('格式转换成功:', flatData.title);
      return flatData;
    } catch (error) {
      console.error('格式转换失败:', error);
      throw new Error('数据格式转换失败');
    }
  }

  ensureFlatFormat(data) {
    try {
      // 检测数据格式
      const format = this.detectDataFormat(data);

      if (format === 'flat') {
        // 已经是扁平格式，直接使用
        return data;
      } else if (format === 'nested') {
        // 嵌套格式，需要转换
        const nestedData = JSON.parse(data);
        const flatData = this.convertNestedToFlat(nestedData);
        return JSON.stringify(flatData, null, 2);
      } else {
        console.warn('未知格式数据，保持原样');
        return data;
      }
    } catch (error) {
      console.error('格式处理失败:', error);
      return data; // 出错时保持原样
    }
  }
  // ========== 结束：格式转换功能 ==========

  prepareUploadData(productData) {
    // 生成与旧产品兼容的扁平结构
    const oemCode = productData.oemCodes && productData.oemCodes.length > 0 ? productData.oemCodes[0] : '';
    const imageString = productData.images && productData.images.length > 0 ? productData.images.join(',') : '';
    
    // 优先从标题识别品牌
    const titleBrand = this.identifyBrand(productData.title);
    console.log('🔍 标题识别品牌:', titleBrand);
    
    // 从车型适配表自动分类
    const fitmentData = productData.fitment || [];
    const fitmentCategory = this.autoClassifyByFitment(fitmentData);
    console.log('🔍 车型表分类:', fitmentCategory);
    
    // 优先使用标题识别的品牌，其次使用车型表分类
    let category = 'other';
    if (titleBrand && titleBrand !== 'other') {
      category = titleBrand;
    } else if (fitmentCategory && fitmentCategory !== 'other') {
      category = fitmentCategory;
    }
    console.log('✅ 最终分类:', category);
    
    return JSON.stringify({
      id: Date.now(), // 使用时间戳作为ID
      name: productData.title,
      title: productData.title,
      category: category,
      oem: oemCode,
      oemCode: oemCode,
      url: productData.url,
      description: productData.description || productData.seoDescription || '',
      images: productData.images || [],
      image: imageString, // 逗号分隔的图片字符串
      fitmentTable: fitmentData, // 适配表
      brand: titleBrand, // 品牌识别
      collectedAt: productData.collectedAt, // 采集时间
      hasFitment: productData.hasFitment || false,
      // SEO字段
      seoTitle: productData.seoTitle || '',
      seoDescription: productData.seoDescription || '',
      seoKeywords: productData.seoKeywords || [],
      urlSlug: productData.urlSlug || '',
      h1Title: productData.h1Title || '',
      h2Title: productData.h2Title || '',
      imageAltText: productData.imageAltText || ''
    }, null, 2);
  }

  async uploadWithRetry(filePath, data, maxRetries = 3) {
    let lastError = null;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`上传尝试 ${attempt}/${maxRetries}:`, filePath);
        const result = await this.uploadToOSS(filePath, data);
        return result;
      } catch (error) {
        lastError = error;
        console.error(`上传失败 (尝试 ${attempt}):`, error.message);
        if (attempt < maxRetries) {
          const delay = Math.pow(2, attempt) * 1000;
          console.log(`等待 ${delay}ms 后重试...`);
          await this.sleep(delay);
        }
      }
    }
    throw new Error(`上传失败，已重试 ${maxRetries} 次。最后错误: ${lastError.message}`);
  }

  async uploadToOSS(filePath, data) {
    const endpoint = `https://${this.ossConfig.bucket}.${this.ossConfig.region}.aliyuncs.com/${filePath}`;
    try {
      const response = await fetch(endpoint, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': this.generateOSSAuth('PUT', filePath, data.length),
          'x-oss-date': new Date().toUTCString()
          // 移除了 'x-oss-object-acl: public-read'，避免权限问题
        },
        body: data
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`OSS上传失败: ${response.status} - ${errorText}`);
      }

      return {
        url: endpoint,
        etag: response.headers.get('etag'),
        size: data.length
      };
    } catch (error) {
      if (error.name === 'TimeoutError') {
        throw new Error('上传超时（120秒），请检查网络连接');
      }
      throw error;
    }
  }

  generateOSSAuth(method, objectKey, contentLength) {
    const date = new Date().toUTCString();
    const canonicalizedResource = `/${this.ossConfig.bucket}${objectKey}`;
    const canonicalizedOSSHeaders = 'x-oss-date:' + date;
    const stringToSign = [
      method,
      '', // Content-MD5
      'application/json', // Content-Type
      date,
      canonicalizedOSSHeaders,
      canonicalizedResource
    ].join('\n');

    // 修复：使用正确的HMAC-SHA1签名
    return this.hmacSHA1(stringToSign, this.ossConfig.accessKeySecret).then(signature => {
      return `OSS ${this.ossConfig.accessKeyId}:${signature}`;
    });
  }

  async hmacSHA1(message, secret) {
    // 优先使用 Web Crypto API（现代浏览器）
    if (crypto && crypto.subtle) {
      try {
        const encoder = new TextEncoder();
        const cryptoKey = await crypto.subtle.importKey(
          'raw', encoder.encode(secret),
          { name: 'HMAC', hash: 'SHA-1' },
          false, ['sign']
        );
        const signature = await crypto.subtle.sign('HMAC', cryptoKey, encoder.encode(message));
        const signatureArray = Array.from(new Uint8Array(signature));
        return btoa(String.fromCharCode.apply(null, signatureArray));
      } catch (error) {
        console.warn('Web Crypto API 失败:', error);
      }
    }
    // 备选：JavaScript HMAC-SHA1
    return this.jsHmacSHA1(message, secret);
  }
  
  jsHmacSHA1(message, secret) {
    function rotl(n, s) { return (n << s) | (n >>> (32 - s)); }
    function sha1hex(str) {
      const hex = '0123456789abcdef';
      let h = '';
      for (let i = 0; i < str.length * 8; i += 8) {
        h += hex[(str.charCodeAt(i >> 5) >>> (24 - i % 32)) & 0xf];
        h += hex[(str.charCodeAt(i >> 5) >>> (16 - i % 32)) & 0xf];
        h += hex[(str.charCodeAt(i >> 5) >>> (8 - i % 32)) & 0xf];
        h += hex[(str.charCodeAt(i >> 5) >>> (0 - i % 32)) & 0xf];
      }
      return h;
    }
    function sha1add(x, y) { return ((x & 0x7fffffff) + (y & 0x7fffffff)) ^ (x & 0x80000000) ^ (y & 0x80000000); }
    
    const msg = unescape(encodeURIComponent(message));
    const words = [];
    for (let i = 0; i < msg.length; i++) words[i >> 2] |= (msg.charCodeAt(i) & 0xff) << (24 - (i % 4) * 8);
    words[msg.length >> 2] |= 0x80 << (24 - (msg.length % 4) * 8);
    words[(((msg.length + 8) >> 6) * 15) + 15] = msg.length * 8;
    
    let h0 = 0x67452301, h1 = 0xEFCDAB89, h2 = 0x98BADCFE, h3 = 0x10325476, h4 = 0xC3D2E1F0;
    
    for (let i = 0; i < words.length; i += 16) {
      const w = [];
      for (let j = 0; j < 16; j++) w[j] = words[i + j] || 0;
      for (let j = 16; j < 80; j++) w[j] = rotl(w[j-3] ^ w[j-8] ^ w[j-14] ^ w[j-16], 1);
      let a = h0, b = h1, c = h2, d = h3, e = h4;
      for (let j = 0; j < 80; j++) {
        let f, k;
        if (j < 20) { f = (b & c) | ((~b) & d); k = 0x5a827999; }
        else if (j < 40) { f = b ^ c ^ d; k = 0x6ed9eba1; }
        else if (j < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8f1bbcdc; }
        else { f = b ^ c ^ d; k = 0xca62c1d6; }
        const temp = sha1add(sha1add(rotl(a, 5), f), sha1add(sha1add(e, k), w[j]));
        e = d; d = c; c = rotl(b, 30); b = a; a = temp;
      }
      h0 = sha1add(h0, a); h1 = sha1add(h1, b); h2 = sha1add(h2, c);
      h3 = sha1add(h3, d); h4 = sha1add(h4, e);
    }
    
    const ipad = new Array(64).join('\x36');
    const opad = new Array(64).join('\x5c');
    const key = secret.length > 64 ? sha1hex(secret) : secret;
    let inner = '', outer = '';
    for (let i = 0; i < 64; i++) {
      inner += String.fromCharCode(key.charCodeAt(i) ^ ipad.charCodeAt(i));
      outer += String.fromCharCode(key.charCodeAt(i) ^ opad.charCodeAt(i));
    }
    return btoa(sha1hex(inner + message));
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  identifyBrand(title) {
    const titleLower = title.toLowerCase();
    const brandMap = {
      // 日系
      'toyota': 'japanese', 'honda': 'japanese', 'nissan': 'japanese',
      'mazda': 'japanese', 'subaru': 'japanese', 'mitsubishi': 'japanese',
      'suzuki': 'japanese', 'lexus': 'japanese', 'infiniti': 'japanese', 'acura': 'japanese',
      // 德系
      'bmw': 'german', 'mercedes': 'german', 'mercedes-benz': 'german',
      'audi': 'german', 'volkswagen': 'german', 'vw ': 'german', 'porsche': 'german',
      // 美系
      'ford': 'other', 'chevrolet': 'other', 'chevy': 'other',
      'dodge': 'other', 'gmc': 'other', 'jeep': 'other', 'ram': 'other',
      'cadillac': 'other', 'buick': 'other',
      // 韩系
      'hyundai': 'korean', 'kia': 'korean', 'genesis': 'korean',
      // 中国品牌
      'chery': 'chinese', 'geely': 'chinese', 'byd': 'chinese', 'haval': 'chinese',
      'great wall': 'chinese', 'changan': 'chinese', 'mg ': 'chinese',
      // 五菱宏光Mini EV 特殊处理
      'wuling': 'chinese', '五菱': 'chinese', 'hongguang': 'chinese', 'mini ev': 'chinese'
    };

    for (const [keyword, category] of Object.entries(brandMap)) {
      if (titleLower.includes(keyword)) {
        return category;
      }
    }
    return 'other';
  }

  updateStats(success) {
    this.stats.total++;
    if (success) {
      this.stats.success++;
    } else {
      this.stats.failed++;
    }
    if (!this.stats.startTime) {
      this.stats.startTime = new Date().toISOString();
    }
  }

  async saveStats() {
    try {
      await chrome.storage.local.set({
        collectorStats: this.stats,
        lastUpdate: new Date().toISOString()
      });
    } catch (error) {
      console.error('保存统计信息失败:', error);
    }
  }

  async updateConfiguration(newConfig) {
    try {
      if (newConfig.ossConfig) {
        this.ossConfig = { ...this.ossConfig, ...newConfig.ossConfig };
        await chrome.storage.sync.set({
          ossConfig: this.ossConfig,
          collectorConfig: newConfig.collectorConfig || {}
        });
        console.log('配置已更新:', this.ossConfig);
      }
    } catch (error) {
      console.error('更新配置失败:', error);
      throw error;
    }
  }

  notifyContentScript(tabId, message) {
    chrome.tabs.sendMessage(tabId, message).catch(error => {
      console.error('通知内容脚本失败:', error);
    });
  }

  // ========== 新增：products.json 管理功能 ==========

  // 获取当前的 products.json
  async getProductsJSON() {
    try {
      const endpoint = `${this.ossConfig.productsUrl}`;
      const response = await fetch(endpoint);
      
      if (response.ok) {
        const data = await response.json();
        console.log('获取products.json成功:', data);
        
        // 兼容数组格式和对象格式
        if (Array.isArray(data)) {
          // 数组格式：[{"id":1,...}, {"id":2,...}]
          console.log('检测到数组格式，产品数量:', data.length);
          return { success: true, data: data };
        } else if (data && typeof data === 'object' && Array.isArray(data.products)) {
          // 对象格式：{"products": [...], "lastUpdated": "..."}
          console.log('检测到对象格式，产品数量:', data.products.length);
          return { success: true, data: data.products };
        } else {
          // 格式无效，返回失败状态
          console.warn('products.json结构无效');
          return { success: false, error: 'products.json结构无效' };
        }
      } else if (response.status === 404) {
        // 文件不存在，返回空数组
        console.log('products.json不存在，返回空数组');
        return { success: true, data: [] };
      } else {
        throw new Error(`获取products.json失败: ${response.status}`);
      }
    } catch (error) {
      console.error('获取products.json失败:', error);
      // 网络不稳定时返回失败状态，不返回空数组
      return { success: false, error: '网络不稳定，读取products.json失败' };
    }
  }

  // 更新 products.json
  async updateProductsJSON(fileName, productInfo) {
    try {
      console.log('开始更新products.json，添加文件:', fileName);
      
      // 获取当前的 products.json
      const result = await this.getProductsJSON();
      
      // 检查是否读取成功
      if (!result.success) {
        console.error('❌ 更新products.json失败:', result.error);
        console.error('⚠️ 产品已上传到OSS，但未加入产品列表');
        console.error('⚠️ 请稍后重新采集以添加到产品列表');
        // OSS上传已成功，products.json更新失败不影响采集状态
        return { success: true, warning: result.error };
      }
      
      // 获取产品数组
      let productsArray = result.data || [];
      
      // 检查产品数量是否合理（防止意外覆盖）
      if (productsArray.length === 0) {
        console.warn('⚠️ products.json为空，将创建新产品列表');
      }
      
      // 检查是否已存在该产品
      const exists = productsArray.some(p => {
        // 兼容不同的数据结构
        const productFileName = p.fileName || p.name || p.title || JSON.stringify(p);
        return productFileName === fileName;
      });
      
      if (exists) {
        console.log('产品已存在，跳过添加:', fileName);
        return { success: true, message: '产品已存在' };
      }
      
      // 添加新产品到列表（最新产品在最前面）
      productsArray.unshift({
        fileName: fileName,
        ...productInfo
      });

      // 对整个数组进行格式检测和转换，确保所有产品都是扁平格式
      const convertedProductsArray = productsArray.map(product => {
        // 检查是否需要转换
        if (product.product || product.metadata) {
          // 嵌套格式，需要转换
          const flatProduct = this.convertNestedToFlat(product);
          return {
            fileName: product.fileName,
            ...flatProduct
          };
        }
        // 扁平格式，确保有fileName字段
        if (!product.fileName) {
          // 如果没有fileName，根据其他信息生成一个
          const timestamp = product.id || Date.now();
          const oemCode = product.oem || 'no-oem';
          const sanitizedTitle = (product.title || '').substring(0, 30).replace(/[^a-zA-Z0-9_-]/g, '_');
          product.fileName = `${timestamp}_${oemCode}_${sanitizedTitle}.json`;
        }
        return product;
      });

      // 更新时间戳
      const updatedData = Array.isArray(result.data)
        ? convertedProductsArray
        : {
            products: convertedProductsArray,
            lastUpdated: new Date().toISOString()
          };
      
      // 转换为JSON字符串
      const jsonData = JSON.stringify(updatedData, null, 2);
      
      // 上传到OSS
      const endpoint = `${this.ossConfig.productsUrl}`;
      const auth = await this.generateOSSAuth('PUT', '/products.json', jsonData.length);
      
      const response = await fetch(endpoint, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': auth,
          'x-oss-date': new Date().toUTCString()
        },
        body: jsonData
      });
      
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`更新products.json失败: ${response.status} - ${errorText}`);
      }
      
      console.log('✅ products.json更新成功，当前产品数量:', productsArray.length);
      // 更新version.json，触发后台刷新
      await this.updateVersionJSON("plugin_collect");
      return {
        success: true,
        productCount: productsArray.length
      };
    } catch (error) {
      console.error('更新products.json失败:', error);
      throw error;
    }
  }
  
  // 更新 version.json（新增）
  async updateVersionJSON(source = 'plugin') {
    try {
      const newVersion = Date.now();
      const versionData = {
        version: newVersion,
        timestamp: new Date(newVersion).toISOString(),
        source: source
      };
      
      const jsonData = JSON.stringify(versionData, null, 2);
      const endpoint = `https://${this.ossConfig.bucket}.${this.ossConfig.region}.aliyuncs.com/version.json`;
      const auth = await this.generateOSSAuth('PUT', '/version.json', jsonData.length);
      
      const response = await fetch(endpoint, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': auth,
          'x-oss-date': new Date().toUTCString()
        },
        body: jsonData
      });
      
      if (!response.ok) {
        console.error('更新version.json失败:', response.status);
        return { success: false };
      }
      
      console.log('✅ version.json更新成功:', newVersion);
      return { success: true, version: newVersion };
    } catch (error) {
      console.error('更新version.json失败:', error);
      return { success: false };
    }
  }

  // ========== SEO自动优化功能 ==========
  
  async handleSEOUpload(data) {
    try {
      const productData = data;
      const brand = productData.brand || 'Auto';
      const title = productData.title || productData.name || '';
      const oem = productData.oemCode || '';
      const images = productData.images || [];
      
      // 提取分类
      const keywords = ['brake', 'filter', 'oil', 'spark', 'belt', 'sensor', 'pump', 'alternator', 'starter', 'clutch', 'bearing'];
      const lower = (title || '').toLowerCase();
      let category = 'Auto Parts';
      for (const kw of keywords) {
        if (lower.includes(kw)) {
          category = kw.charAt(0).toUpperCase() + kw.slice(1) + ' Parts';
          break;
        }
      }
      
      const metaTitle = title ? title + ' | OEM Quality ' + brand + ' Parts - Carval Auto' : brand + ' Auto Parts';
      const metaDesc = 'Wholesale ' + (title || brand) + ' from Carval Auto Parts. 16 years experience, OEM quality, global shipping.';
      
      const structuredData = {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": title || brand,
        "brand": { "@type": "Brand", "name": brand },
        "description": metaDesc,
        "image": images,
        "sku": oem,
        "offers": { "@type": "Offer", "price": productData.price || "Contact", "priceCurrency": "USD", "availability": "https://schema.org/InStock" },
        "aggregateRating": { "@type": "AggregateRating", "ratingValue": "4.8", "reviewCount": "156" }
      };
      
      const safeId = (productData.id || oem || Date.now().toString()).replace(/[^a-zA-Z0-9-_]/g, '_');
      const fileName = 'products/' + safeId + '.html';
      
      const html = '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>' + metaTitle + '</title><meta name="description" content="' + metaDesc + '"><meta name="robots" content="index, follow"><link rel="canonical" href="https://carvalautopart.com/' + fileName + '"><meta property="og:title" content="' + metaTitle + '"><meta property="og:description" content="' + metaDesc + '"><meta property="og:type" content="product">' + (images[0] ? '<meta property="og:image" content="' + images[0] + '">' : '') + '<script type="application/ld+json">' + JSON.stringify(structuredData) + '</script><style>*{margin:0;padding:0}body{font-family:Arial,sans-serif;max-width:1200px;margin:0 auto;padding:20px;background:#f5f5f5}.c{background:#fff;padding:30px;border-radius:8px}h1{color:#333;margin-bottom:20px}.g{display:grid;grid-template-columns:repeat(auto-fit,250px);gap:20px;margin:20px 0}.g img{width:100%;border-radius:8px}.i{background:#f9f9f9;padding:20px;border-radius:8px;margin:20px 0}.p{font-size:24px;color:#e74c3c;font-weight:bold}.b{color:#00d4ff;font-weight:bold}.co{background:#667eea;color:#fff;padding:30px;border-radius:8px;text-align:center;margin-top:30px}f{text-align:center;margin-top:40px;padding:20px;color:#888}</style></head><body><div class="c"><h1>' + brand + ' ' + category + ' | OEM Quality</h1><div class="g">' + images.map((img, i) => '<img src="' + img + '" alt="' + title + ' ' + category + ' Image ' + (i+1) + '">').join('') + '</div><div class="i"><p class="b">Brand: ' + brand + '</p>' + (oem ? '<p>OEM: ' + oem + '</p>' : '') + (productData.price ? '<p class="p">' + productData.price + '</p>' : '') + '<p>' + metaDesc + '</p></div><h2>Why Choose Carval Auto?</h2><ul><li>16+ Years Experience</li><li>OEM Quality Guarantee</li><li>Global Shipping</li></ul><div class="co"><h2>Contact Us</h2><p>+86 195 2122 8657</p><p>info@carvalautopart.com</p></div></div><f>2024 Guangzhou Carval Auto Parts Co., Ltd.</f></body></html>';
      
      const apiUrl = 'https://api.github.com/repos/' + this.githubConfig.username + '/' + this.githubConfig.repository + '/contents/' + fileName;
      let sha = null;
      try {
        const check = await fetch(apiUrl, { headers: { 'Authorization': 'token ' + this.githubConfig.token } });
        if (check.ok) sha = (await check.json()).sha;
      } catch (e) {}
      
      const body = { message: 'Add SEO: ' + (title || oem || 'product'), content: btoa(unescape(encodeURIComponent(html))), branch: this.githubConfig.branch };
      if (sha) body.sha = sha;
      
      const response = await fetch(apiUrl, { method: 'PUT', headers: { 'Authorization': 'token ' + this.githubConfig.token, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      
      if (!response.ok) throw new Error('GitHub: ' + response.status);
      
      return { success: true, url: 'https://carvalautopart.com/' + fileName, fileName };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  // ========== 结束：products.json 管理功能 ==========
}

// 初始化后台服务
const collectorBackground = new CollectorBackground();

// 监听扩展安装/更新事件
chrome.runtime.onInstalled.addListener((details) => {
  console.log('扩展安装/更新:', details.reason);
  if (details.reason === 'install') {
    chrome.tabs.create({ url: 'popup.html?mode=setup' });
  }
});

// 监听网络请求（可选，用于调试）
chrome.webRequest.onCompleted.addListener(
  (details) => {
    if (details.url.includes('aliyuncs.com')) {
      console.log('OSS请求完成:', details);
    }
  },
  { urls: ['https://*.aliyuncs.com/*'] }
);
